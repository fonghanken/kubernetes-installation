# Simple Helm Example

Helm manifest of an nginx deployment with exposed secrets.

This method of delivery into K8 cluster is not being used.
