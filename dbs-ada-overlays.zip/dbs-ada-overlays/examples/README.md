# Delivery of Tenant Tools
Following [GitOps](https://about.gitlab.com/topics/gitops/) principles, we make use of [ArgoCD](https://argo-cd.readthedocs.io/en/stable/#what-is-argo-cd) to deliver microservices into the kubernetes cluster in a declarative manner.

Before proceeding, it'd be useful to understand:
- Core concepts of [ArgoCD](https://argo-cd.readthedocs.io/en/stable/core_concepts/)
- Kubernetes resource templating with Helm, or patching with [Kustomize](https://kubectl.docs.kubernetes.io/guides/introduction/kustomize/)
- Usage of [ArgoCD Vault Plugin](https://argocd-vault-plugin.readthedocs.io/en/stable/howitworks/#generic-placeholders) to template secrets

## How do we use ArgoCD ?
- Using the `Application` CRD by ArgoCD, we are able to define:
  - source location of the kubernetes resource files (i.e. git repository)
  - destination cluster and namespace to deliver microservices to
- Application source types:
  - Supported
  <br> &#x2611; `kustomize`
  <br> &#x2611; `helm-kustomize`
  - Not Supported
  <br> &#x2612; `plain`
  <br> &#x2612; `helm`
  
- Secret content are to be stored in the managed Vault
  - They must not exist in any repository
  - Kubernetes secret resources residing in `vault-secrets` directories would be templated using the Vault Plugin

## Tenant Guide
### Folder Structure
A tool may be delivered into multiple environments, each with a different configuration. It is suggested to follow the below conventions:
- `manifest/{TOOL_NAME}`, for each particular version of tool
- `overlays/{ENV_NAME}/{TOOL_NAME}`, for each tool in each environment
```sh
tenant-repository
├── manifest
│   ├── tool-one
│   └── tool-two
└── overlays
    └── poc
    │   ├── tool-one
    │   │   └── vault-secrets
    │   └── tool-two
    │       └── vault-secrets
    └── sit
        ├── tool-one
        │   └── vault-secrets
        └── tool-two
            └── vault-secrets
```
### Examples
Go through in the following order:
  1. [simpleweb-plain](manifest/simpleweb-plain/README.md)
  2. [simpleweb-kustomize](manifest/simpleweb-kustomize/README.md)  [supported source type]
  3. [simpleweb-helm](manifest/simpleweb-helm/README.md)
  4. [simpleweb-helmkustomize](manifest/simpleweb-helmkustomize/README.md) [supported source type]

### Commands to Generate Folders
```sh
# input variables
REPO_NAME=examplerepo
TOOL_NAME=exampletool
ENV_NAME=poc

# setup repo folder structure
MANIFEST_DIR="${REPO_NAME}/manifest/${TOOL_NAME}/"
OVERLAY_DIR="${REPO_NAME}/overlays/${ENV_NAME}/${TOOL_NAME}/"
SECRETS_DIR="${REPO_NAME}/overlays/${ENV_NAME}/${TOOL_NAME}/vault-secrets"

# setup manifest
mkdir -p ${MANIFEST_DIR}
echo "proceed to add helm chart or kustomization base files into '${MANIFEST_DIR}'.."

# setup overlay
mkdir -p ${OVERLAY_DIR}
cat <<EOF > ${OVERLAY_DIR}/kustomization.yaml
apiVersion: kustomize.config.k8s.io/v1beta1
kind: Kustomization
resources:
  - manifest.yaml
  - vault-secrets.yaml
EOF

# setup secrets
mkdir -p ${SECRETS_DIR}
echo "proceed to add vault secrets into '${SECRETS_DIR}'.."
```


<!--
## High-level process
**Tenant**
1. Create Tenant's Vault keystore, and upload secrets to it
2. Prepare Tenant's tool repository
   1. Manifest
   2. (Environment-specific) Overlays
      1. Configuration values
      2. Secret manifests
      3. Labels
3. Provide repository access for ArgoCD's multi-tenant usage
4. Provide vault credentials for ArgoCD's multi-tenant usage

**Operator**

5. Upload secrets to Platform's Vault keystore
6. Mount vault credentials to ArgoCD
7. Update `manifest.yaml`
8. Generate cluster `config.yaml`
9. Commit to repository
    
-->

# Deployment of Platform Tools
## High-level process
**Tenant**
1. Create Tenant's Vault keystore, and upload secrets to it
2. Prepare Tenant's tool repository
   1. (Environment-specific) Overlays
      1. Configuration values
      2. Secret manifests
      3. Labels

**Operator**

1. Update `manifest.yaml`
2. Generate cluster `config.yaml`
3. Commit to repository
