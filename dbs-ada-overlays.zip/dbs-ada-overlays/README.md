# dbs-adak8s-overlays

## steps to deploy
### pre-bootstrap
- clean slate of k8 cluster
  - new cluster or execute `nukestrap.sh`
- populate Vault Secrets

### bootstrap
- prepare one-use vault credentials
- execute `bootstrap.sh`
  - uses one-use vault credentials to retrieve:
    - vault credentials
    - repositiory SSH credentials
    - (if required) ca certificate
  - deploys nginx and argocd
  - deploys app of apps into argocd

### post-bootstrap
- initialize TiDB
  - prepare for usage by applications (airflow, superset)
- initialize RabbitMQ
  - prepare for usage by applications (airflow, superset)
  - set pod management policy
