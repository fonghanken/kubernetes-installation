
Application Versions
===========

This repository contains all the versions of the different applications.


## Configuration

The following table lists the Versions of all the Applications

S/N | Application   | Address                                                                                     | Version   | Supported | Latest
--- | ------------- | ------------------------------------------------------------------------------------------  | --------- | --------- | ---------
1   | Airflow       | [Link here](https://github.com/apache/airflow/tree/main/chart)                              | v2.2.3    |           | v2.3.2
2   | ArgoCD        | [Link here](https://github.com/argoproj/argo-helm/tree/main/charts/argo-cd)                 | v2.4.8    |           | v2.4.8
3   | ArgoWorkflow  | [Link here](https://github.com/argoproj/argo-helm/tree/main/charts/argo-workflows)          | v3.3.8    |           | v3.3.8
4   | CertManager   | [Link here](https://github.com/helm/charts/tree/master/stable/cert-manager)                 | v1.4.0    |           | v1.8.2
5   | ChaosMesh     | [Link here](https://github.com/chaos-mesh/chaos-mesh/tree/master/helm/chaos-mesh)           | v2.2.2    |           | v2.2.2
6   | HMS           |                                                                                             | v367.0.0  |           | v367.0.0
7   | Istio         | [Link here](https://github.com/istio/istio/tree/master/manifests/charts/base)               | v1.14.0   |           | v1.14.1
8   | Jenkins       | [Link here](https://github.com/jenkinsci/helm-charts/tree/main/charts/jenkins)              | v2.319.2  |           | v4.1.12
9   | JupyterBook   | custom-built                                                                                | v1.0.0    |           | 
10  | JupyterHub    | [Link here](https://github.com/jupyterhub/helm-chart)                                       | v1.2.0    |           | v1.2.0
11  | Kafka         | [Link here](https://github.com/bitnami/charts/tree/master/bitnami/kafka)                    |           |           | v3.2.0
12  | Keycloak      | [Link here](https://github.com/codecentric/helm-charts/tree/master/charts/keycloak)         |           |           | v18.1.1
13  | Kyverno       | [Link here](https://github.com/kyverno/kyverno/tree/main/charts/kyverno)                    | v1.6.1    |           | v1.7.1
14  | Logging       | [Link here](https://github.com/bitnami/charts/tree/master/bitnami)                          | v1.0.0    |           |
15  | Longhorn      | [Link here](https://github.com/longhorn/longhorn/tree/master/chart)                         | v1.2.4    |           | v1.3.0
16  | Nginx         | [Link here](https://github.com/kubernetes/ingress-nginx/tree/main/charts/ingress-nginx)     | v1.3.0    |           | v1.3.0
17  | Monitoring    | [Link here](https://github.com/bitnami/charts/tree/master/bitnami)                          | v1.0.0    |           |
18  | RabbitMQ      | [Link here](https://github.com/bitnami/charts/tree/master/bitnami/rabbitmq-cluster-operator)| v3.10.5   |           | v3.10.5
19  | Sealedsecrets | [Link here](https://github.com/bitnami-labs/sealed-secrets/tree/main/helm/sealed-secrets)   | v0.17.5   |           | v0.18.0
20  | Spark         | [Link here](https://github.com/bitnami/charts/tree/master/bitnami/spark)                    | v3.2.1    |           | v3.2.1
21  | Superset      | [Link here](https://github.com/apache/superset/tree/master/helm/superset)                   | v0.0.0dev |           | v1.5.1
22  | TiDB          | [Link here](https://github.com/pingcap/tidb-operator/tree/master/charts)                    | v6.1.0    |           | v6.1.0
23  | Trino         | [Link here](https://github.com/trinodb/charts/tree/main/charts/trino)                       | v355.0.0  |           | v0.8.0
24  | Utilitytool   | custom-built                                                                                | v1.0.0    |           | 
25  | Vault         | [Link here](https://github.com/hashicorp/vault-helm)                                        | v0.14.2   |           | v0.20.1
26  | ElasticSearch | [Link here](https://github.com/bitnami/charts/tree/master/bitnami/elasticsearch)            | v7.16.3   |           | v8.1.0
27  | Fluentbit     | [Link here](https://github.com/fluent/helm-charts/tree/main/charts/fluent-bit)              | v1.8.11   |           | v1.9.6
28  | Fluentd       | [Link here](https://github.com/fluent/helm-charts/tree/main/charts/fluentd)                 | v1.12.4   |           | v1.14.6
29  | Kibana        | [Link here](https://github.com/bitnami/charts/tree/master/bitnami/kibana)                   | v7.16.3   |           | v8.1.0
30  | Prometheus    | [Link here](https://github.com/bitnami/charts/tree/master/bitnami/kube-prometheus)          | v2.36.1   |           | v2.36.2
31  | Thanos        | [Link here](https://github.com/bitnami/charts/tree/master/bitnami/thanos)                   | v0.27.0   |           | v0.27.0
32  | Grafana       | [Link here](https://github.com/bitnami/charts/tree/master/bitnami/grafana)                  | v8.3.4    |           | v9.0.5
33  | Kiali         | [Link here](https://github.com/kiali/helm-charts/tree/master/kiali-server)                  |
34  | Jaegar        |                                                                                             |
 
_Documentation   generated by [Versent K8S Team](https://versent.atlassian.net/wiki/spaces/DBS/pages/8432812196/Engineering+Notes)._