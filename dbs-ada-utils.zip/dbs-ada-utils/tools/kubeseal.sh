#!/usr/bin/env bash
### Get TLS Cert for Kubeseal ###
sealedsecretRepo=https://github.com/Versent/dbs-ada.git
git clone $sealedsecretRepo
cd dbs-ada/poc/k8s-config/sealedsecrets

aws secretsmanager get-secret-value --secret-id dbs-ada/controller/sealedsecret-key --output text --query 'SecretString' \
    | jq -r '.data."tls.crt"' | base64 -d > sealedsecret-tls.crt

### Get List of Secrets ###
filter=gitcred-argo
SCRT_NAMES=( $( aws secretsmanager list-secrets --query 'SecretList[*].Name' --output text --filters Key=name,Values=dbs-ada/$filter ) )
echo "List Secrets: ${#SCRT_NAMES[@]}"

for i in "${SCRT_NAMES[@]}"
do
    ### Retrieve secret value ###
    secretName=$( echo gitcred-${i##*/} )
    aws secretsmanager get-secret-value --secret-id $i --output text --query 'SecretString' > $secretName.json
    kubeseal --format=yaml --cert=sealedsecret-tls.crt < $secretName.json > $secretName-sealed.yaml
    
done
rm $secretName.json sealedsecret-tls.crt
git add *-sealed.yaml
git commit -m "Sealedsecret Updates"
git push origin

function getSecret() {
    URL="https://vault.stg.ada.innovation-1.versent-innovation.au1.staxapp.cloud" &&
    SECPATH="v1/example-store/data/sealedsecret-key" &&
    USER=admin &&
    PASS=password &&
    VAULT_TOKEN=$(curl -sk --request POST --data '{"password": "'$PASS'"}' $URL/v1/auth/userpass/login/$USER | jq -r '.auth.client_token') &&
    curl -sk --header "X-Vault-Token: $VAULT_TOKEN" $URL/$SECPATH | jq -r '.data.data'
}

function generateSecret() {
    name=$1
    namespace=$2
    annotations=$3
    labels=$4
    data=$(getSecret)
    cat << EOF > tmpFile.json
{
    "metadata": {
        "name": "$name",
        "namespace": "$namespace",
        "labels":$labels,
        "annotations":$annotations
    },
    "data": $data,
    "type": "Opaque"
}
EOF

    cat tmpFile.json | jq -r '.' > $name-$namespace-secret.json &&
    rm -rf tmpFile.json
}

function testGenSecret() {
    generateSecret 'test-cred' 'test' '{"managed-by": "argocd.argoproj.io"}' '{"argocd.argoproj.io/secret-type": "repository"}'
}