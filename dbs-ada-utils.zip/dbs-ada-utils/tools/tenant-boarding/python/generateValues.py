#!/usr/bin/env python3

import argparse
from os import path
import sys, logging, re
import json

from utils import NameMapping, YamlTool, merge_dictionary
class ValuesGenerator:
    """
    Parses a cluster-level yaml to generate environment-level yaml, for ApplicationSet's consumption
    """
    _overlays_path = 'overlays'
    _input_manifest_filepath = '{}/manifest.yaml'
    _output_bootstrapvalues_filepath = '{}/core/adak8s/aasyncapp/values-bootstrap.yaml'
    _output_toolvalues_filepath = '{}/core/adak8s/aasyncapp/values-tools.yaml'
    _output_tenantvalues_filepath = '{}/core/adak8s/aasyncapp/values-tenants.yaml'
    _output_namespacevalues_filepath = '{}/core/adak8s/aasyncapp/values-namespaces.yaml'

    _generated_values = {}
    _flattened_values = []
    _write_values_result = {}

    _super_tenants = ['adak8s']

    def __init__(self, repository_path) -> None:
        self.repository_path = repository_path
        self.overlays_path = path.join(self.repository_path, self._overlays_path)
        logging.debug(f'repository_path: {self.repository_path}')
        logging.debug(f'overlays_path: {self.overlays_path}')

    ## TRANSFORMATION
    def add_tenant_default_values(self, default_data, record):
        """
        Inherits the tenant-level default values if the tool record does not already contain it
        """
        record['tenant'] = {
            'name': default_data['name']
        }
        skip_keys = ['name', 'tools']
        for key_name in default_data:
            if key_name in skip_keys:
                continue
            elif type(default_data[key_name]) is dict and key_name in record['tool']:
                record['tool'][key_name] = merge_dictionary(default_data[key_name], record['tool'][key_name])
            elif key_name in record['tool']:
                continue
            else:
                record['tool'][key_name] = default_data[key_name]
                # record['tool'][key_name] = copy.deepcopy(default_data[key_name])
        return record
    def add_environment_default_values(self, default_data, record):
        """
        Inherits the environment-level default values if the tool record does not already contain it
        """
        record['environment'] = {
            'name': default_data['name']
        }
        skip_keys = ['name', 'tenants']
        for key_name in default_data:
            if key_name in skip_keys:
                continue
            elif type(default_data[key_name]) is dict and key_name in record['tool']:
                record['tool'][key_name] = merge_dictionary(default_data[key_name], record['tool'][key_name])
            elif key_name in record['tool']:
                continue
            else:
                record['tool'][key_name] = default_data[key_name]
                # record['tool'][key_name] = copy.deepcopy(default_data[key_name])
        return record
    def add_cluster_default_values(self, default_data, record):
        """
        Inherits the cluster-level default values if the tool record does not already contain it
        """
        record['cluster'] = {
            'name': default_data['name']
        }
        skip_keys = ['name', 'cluster', 'environments']
        for key_name in default_data:
            if key_name in skip_keys:
                continue
            elif type(default_data[key_name]) is dict and key_name in record['tool']:
                record['tool'][key_name] = merge_dictionary(default_data[key_name], record['tool'][key_name])
            elif key_name in record['tool']:
                continue
            else:
                record['tool'][key_name] = default_data[key_name]
                # record['tool'][key_name] = copy.deepcopy(default_data[key_name])
        return record

    def add_short_names(self, short_names, record):
        """
        Enrich subconfig records with short names
        """
        environmentNameMap = short_names['environment']
        tenantNameMap = short_names['tenant']
        toolNameMap = short_names['tool']

        record['environment']['display'] = environmentNameMap[record['environment']['name']]
        record['tenant']['display'] = tenantNameMap[record['tenant']['name']]
        record['tool']['display'] = toolNameMap[record['tool']['name']]

    def replace_values(self, record):
        """
        Substitution procedures to replace the ${TOKENS}
        """
        payload = json.dumps(record)
        replace_str = re.findall(r'\${([\w\_]+)}', payload)
        replace_str = list(set(replace_str))
        replace_map = {}
        for replace_key in replace_str:
            if '_' in replace_key:
                object_name, object_key = replace_key.split('_')
            else:
                object_name = replace_key
                object_key = replace_key
            object_name = object_name.lower()
            object_key = object_key.lower()
            replace_map[replace_key] = record[object_name][object_key]
        logging.debug('replace_map:')
        logging.debug(replace_map)
        for replace_key in replace_map:
            payload = payload.replace('${'+f'{replace_key}'+'}', replace_map[replace_key])
        data = json.loads(payload)
        logging.debug('data:')
        logging.debug(data)
        return data

    def sort_tool_records(self, records):
        return sorted(records, key = lambda x: (x['cluster']['name'], x['environment']['name'], x['tenant']['name'], x['tool']['name']))

    def sort_tenant_records(self, records):
        for record_index in range(len(records)):
            records[record_index]['namespaces'] = sorted(records[record_index]['namespaces'], key = lambda x: (x['name']))
        return sorted(records, key = lambda x: (x['name']))

    def sort_namespace_records(self, records):
        return sorted(records, key = lambda x: (x['name']))

    ## STATUS REPORTING
    def save_status(self, name, result):
        self._write_values_result[name] = result
    
    def print_status_result(self):
        successful_generation = filter(lambda x: x[1] == True, self._write_values_result.items())
        successful_generation = list(map(lambda x: x[0], successful_generation))
        failed_generation = filter(lambda x: x[1] != True, self._write_values_result.items())
        failed_generation = list(map(lambda x: x[0], failed_generation))
        logging.info(f'Successful Generation: {successful_generation}')
        logging.info(f'Failed Generation: {failed_generation}')
        if failed_generation:
            logging.warning('Failed Generation..')
            return False
        logging.info('Completed Generation..')
        return True

    def generate_cluster_tool_values(self, cluster_data, short_names):
        tool_records = []
        for environment_data in cluster_data['environments']:
            # environment_name = environment_data['name']
            tenants = environment_data['tenants']
            for tenant_data in tenants:
                for tool in tenant_data['tools']:
                    tool_record = { 'tool': tool }
                    self.add_tenant_default_values(tenant_data, tool_record)
                    self.add_environment_default_values(environment_data, tool_record)
                    self.add_cluster_default_values(cluster_data, tool_record)
                    self.add_short_names(short_names, tool_record)
                    tool_record = self.replace_values(tool_record)
                    tool_records.append(tool_record)
        tool_records = self.sort_tool_records(tool_records)
        return tool_records

    def generate_cluster_tenant_values(self, tool_records):
        tenant_dict = {}
        for tool_record in tool_records:
            tenant_name = tool_record['tenant']['name']
            namespace = tool_record['tool']['namespace']
            if tenant_name in self._super_tenants:
                namespace = '*'
            if tenant_name not in tenant_dict:
                tenant_dict[tenant_name] = set()
            tenant_dict[tenant_name].add(namespace)
        tenant_records = []
        for tenant_name, tenant_namespaces in tenant_dict.items():
            tenant_records.append({
                'name': tenant_name,
                'namespaces': [{'name': tenant_namespace} for tenant_namespace in tenant_namespaces]
            })
        tenant_records = self.sort_tenant_records(tenant_records)
        return tenant_records

    def generate_cluster_namespace_values(self, tool_records):
        namespace_dict = {}
        for tool_record in tool_records:
            namespace = tool_record['tool']['namespace']
            istio_flag = tool_record['tool']['istioFlag']
            if namespace not in namespace_dict:
                namespace_dict[namespace] = {
                    'istioFlag': istio_flag
                }
        namespace_records = []
        for namespace_name, namespace_values in namespace_dict.items():
            namespace_records.append({
                'name': namespace_name,
                **namespace_values
            })
        namespace_records = self.sort_namespace_records(namespace_records)
        return namespace_records

    def reduce_tool_values(self, tool_records):
        for tool_record in tool_records:
            # print(tool_record.keys())
            del tool_record['tool']['istioFlag']
        return tool_records

    ## ENTRYPOINTS
    def generate_values(self, short_names, cluster_name):
        """
        Identifies the mainconfigs of each cluster, and generates the environment subconfigs 
        Subconfig Values are filled by precedence of specificity (Tool > Tenant > Environment > Cluster)
        """
        # load main config
        input_config_filepath = path.join(self.overlays_path, self._input_manifest_filepath.format(cluster_name))
        logging.debug(f'input_config_filepath: {input_config_filepath}')
        cluster_data = YamlTool.load_file(input_config_filepath)
        if cluster_data is None:
            return
        # generate tool records
        tool_records = self.generate_cluster_tool_values(cluster_data, short_names)
        # generate tenant records
        tenant_records = self.generate_cluster_tenant_values(tool_records)
        # generate tenant records
        namespace_records = self.generate_cluster_namespace_values(tool_records)
        # cache value files
        output_bootstrapvalues_filepath = path.join(self.overlays_path, self._output_bootstrapvalues_filepath.format(cluster_name))
        output_toolvalues_filepath = path.join(self.overlays_path, self._output_toolvalues_filepath.format(cluster_name))
        output_tenantvalues_filepath = path.join(self.overlays_path, self._output_tenantvalues_filepath.format(cluster_name))
        output_namespacevalues_filepath = path.join(self.overlays_path, self._output_namespacevalues_filepath.format(cluster_name))
        logging.debug(f'output_bootstrapvalues_filepath: {output_bootstrapvalues_filepath}')
        logging.debug(f'output_toolvalues_filepath: {output_toolvalues_filepath}')
        logging.debug(f'output_tenantvalues_filepath: {output_tenantvalues_filepath}')
        logging.debug(f'output_namespacevalues_filepath: {output_namespacevalues_filepath}')
        # drop tool records redundent values
        tool_records = self.reduce_tool_values(tool_records)
        self._generated_values[f"{cluster_name}"] = [
            {
                'name': 'bootstrap',
                'filepath': output_bootstrapvalues_filepath,
                'contents': { "tools": [tool_records[0]] }
            },
            {
                'name': 'tools',
                'filepath': output_toolvalues_filepath,
                'contents': { "tools": tool_records }
            },
            {
                'name': 'tenants',
                'filepath': output_tenantvalues_filepath,
                'contents': { "tenants": tenant_records }
            },
            {
                'name': 'namespaces',
                'filepath': output_namespacevalues_filepath,
                'contents': { "namespaces": namespace_records }
            }
        ]
        self._flattened_values.extend(tool_records)
                
    def save_generated_values(self):
        for cluster_name, cluster_values in self._generated_values.items():
            for cluster_value in cluster_values:
                status = YamlTool.save_file(cluster_value['filepath'], cluster_value['contents'])
                self.save_status(f'{cluster_name}-{cluster_value["name"]}', status)

## MISC
def usage_msg():
    if len(sys.argv) != 3:
        print(f"Usage: python {path.basename(sys.argv[0])} [path-to-overlay-repository] [cluster-name]")
        sys.exit(1)

def extract_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('repository', help='path to repository directory containing the overlays')
    parser.add_argument('cluster', help='name of cluster (i.e. found under overlays/ dir)')

    args = parser.parse_args()
    print(args)
    return args

## MAIN
if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)

    args = extract_args()
    repository_path = args.repository
    cluster_name = args.cluster

    logging.info(f"\trepository_path:    {repository_path}")
    logging.info(f"\tcluster_name:       {cluster_name}")

    values_generator = ValuesGenerator(repository_path)
    name_mapping = NameMapping(repository_path).load()
    values_generator.generate_values(name_mapping, cluster_name)
    values_generator.save_generated_values()
    if not values_generator.print_status_result():
        sys.exit(2)
