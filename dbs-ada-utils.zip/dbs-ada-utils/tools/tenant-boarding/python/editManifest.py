#!/usr/bin/env python3

import argparse
from os import path
import sys, logging

from utils import NameMapping, YamlTool
class ManifestEditor:
    """
    Parses a cluster-level yaml to generate environment-level yaml, for ApplicationSet's consumption
    """
    _cluster_manifest_filepath = 'overlays/{}/manifest.yaml'
    _cluster_manifest_filepath = 'overlays/{}/manifest.yaml'

    def __init__(self, repository_path, cluster) -> None:
        self.name_mapping = NameMapping(repository_path)
        self.repository_path = repository_path
        cluster_manifest_relative_filepath = self._cluster_manifest_filepath.format(cluster)
        self.cluster_manifest_filepath = path.join(self.repository_path, cluster_manifest_relative_filepath)
        logging.debug(f'repository_path: {self.repository_path}')
        logging.debug(f'cluster_manifest_filepath: {self.cluster_manifest_filepath}')

    def edit_environment(self, loaded_manifest, action, environment):
        found_record = [record for record in loaded_manifest['environments'] if record['name'] == environment]
        if action == 'add':
            if len(found_record) == 0:
                loaded_manifest['environments'].append({
                    'name': environment,
                    'tenants': []
                })
                return loaded_manifest['environments'][-1]
            else:
                return found_record[0]
        elif action == 'remove':
            if len(found_record) == 1:
                logging.debug(f'remove environment: {found_record[0]["name"]}')
                loaded_manifest['environments'].remove(found_record[0])
    def edit_tenant(self, loaded_environment, action, tenant):
        found_record = [record for record in loaded_environment['tenants'] if record['name'] == tenant]
        if action == 'add':
            if len(found_record) == 0:
                self.name_mapping.edit(action, 'tenant', tenant, tenant)
                loaded_environment['tenants'].append({
                    'name': tenant,
                    'tools': []
                })
                return loaded_environment['tenants'][-1]
            else:
                return found_record[0]
        elif action == 'remove':
            if len(found_record) == 1:
                logging.debug(f'remove tenant: {found_record[0]["name"]}')
                loaded_environment['tenants'].remove(found_record[0])
    def edit_tool(self, loaded_tenant, action, tool,  tool_version, tool_suffix=None, tool_opts=None):
        logging.debug(f'{action} tool: {tool} {tool_version} {tool_suffix}')
        if action == 'add':
            self.name_mapping.edit(action, 'tool', tool, tool)
            new_tool = {
                'name': tool,
                'version': tool_version,
                **tool_opts
            }
            if tool_suffix:
                new_tool['suffix'] = tool_suffix
            loaded_tenant['tools'].append(new_tool)
            return loaded_tenant['tools'][-1]
        elif action == 'remove':
            found_record = [record for record in loaded_tenant['tools'] if (record['name'] == tool and record['version'] == tool_version)]
            if tool_suffix:
                found_record = [record for record in found_record if 'suffix' in record and record['suffix'] == tool_suffix]
            else:
                found_record = [record for record in found_record if 'suffix' not in record]
            if len(found_record) == 1:
                logging.debug(f'remove tenant: {found_record[0]["name"]}')
                loaded_tenant['tools'].remove(found_record[0])
    
    def get_objects(self, loaded_manifest, environment, tenant, tool, tool_version, tool_suffix=None):
        found_environments = [record for record in loaded_manifest['environments'] if record['name'] == environment]
        found_environment = found_environments[0] if len(found_environments) == 1 else None
        if found_environment:
            found_tenants = [record for record in found_environment['tenants'] if record['name'] == tenant]
            found_tenant = found_tenants[0] if len(found_tenants) == 1 else None
            if found_tenant:
                found_tools = found_tenant and [record for record in found_tenant['tools'] if (record['name'] == tool and record['version'] == tool_version)]
                if tool_suffix:
                    found_tools = [record for record in found_tools if 'suffix' in record and record['suffix'] == tool_suffix]
                else:
                    found_tools = [record for record in found_tools if 'suffix' not in record]
                found_tool = found_tools[0] if len(found_tools) == 1 else None
            else: 
                found_tool = None
        else: 
            found_tenant = None
            found_tool = None
        return found_environment, found_tenant, found_tool

    ## ENTRYPOINTS
    def edit(self, action, action_category, environment, tenant, tool, tool_version, tool_suffix, tool_opts, force):
        """
        """
        # load manifest.yaml
        loaded_manifest = YamlTool.load_file(self.cluster_manifest_filepath)
        if loaded_manifest is None:
            logging.error("unable to load cluster manifest..")
            sys.exit(3)
        found_environment, found_tenant, found_tool = self.get_objects(loaded_manifest, environment, tenant, tool, tool_version, tool_suffix)
        logging.debug(f"{found_environment=}")
        logging.debug(f"{found_tenant=}")
        logging.debug(f"{found_tool=}")

        match action_category:
            case 'environment':
                validate_input_args({'environment': environment})
                self.edit_environment(loaded_manifest, action, environment)
            case 'tenant':
                validate_input_args({'environment': environment, 'tenant': tenant})
                if action == 'add':
                    if found_environment is None:
                        found_environment = self.edit_environment(loaded_manifest, action, environment)
                    self.edit_tenant(found_environment, action, tenant)
                elif action == 'remove':
                    if found_tenant:
                        self.edit_tenant(found_environment, action, tenant)
                    if found_environment and len(found_environment['tenants']) == 0:
                        self.edit_environment(loaded_manifest, action, environment)
            case 'tool':
                validate_input_args({'environment': environment, 'tenant': tenant, 'tool': tool, 'tool_version': tool_version})
                if action == 'add':
                    if found_environment is None:
                        found_environment = self.edit_environment(loaded_manifest, action, environment)
                    if found_tenant is None:
                        found_tenant = self.edit_tenant(found_environment, action, tenant)
                    if found_tool is None:
                        self.edit_tool(found_tenant, action, tool, tool_version, tool_suffix, tool_opts)
                    elif found_tool and force:
                        self.edit_tool(found_tenant, 'remove', tool, tool_version, tool_suffix, tool_opts)
                        self.edit_tool(found_tenant, action, tool, tool_version, tool_suffix, tool_opts)
                elif action == 'remove':
                    if found_tool:
                        self.edit_tool(found_tenant, action, tool, tool_version, tool_suffix)
                    if found_tenant and len(found_tenant['tools']) == 0:
                        self.edit_tenant(found_environment, action, tenant)
                    if found_environment and len(found_environment['tenants']) == 0:
                        self.edit_environment(loaded_manifest, action, environment)

        YamlTool.save_file(self.cluster_manifest_filepath, loaded_manifest)

## MISC
def validate_input_args(args):
    if None in args.values():
        msg = ', '.join([f'{k}({v})' for k, v in args.items() if v is None])
        logging.error(f"missing arguments: {msg}..")
        sys.exit(2)

def remove_value(obj, value):
  if isinstance(obj, (list, tuple, set)):
    return type(obj)(remove_value(x, value) for x in obj if x != value)
  elif isinstance(obj, dict):
    return type(obj)((remove_value(k, value), remove_value(v, value))
      for k, v in obj.items() if k != value and v != value)
  else:
    return obj

def extract_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['add-environment', 'add-tenant', 'add-tool', 'remove-environment', 'remove-tenant', 'remove-tool'])
    parser.add_argument('repository', help='path to repository directory containing the overlays')
    parser.add_argument('--cluster', '-c')
    parser.add_argument('--environment', '-e')
    parser.add_argument('--tenant', '-tn')
    parser.add_argument('--tool', '-t')
    parser.add_argument('--version', '-v')
    parser.add_argument('--suffix', '-s')
    parser.add_argument('--server', '-sv')
    parser.add_argument('--cmp-plugin', '-cp', help='name of cmp plugin')
    parser.add_argument('--cmp-values', '-cv', help='name of helm value files')
    parser.add_argument('--repo-url', '-ru', help='url of tool repository')
    parser.add_argument('--repo-ref', '-rr', help='branch of tool repository')
    parser.add_argument('--repo-basepath', '-rbp')
    parser.add_argument('--repo-overlaypath', '-rop')
    parser.add_argument('--skip-overlay', '-so', help='flag to skip overlay dir creation', action='store_true')
    parser.add_argument('--force', '-f', help='flag to overwrite existing when attempting to add', action=argparse.BooleanOptionalAction)

    args = parser.parse_args()
    print(args)
    return args

## MAIN
if __name__ == '__main__':
    # logging.basicConfig(level=logging.INFO)
    logging.basicConfig(level=logging.DEBUG)

    args = extract_args()
    repository_path = args.repository
    action, action_category = args.action.split('-')
    cluster_name = args.cluster
    environment_name = args.environment
    tenant_name = args.tenant
    tool_name = args.tool
    tool_version = args.version
    tool_suffix = args.suffix
    tool_opts = {
        'cmp': {
            'plugin': args.cmp_plugin,
            'values': args.cmp_values
        },
        'repo': {
            'basepath': args.repo_basepath,
            'overlaypath': args.repo_overlaypath,
            'ref': args.repo_ref,
            'url': args.repo_url
        },
        'server': args.server
    }
    skip_overlay = args.skip_overlay
    if skip_overlay:
        tool_opts['createoverlay'] = False
    tool_opts = remove_value(tool_opts, None)
    tool_opts = remove_value(tool_opts, '')
    tool_opts = remove_value(tool_opts, {})
    force = args.force

    logging.info(f"\trepository_path:    {repository_path}")
    logging.info(f"\taction:             {action}")
    logging.info(f"\taction_category:    {action_category}")
    logging.info(f"\tcluster_name:       {cluster_name}")
    logging.info(f"\tenvironment_name:   {environment_name}")
    logging.info(f"\ttenant_name:        {tenant_name}")
    logging.info(f"\ttool_name:          {tool_name}")
    logging.info(f"\ttool_version:       {tool_version}")
    logging.info(f"\ttool_suffix:        {tool_suffix}")
    logging.info(f"\ttool_opts:          {tool_opts}")
    logging.info(f"\tskip_overlay:       {skip_overlay}")
    logging.info(f"\tforce:              {force}")

    manifest_editor = ManifestEditor(repository_path, cluster_name)
    manifest_editor.edit(action, action_category, environment_name, tenant_name, tool_name, tool_version, tool_suffix, tool_opts, force)
