#!/usr/bin/env python3

from os import path, mkdir
import logging
import yaml

class NameMapping:
    """
    Retrieves mappings of names to short names
    """
    _environment_mapping_filepath = 'mappings/environments.yaml'
    _tenant_mapping_filepath = 'mappings/tenants.yaml'
    _tool_mapping_filepath = 'mappings/tools.yaml'

    def __init__(self, repository_path) -> None:
        self.environment_mapping_filepath = path.join(repository_path, NameMapping._environment_mapping_filepath)
        self.tenant_mapping_filepath = path.join(repository_path, NameMapping._tenant_mapping_filepath)
        self.tool_mapping_filepath = path.join(repository_path, NameMapping._tool_mapping_filepath)
        logging.debug(f'repository_path: {repository_path}')
        logging.debug(f'environment_mapping_filepath: {self.environment_mapping_filepath}')
        logging.debug(f'tenant_mapping_filepath: {self.tenant_mapping_filepath}')
        logging.debug(f'tool_mapping_filepath: {self.tool_mapping_filepath}')

    def load(self):
        loaded_mappings = {}
        loaded_mappings['environment'] = YamlTool.load_file(self.environment_mapping_filepath)
        loaded_mappings['tenant'] = YamlTool.load_file(self.tenant_mapping_filepath)
        loaded_mappings['tool'] = YamlTool.load_file(self.tool_mapping_filepath)
        logging.debug(f"environment: {loaded_mappings['environment']}")
        logging.debug(f"tenant: {loaded_mappings['tenant']}")
        logging.debug(f"tool: {loaded_mappings['tool']}")

        return loaded_mappings

    def refresh(self, target_environments, target_tenants, target_tools):
        loaded_mappings = self.load()
        existing_environments = set(loaded_mappings['environment'])
        existing_tenants = set(loaded_mappings['tenant'])
        existing_tools = set(loaded_mappings['tool'])
        environments_to_add = target_environments - existing_environments
        environments_to_remove = target_environments - existing_environments
        tenants_to_add = target_tenants - existing_tenants
        tenants_to_remove = target_tenants - existing_tenants
        tools_to_add = target_tools - existing_tools
        tools_to_remove = target_tools - existing_tools
        for name in environments_to_add:
            self.edit('add', 'environment', name)
        for name in environments_to_remove:
            self.edit('remove', 'environment', name)
        for name in tenants_to_add:
            self.edit('add', 'tenant', name)
        for name in tenants_to_remove:
            self.edit('remove', 'tenant', name)
        for name in tools_to_add:
            self.edit('add', 'tool', name)
        for name in tools_to_remove:
            self.edit('remove', 'tool', name)

    def edit(self, action, action_category, key, value=None):
        match action_category:
            case "environment":
                mapping_filepath = self.environment_mapping_filepath
            case "tenant":
                mapping_filepath = self.tenant_mapping_filepath
            case "tool":
                mapping_filepath = self.tool_mapping_filepath
            case _:
                return
        logging.debug(f'mapping_filepath: {mapping_filepath}')
        loaded_mapping = YamlTool.load_file(mapping_filepath)
        if action == 'add':
            loaded_mapping[key] = value
        elif action == 'remove':
            loaded_mapping.pop(key)
        else:
            return
        YamlTool.save_file(mapping_filepath, loaded_mapping)
        return

class YamlTool:
    """
    Wrapper to reads and writes yaml files
    """
    def load_file(filepath):
        if path.exists(filepath):
            logging.info(f"Reading file from '{filepath}'")
            with open(filepath) as f:
                payload = yaml.load(f, Loader=yaml.loader.SafeLoader)
            return payload
        logging.warning(f"yaml file ({filepath}) is missing..")
        return None

    def save_file(filepath, payload):
        dir_path = path.dirname(filepath)
        if not path.exists(dir_path):
            logging.info(f"Creating directory ({path.dirname(filepath)})")
            mkdir(dir_path)
        logging.info(f"Writing file to '{filepath}'")
        with open(filepath, 'w') as file:
            yaml.dump(payload, file)
            return True

def merge_dictionary(addition_dictionary, base_dictionary):
    """
    Adds values from dictionary if missing from base dictionary
    """
    for key, value in addition_dictionary.items():
        if key not in base_dictionary:
            base_dictionary[key] = value
    return base_dictionary
