#!/usr/bin/env sh
set -e

############################################################
# Input Arguments                                          #
############################################################
UTILS_REPO=git@github.com:Versent/dbs-ada-utils.git
OVERLAY_REPO=git@github.com:Versent/dbs-ada.git
REPO_BRANCH=adak8s-deploy
CLUSTER_NAME=alpha
ENVIRONMENT_NAME=poc
TENANT_NAME=examples
TOOL_NAME=superset
TOOL_VERSION=0.0.0dev
TOOL_SUFFIX=3
ADDITIONAL_HELM_VALUES_BASE64=IyBzb21lIGNoYW5nZQpleHRyYVNlY3JldHM6IHt9CgpleHRyYVZvbHVtZXM6IFtdCgpleHRyYVZvbHVtZU1vdW50czogW10K
CMP_PLUGIN=tenant-helm-kustomize
CMP_VALUES=
if [[ ${TOOL_NAME} == 'superset' ]]; then
    CMP_VALUES=values.yaml,suffix.yaml
fi
if [[ ! -z ${ADDITIONAL_HELM_VALUES_BASE64} ]]; then
    ADDITIONAL_CMP_VALUE=/tmp/values-additional.yaml
    echo ${ADDITIONAL_HELM_VALUES_BASE64} | base64 -d > ${ADDITIONAL_CMP_VALUE}
    CMP_VALUES=${CMP_VALUES},values-additional.yaml
fi
REPO_URL=
REPO_REF=
REPO_BASEPATH=
REPO_OVERLAYPATH=
# TOOL_NAME=trino
# TOOL_VERSION=355.0.0
# TOOL_SUFFIX=
# CMP_PLUGIN=tenant-helm-kustomize
# CMP_VALUES=values.yaml
# REPO_URL=git@github.com:Versent/dbs-ada.git
# REPO_REF=master
# REPO_BASEPATH=manifest/superset
# REPO_OVERLAYPATH=overlay/superset

############################################################
# Entry Point                                              #
############################################################
SCRIPTS_DIR=/tmp/scripts
OVERLAY_REPO_DIR=/tmp/repo
UTILS_REPO_DIR=/tmp/utils-repo
# 0. Clone
git config --global user.email "argowf@adak8s.gitops"
git config --global user.name "argowf"
git clone ${UTILS_REPO} ${UTILS_REPO_DIR}
# cp -R ${UTILS_REPO_DIR}/src/docker/bootstrap/scripts ${SCRIPTS_DIR}
ln -s ${UTILS_REPO_DIR}/tools/tenant-boarding/ ${SCRIPTS_DIR}
git clone --recurse-submodules ${OVERLAY_REPO} -b ${REPO_BRANCH} ${OVERLAY_REPO_DIR}

# 1. Update file - Set tenant name in `mappings/tenants.yaml`
# 2. Update file - Set tool name in `overlays/{cluster}/manifest.yaml`
python ${SCRIPTS_DIR}/python/editManifest.py \
    --cluster ${CLUSTER_NAME} \
    --environment ${ENVIRONMENT_NAME} \
    --tenant ${TENANT_NAME} \
    --tool ${TOOL_NAME} \
    --version ${TOOL_VERSION} \
    --suffix "${TOOL_SUFFIX}" \
    --cmp-plugin "${CMP_PLUGIN}" \
    --cmp-values "${CMP_VALUES}" \
    --repo-url "${REPO_URL}" \
    --repo-ref "${REPO_REF}" \
    --repo-basepath "${REPO_BASEPATH}" \
    --repo-overlaypath "${REPO_OVERLAYPATH}" \
    --force \
    add-tool \
    ${OVERLAY_REPO_DIR}

# 3. Run script - generate appOfApp values
python ${SCRIPTS_DIR}/python/generateValues.py ${OVERLAY_REPO_DIR} ${CLUSTER_NAME}

# 4. Run script - create overlay directory
bash ${SCRIPTS_DIR}/bash/createOverlays.sh ${OVERLAY_REPO_DIR} ${CLUSTER_NAME}

# 5. Run script - overwrites additional values
bash ${SCRIPTS_DIR}/bash/replaceOverlays.sh ${OVERLAY_REPO_DIR} ${CLUSTER_NAME} ${ENVIRONMENT_NAME} ${TENANT_NAME} ${TOOL_NAME} "${TOOL_SUFFIX}" "${ADDITIONAL_CMP_VALUE}"

# 6. Commit
cd ${OVERLAY_REPO_DIR}
git add .
git commit -am "Adds ${CLUSTER_NAME}/${ENVIRONMENT_NAME}/${TENANT_NAME}/${TOOL_NAME}${TOOL_VERSION} @ $(date)"
git push origin ${REPO_BRANCH}
