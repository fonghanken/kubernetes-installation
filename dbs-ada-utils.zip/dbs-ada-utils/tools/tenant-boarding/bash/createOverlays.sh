#!/usr/bin/env bash

WORK_DIR=$(cd -P -- "$(dirname -- "$0")" && pwd -P)
cd $WORK_DIR

source f_func.sh;
DATE_NOW=$(date +%s)
OVERLAYS_REPO_DIR=$1
DATACENTRE=AWS
CLUSTER=$2
TEMPLT_DIR=templates/overlays
INFILE=$OVERLAYS_REPO_DIR/overlays/$CLUSTER/core/adak8s/aasyncapp/values-tools.yaml

yq -p yaml -o json '.tools' $INFILE | jq -c '.[]' | while read i; do
    NAMESPACE=$(echo $i | jq -r ".tool.namespace")
    CLUSTER_NAME=$(echo $i | jq -r ".cluster.name")
    ENV_NAME=$(echo $i | jq -r ".environment.name")
    TENANT_NAME=$(echo $i | jq -r ".tenant.name")
    TOOL_NAME=$(echo $i | jq -r ".tool.name")
    TOOL_VERSION=$(echo $i | jq -r ".tool.version")
    TOOL_REPO=$(echo $i | jq -r ".tool.repo.url")
    TOOL_CMP=$(echo $i | jq -r ".tool.cmp.plugin")
    TOOL_VALUE=$(echo $i | jq -r ".tool.cmp.values")
    TOOL_SUFFIX=$(echo $i | jq -r ".tool.suffix")
    TOOL_OVERLAY_PATH=$(echo $i | jq -r ".tool.repo.overlaypath")
    TOOL_CREATE_OVERLAY=$(echo $i | jq -r ".tool.createoverlay")

    echo "********************"
    echo "$CLUSTER_NAME[$ENV_NAME] - $TENANT_NAME: $TOOL_NAME$TOOL_SUFFIX($TOOL_VERSION) - $TOOL_CREATE_OVERLAY"

    TOOL_DIR=$OVERLAYS_REPO_DIR/$TOOL_OVERLAY_PATH
    MANIFEST_DIR=$OVERLAYS_REPO_DIR/manifest/$TOOL_NAME/$TOOL_VERSION
    if [[ $TOOL_CREATE_OVERLAY == 'true' ]]; then
        [[ ! -d $TOOL_DIR ]] && mkdir -p $TOOL_DIR
        if [[ "$TOOL_CMP" == *"helm"* ]]; then
            IFS=',' read -ra VALUE <<< "$TOOL_VALUE"
            for j in "${VALUE[@]}"; do
                if [[ ! -f $TOOL_DIR/$j ]]; then
                    cp $MANIFEST_DIR/$j $TOOL_DIR/$j
                    echo "  - Generated $j"
                else
                    echo "  - $j exist"
                fi
            done
        fi

        if [[ ! -f $TOOL_DIR/kustomization.yaml && -d $TEMPLT_DIR/$TOOL_NAME ]]; then
            cp -R $TEMPLT_DIR/$TOOL_NAME/* $TOOL_DIR
            for TEMPLT_FILEPATH in $(find $TOOL_DIR -type f ! -iname "values*.yaml")
            do  
                echo "working on $TEMPLT_FILEPATH"
                (eval "echo \"$(cat $TEMPLT_FILEPATH)\"")>/tmp/templt.buffer
                (eval "echo \"$(cat /tmp/templt.buffer)\"")>$TEMPLT_FILEPATH
                # rm /tmp/templt.buffer
            done
            echo "  - Generated kustomization.yaml"
        elif [[ ! -f $TOOL_DIR/kustomization.yaml ]]; then
            (eval "echo \"$(cat $TEMPLT_DIR/template-kustomize.yaml)\"")>$OVERLAYS_REPO_DIR/temp-kustomize.yaml &&
            (eval "echo \"$(cat $OVERLAYS_REPO_DIR/temp-kustomize.yaml)\"")>$TOOL_DIR/kustomization.yaml
            rm -rf $OVERLAYS_REPO_DIR/temp-kustomize.yaml;
            echo "  - Generated kustomization.yaml"
        else
            echo "  - kustomization.yaml exist"
        fi
    fi
done

f_printEndTime;
