#!/usr/bin/env bash

WORK_DIR=$(cd -P -- "$(dirname -- "$0")" && pwd -P)
cd $WORK_DIR

source f_func.sh;
DATE_NOW=$(date +%s)

OVERLAYS_REPO_DIR=$1
CLUSTER=$2
ENV=$3
TENANT=$4
TOOL=$5
SUFFIX=$6
ADDITIONAL_VALUE_FILE=$7

if [[ -z $ADDITIONAL_VALUE_FILE ]]; then
    echo "- No additional values provided"
elif [[ -f $ADDITIONAL_VALUE_FILE ]]; then
    DEST_DIR=${OVERLAYS_REPO_DIR}/overlays/${CLUSTER}/${ENV}/${TENANT}/${TOOL}${SUFFIX}/$(basename $ADDITIONAL_VALUE_FILE)
    cp $ADDITIONAL_VALUE_FILE $DEST_DIR
    echo "- Added $DEST_DIR"
else 
    echo "- Missing $ADDITIONAL_VALUE_FILE"
fi

f_printEndTime;
