# https://www.keycloak.org/docs/latest/server_development/#admin-rest-api
# https://www.keycloak.org/docs-api/15.0/rest-api/

TARGET_CLIENT=$1
SUB_DOMAIN_NAME=$2

if [[ "${TARGET_CLIENT}" == 'superset' ]]; then
    # TARGET_CLIENT=superset
    URI_TO_ADD="https://${SUB_DOMAIN_NAME}.dev.ada.dbs-sandbox.versent-innovation.au1.staxapp.cloud/*"
elif [[ "${TARGET_CLIENT}" == 'trino' ]]; then
    # TARGET_CLIENT=trino
    URI_TO_ADD="https://${SUB_DOMAIN_NAME}.dev.ada.dbs-sandbox.versent-innovation.au1.staxapp.cloud/oauth2/callback"
else
    exit 1
fi

KC_REALM=master
KC_URL=https://keycloak.dev.ada.dbs-sandbox.versent-innovation.au1.staxapp.cloud

# KC_CLIENT_ID=a091e8de-1657-4232-a830-7a9235e5421a
# KC_CLIENT_SECRET=eyJhbGciOiJIUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICIwNDNlODk1ZS01MTBhLTQ1YWEtYjk5NC04Y2YwOWVhZWMzYjcifQ.eyJleHAiOjAsImlhdCI6MTY2MzIwOTYwMSwianRpIjoiYTA5MWU4ZGUtMTY1Ny00MjMyLWE4MzAtN2E5MjM1ZTU0MjFhIiwiaXNzIjoiaHR0cHM6Ly9rZXljbG9hay5kZXYuYWRhLmRicy1zYW5kYm94LnZlcnNlbnQtaW5ub3ZhdGlvbi5hdTEuc3RheGFwcC5jbG91ZC9hdXRoL3JlYWxtcy9tYXN0ZXIiLCJhdWQiOiJodHRwczovL2tleWNsb2FrLmRldi5hZGEuZGJzLXNhbmRib3gudmVyc2VudC1pbm5vdmF0aW9uLmF1MS5zdGF4YXBwLmNsb3VkL2F1dGgvcmVhbG1zL21hc3RlciIsInR5cCI6IkluaXRpYWxBY2Nlc3NUb2tlbiJ9.PYNOtQdjmpXckgCwfzc7TY04XyHJ6exPTrcoHmGuugM
# AUTH_REQUEST=$(curl -L \
#   -d "client_id=${KC_CLIENT_ID}" \
#   -d "client_secret=${KC_CLIENT_SECRET}" \
#   -d "grant_type=client_credentials" \
#   "${KC_URL}/auth/realms/${KC_REALM}/protocol/openid-connect/token")

AUTH_REQUEST=$(curl -L -X POST \
  -d "client_id=admin-cli" \
  -d "username=admin" \
  -d "password=admin" \
  -d "grant_type=password" \
  "${KC_URL}/auth/realms/${KC_REALM}/protocol/openid-connect/token")
AUTH_TOKEN=$(echo ${AUTH_REQUEST} | jq -r .access_token)
echo "AUTH_TOKEN: ${AUTH_TOKEN}"

CLIENTS_REQUEST=$(curl -L \
  -H "Authorization: Bearer ${AUTH_TOKEN}" \
  "${KC_URL}/auth/admin/realms/${KC_REALM}/clients")
echo "CLIENTS_REQUEST: ${CLIENTS_REQUEST}"
CLIENT_REQUEST=$(echo ${CLIENTS_REQUEST} | jq -r ".[] | select(.clientId==\"${TARGET_CLIENT}\")")
echo "CLIENT_REQUEST: ${CLIENT_REQUEST}"

CLIENT_ID=$(echo ${CLIENT_REQUEST} | jq -r .id)
CLIENT_REDIRECTS=$(echo ${CLIENT_REQUEST} | jq -c ".redirectUris += [\"${URI_TO_ADD}\"] | .redirectUris")
PAYLOAD={\"redirectUris\":${CLIENT_REDIRECTS}}

CLIENT_REQUEST=$(curl -L -X PUT -i \
  -s -o /dev/null -w "%{http_code}" \
  -H "Authorization: Bearer ${AUTH_TOKEN}" \
  -H 'Content-Type: application/json' \
  -d ${PAYLOAD} \
  "${KC_URL}/auth/admin/realms/${KC_REALM}/clients/${CLIENT_ID}")

[[ $CLIENT_REQUEST =~ ^2[0-9]{2}$ ]] && exit 0 || exit ${CLIENT_REQUEST}
