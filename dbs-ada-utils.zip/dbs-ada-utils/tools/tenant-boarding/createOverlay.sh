#!/usr/bin/env bash
source f_func.sh;
DATE_NOW=$(date +%s)

WORK_DIR=$(pwd)
DATACENTRE=AWS
CLUSTER=$1
ENVIRONMENT=$2
OVERLAY_REPO=git@github.com:Versent/dbs-ada.git
OUTPUT_DIR=outputs/deploy
TEMPLT_DIR=templates/overlays
INFILE=$OUTPUT_DIR/overlays/$CLUSTER/$ENVIRONMENT/config.yaml
git clone $OVERLAY_REPO -b adak8s-deploy --recursive $OUTPUT_DIR

yq -c '.[]' $INFILE | while read i; do
    NAMESPACE=$(echo $i | jq -r ".tool.namespace")
    CLUSTER_NAME=$(echo $i | jq -r ".cluster.name")
    CLUSTER_DISP=$(echo $i | jq -r ".cluster.display")
    ENV_NAME=$(echo $i | jq -r ".environment.name")
    ENV_DISP=$(echo $i | jq -r ".environment.display")
    TENANT_NAME=$(echo $i | jq -r ".tenant.name")
    TENANT_DISP=$(echo $i | jq -r ".tenant.display")
    TOOL_NAME=$(echo $i | jq -r ".tool.name")
    TOOL_DISP=$(echo $i | jq -r ".tool.display")
    TOOL_VERSION=$(echo $i | jq -r ".tool.version")
    TOOL_REPO=$(echo $i | jq -r ".tool.repo.url")
    TOOL_REF=$(echo $i | jq -r ".tool.repo.ref")
    TOOL_PATH=$(echo $i | jq -r ".tool.repo.path")
    TOOL_CMP=$(echo $i | jq -r ".tool.cmp.plugin")
    TOOL_VALUE=$(echo $i | jq -r ".tool.cmp.values")
    TOOL_SUFFIX=$(echo $i | jq -r ".tool.suffix")

    echo "********************"
    echo "$CLUSTER_NAME[$ENV_NAME] - $TENANT_NAME: $TOOL_NAME($TOOL_VERSION)"

    TOOL_DIR=$OUTPUT_DIR/overlays/$CLUSTER_NAME/$ENV_NAME/$TENANT_NAME/$TOOL_NAME$TOOL_SUFFIX
    MANIFEST_DIR=$OUTPUT_DIR/manifest/$TOOL_NAME/$TOOL_VERSION
    [[ ! -d $TOOL_DIR ]] && mkdir -p $TOOL_DIR

    if [[ "$TOOL_CMP" == *"helm"* ]]; then
        IFS=',' read -ra VALUE <<< "$TOOL_VALUE"
        for j in "${VALUE[@]}"; do
            if [[ ! -f $TOOL_DIR/$j ]]; then
                cp $MANIFEST_DIR/$j $TOOL_DIR/$j
                echo "  - Generated $j"
            else
                echo "  - $j exist"
            fi
        done
    fi
    if [[ ! -f $TOOL_DIR/kustomization.yaml ]]; then
        (eval "echo \"$(cat $TEMPLT_DIR/template-kustomize.yaml)\"")>$OUTPUT_DIR/temp-kustomize.yaml &&
        (eval "echo \"$(cat $OUTPUT_DIR/temp-kustomize.yaml)\"")>$TOOL_DIR/kustomization.yaml
        rm -rf $OUTPUT_DIR/temp-kustomize.yaml;
        echo "  - Generated kustomization.yaml"
    else
        echo "  - kustomization.yaml exist"
    fi
done

cd $OUTPUT_DIR
git add .
git commit -m "Build Overlays @date"
git push origin

rm -rf $WORK_DIR/$OUTPUT_DIR;
f_printEndTime;

