# Simple Plain Example

Plain manifest of an nginx deployment with exposed secrets.

Compare this against [simpleweb-kustomize](../simpleweb-kustomize/README.md).
