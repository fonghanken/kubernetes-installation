#!/usr/bin/env bash
set -e
source f_func.sh;
DATE_NOW=$(date +%s)

NODE_NAME=$1
kubectl taint nodes $NODE_NAME upgrade=detach:NoSchedule
kubectl drain $NODE_NAME --ignore-daemonsets --delete-local-data
kubectl delete node $NODE_NAME


f_printEndTime;