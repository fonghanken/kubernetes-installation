#!/usr/bin/env bash
source f_func.sh;
DATE_NOW=$(date +%s)
rm -rf final.yaml temp-config.yaml temp-kustomize.yaml;
CLUSTER_NAME=alpha
CLUSTER_DISPLAY=alp
ENV_DISPLAY=tEnv
TENANT_DISPLAY=tTnt
TOOL_DISPLAY=tTool
MAIN_DIR=/Users/hanken/Work/Codes/Development/versent-ada/dbs-ada

TEMPLT_DIR=templates/tools
OUTPUT_DIR=outputs
INFILE=$MAIN_DIR/overlays/$CLUSTER/config.yaml

ENV_ARRAY=( $(cat $INFILE | yq -r ".environments[].name") )
for i in "${ENV_ARRAY[@]}"
do
    ENVIRONMENT_NAME=$i
    echo -n $ENVIRONMENT_NAME
    jyEnvString=".environments[] | select(.name==\"$i\") |"
    TNT_ARRAY=( $(cat $INFILE | yq -r "$jyEnvString .tenants[].name") )
    echo ": ${#TNT_ARRAY[@]}"
    for j in "${TNT_ARRAY[@]}"
    do
        TENANT_NAME=$j
        echo -n " - $TENANT_NAME"
        jyTntString=".environments[] | select(.name|test(\"$i\")) | .tenants[] | select(.name==\"$j\") |"
        TOOL_ARRAY=( $(cat $INFILE | yq -r "$jyTntString .tools[].name") )
        echo ": ${#TOOL_ARRAY[@]}"
        for k in "${TOOL_ARRAY[@]}"
        do
            jyToolString=".environments[] | select(.name==\"$i\") | .tenants[] | select(.name==\"$j\") | .tools[] | select(.name==\"$k\") |"
            TOOL_NAME="$(cat $INFILE | yq -r "$jyToolString .name")"
            TOOL_VERSION="$(cat $INFILE | yq -r "$jyToolString .version")"
            echo "   - $TOOL_NAME : $TOOL_VERSION"

            f_fetchValue
            (eval "echo \"$(cat $TEMPLT_DIR/template-config.yaml)\"")>$OUTPUT_DIR/temp-config.yaml &&
            (eval "echo \"$(cat $OUTPUT_DIR/temp-config.yaml)\"")>>$OUTPUT_DIR/final.yaml
            rm -rf $OUTPUT_DIR/temp-config.yaml;
        done
    done
done
f_printEndTime;