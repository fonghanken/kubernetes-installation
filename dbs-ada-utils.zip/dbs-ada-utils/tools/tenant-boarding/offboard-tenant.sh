#!/usr/bin/env bash
set -e
function f_wait() {
    delayInSeconds=$1
    for (( i=delayInSeconds;i>=0;i-- )) ; do
        sleep 1
        printf "\rPlease wait... Ready in $i seconds "
    done
    printf "\rWait completed - $delayInSeconds seconds              "
    printf "\n"
}

function f_printEndTime() {
    endTime=$(date +%s) &&
    diff=$(expr $endTime - $DATE_NOW) && 
    echo -n "Transformation COMPLETED >>>>>> $CLUSTER @ " &&
    printf '%dh:%dm:%ds\n' $(($diff/3600)) $(($diff%3600/60)) $(($diff%60))
}

DATE_NOW=$(date +%s)

CLSR=$1
OVERLAY_REPO=$5
#OUTPUT_DIR=outputs/deploy
MAINENV=core
MAINTNT=adak8s
APPOFAPP=aasyncapp
ENVT=$2
TNT_NAME=$3
TOOL_NAME=$4
NS_ARG=adak8s-argocd
APP_NAME=$ENVT-$TNT_NAME-$TOOL_NAME

echo "***************************";
echo "***  Disable ArgoSync  ****";
echo "***************************";
kubectl patch app $APPOFAPP -n$NS_ARG --type='json' -p='[{"op": "remove", "path": "/spec/syncPolicy/automated"}]' &&
kubectl patch app $APP_NAME -n$NS_ARG --type='json' -p='[{"op": "remove", "path": "/spec/syncPolicy/automated"}]'
kubectl patch app $APP_NAME -n$NS_ARG --type='json' -p='{"metadata": {"finalizers": ["resources-finalizer.argocd.argoproj.io"]}}' --type merge
f_wait 5

echo "***************************";
echo "****  Delete Tool App  ****";
echo "***************************";
kubectl delete app $ENVT-$TNT_NAME-$TOOL_NAME -n$NS_ARG

# git clone $OVERLAY_REPO -b adak8s-deploy $OUTPUT_DIR

echo "***************************";
echo "****  Delete Overlay  *****";
echo "***************************";
rm -rf $OVERLAY_REPO/overlays/$CLSR/$ENVT/$TNT_NAME/$TOOL_NAME

# echo "***************************";
# echo "****  Delete Main Tool  ***";
# echo "***************************";
# yq -iy 'del( .tools[] | select(.tool.appname=="'$ENVT-$TNT_NAME-$TOOL_NAME'") )' $OUTPUT_DIR/overlays/$CLSR/$MAINENV/$MAINTNT/$APPOFAPP/values-tools.yaml
# yq '.environments[] | select (.name=="poc") | .tenants[] | select (.name=="datanaut") | .tools[] | select (.name=="superset")' $OUTPUT_DIR/overlays/$CLSR/manifest.yaml

# cd $OUTPUT_DIR
# git add .
# git commit -m "Delete $TNT_NAME from overlays $(date)"
# git push origin

# rm -rf $WORK_DIR/$OUTPUT_DIR;
f_printEndTime;