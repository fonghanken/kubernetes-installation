function f_fetchValue() {
    NAMESPACE=$(f_getValue "namespace");
    REPO_PATH=$(f_getValue "repo.path");
    REPO_URL=$(f_getValue "repo.url");
    REPO_REF=$(f_getValue "repo.ref");
    CMP_PLUGIN=$(f_getValue "cmp.plugin");
    CMP_VALUES=$(f_getValue "cmp.values");
}

function f_getValue() {
    # if [[ $(cat $INFILE | yq -r "$jyToolString .$1") != null ]]; then
    #     echo "$(cat $INFILE | yq -r "$jyToolString .$1")";
    # elif [[ $(cat $INFILE | yq -r "$jyTntString .$1") != null ]]; then
    #     echo "$(cat $INFILE | yq -r "$jyTntString .$1")";
    # elif [[ $(cat $INFILE | yq -r "$jyEnvString .$1") != null ]]; then
    #     echo "$(cat $INFILE | yq -r "$jyEnvString .$1")";
    # elif [[ $(cat $INFILE | yq -r ".$1") != null ]]; then
    #     echo "$(cat $INFILE | yq -r ".$1")";
    # fi
    
    tmpVar=$(cat $INFILE | yq -r "$jyToolString .$1") && [[ "$tmpVar" != null ]] \
        || tmpVar=$(cat $INFILE | yq -r "$jyTntString .$1") && [[ "$tmpVar" != null ]] \
        || tmpVar=$(cat $INFILE | yq -r "$jyEnvString .$1") && [[ "$tmpVar" != null ]] \
        || tmpVar=$(cat $INFILE | yq -r ".$1") && [[ "$tmpVar" != null ]];
    echo $tmpVar;
}

function f_wait() {
    delayInSeconds=$1
    for (( i=delayInSeconds;i>=0;i-- )) ; do
        sleep 1
        printf "\rPlease wait... Ready in $i seconds "
    done
    printf "\rWait completed - $delayInSeconds seconds              "
    printf "\n"
}

function f_printEndTime() {
    endTime=$(date +%s) &&
    diff=$(expr $endTime - $DATE_NOW) && 
    echo -n "Transformation COMPLETED >>>>>> $CLUSTER @ " &&
    printf '%dh:%dm:%ds\n' $(($diff/3600)) $(($diff%3600/60)) $(($diff%60))
}

function f_checkKustomize() {   
    yq -iy '
        .commonLabels.datacentre="$DATACENTRE" | 
        .commonLabels.cluster="$CLUSTER" |
        .commonLabels.environment="$ENVIRONMENT" |
        .commonLabels.appCode="$TENANT_NAME" |
        .commonLabels.pcCode="$TENANT_NAME"
    ' kustomization.yaml
}