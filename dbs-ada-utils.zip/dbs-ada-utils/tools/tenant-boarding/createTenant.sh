#!/usr/bin/env bash

WORK_DIR=$(pwd)
TENANT_NAME=$1
TEMPLT_DIR=templates/tenants
OUTPUT_DIR=outputs/schema
REPO=git@github.com:Versent/dbs-adak8s-schema.git

rm -rf $OUTPUT_DIR
git clone $REPO $OUTPUT_DIR

mkdir -p $OUTPUT_DIR/tenants/$TENANT_NAME

(eval "echo \"$(cat $TEMPLT_DIR/template-kustomize.yaml)\"")>$OUTPUT_DIR/tenants/$TENANT_NAME/kustomization.yaml

cd $OUTPUT_DIR/tenants/$TENANT_NAME
git add .
git commit -m "Create New Tenant - $TENANT_NAME @ $date"
git push origin

cd $WORK_DIR
rm -rf $OUTPUT_DIR