#!/usr/bin/env bash

WORK_DIR=$(pwd)
TOOL_NAME=$1
TOOL_VERSION=$2
TEMPLT_DIR=templates/tools
OUTPUT_DIR=outputs/manifest
REPO=git@github.com:Versent/dbs-adak8s-manifest.git

rm -rf $OUTPUT_DIR
git clone $REPO $OUTPUT_DIR

mkdir -p $OUTPUT_DIR/$TOOL_NAME/$TOOL_VERSION

(eval "echo \"$(cat $TEMPLT_DIR/template-kustomize.yaml)\"")>$OUTPUT_DIR/$TOOL_NAME/$TOOL_VERSION/kustomization.yaml

cd $OUTPUT_DIR/$TOOL_NAME/$TOOL_VERSION
git add .
git commit -am "Create New Tool - $TOOL_NAME:$TOOL_VERSION @ $date"
git push origin

cd $WORK_DIR
rm -rf $OUTPUT_DIR