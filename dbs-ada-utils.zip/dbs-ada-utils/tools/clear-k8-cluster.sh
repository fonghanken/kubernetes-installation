k get namespace --output=custom-columns="NAME:.metadata.name" --no-headers | xargs -I{} kubectl patch namespace {} --type='json'  -p='[{"op": "remove", "path": "/metadata/finalizers"}]'

k get appprojects.argoproj.io -nadak8s-acd --output=custom-columns="NAME:.metadata.name" --no-headers | xargs -I{} kubectl patch -nadak8s-acd appprojects.argoproj.io {} --type='json'  -p='[{"op": "remove", "path": "/metadata/finalizers"}]'
k get applications.argoproj.io -nadak8s-acd --output=custom-columns="NAME:.metadata.name" --no-headers | xargs -I{} kubectl patch -nadak8s-acd applications.argoproj.io {} --type='json'  -p='[{"op": "remove", "path": "/metadata/finalizers"}]'
k get applicationsets.argoproj.io -nadak8s-acd --output=custom-columns="NAME:.metadata.name" --no-headers | xargs -I{} kubectl patch -nadak8s-acd applicationsets.argoproj.io {} --type='json'  -p='[{"op": "remove", "path": "/metadata/finalizers"}]'

target_ns=adak8s-lhn
target_kind=lhv
k get -n $target_ns $target_kind --output=custom-columns="NAME:.metadata.name" --no-headers | xargs -I{} kubectl patch -n $target_ns $target_kind {} --type='json' -p='[{"op": "remove", "path": "/metadata/finalizers"}]'



k api-resources | grep longhorn | awk '{ print $2 }' | xargs -I{} kubectl delete {} --all -n adak8s-lhn

target_ns=adak8s-lhn
for target_kind in $(kubectl api-resources | grep longhorn | awk '{ print $2 }')
do
	kubectl get -n $target_ns $target_kind --output=custom-columns="NAME:.metadata.name" --no-headers | xargs -I{} kubectl patch -n $target_ns $target_kind {} --type='json' -p='[{"op": "remove", "path": "/metadata/finalizers"}]'
done