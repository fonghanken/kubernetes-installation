#!/usr/bin/env bash
source functions.sh

ARGO_DIR=/mydirectory
APPS_DIR=/myappdirectory

kubectl apply -k $ARGO_DIR &&
argopass
f_wait 10 &&
kubectl apply -k $APPS_DIR 