#!/usr/bin/env bash

generate_post_data()
{
  cat <<EOF
{
  "resourceKind": "WorkflowTemplate",
  "namespace": "$NS_NAME",
  "resourceName": "$WF_NAME",
  "submitOptions": {"parameters": $INPUT_PARAM}
}
EOF
}

### Declare Variables
ARGO_URL=$1 &&
NS_NAME=$2 &&
WF_NAME=$3 &&
INPUT_PARAM='["IMG_LIST=http-receiver","DAEMON_TIMER=400","S3_UPLOAD=false"]'

if [ -z "$ARGO_URL" ]; then
  echo "Please specify Argo Workflow URL!" 
  exit
fi
if [ -z "$NS_NAME" ]; then
  echo "Please specify Argo Workflow Namespace!" 
  exit
fi
if [ -z "$WF_NAME" ]; then
  echo "Please specify Argo Workflow Template Name!" 
  exit
fi

echo "INPUT PARAMS: $INPUT_PARAM"
echo "DATA: $(generate_post_data)"
### Get Workflow Template Name
WF_NAME=$(curl -sk $ARGO_URL/api/v1/workflow-templates/$NS_NAME | jq -r '.items[].metadata.name' | grep $WF_NAME | head -1) &&

#echo $WF_NAME


### Submit Workflow Template
curl -skX POST -H 'content-type: application/json' \
  --url $ARGO_URL/api/v1/workflows/$NS_NAME/submit \
  --data '{ 
      "resourceKind": "WorkflowTemplate",
      "namespace": "'$NS_NAME'",
      "resourceName": "'$WF_NAME'",
      "submitOptions": {"parameters": ["IMG_LIST=http-receiver","DAEMON_TIMER=400","S3_UPLOAD=false"]}
      }' | jq -r '.metadata.name'

