#!/usr/bin/env bash

# Helper functions
function downloadingImages {
    pwd
    mkdir -p docker-images
    cd docker-images
    fileName="../listOfImageToUpload.txt"
    while read -r line; do
        echo "------------------------------------------------------"
        echo "Pulling "$line""
        docker pull "$line"
        echo "Saving "$line""
        tarFileName=$(echo "$line" | sed 's/\//∕/g')
        echo $tarFileName
        docker save "$line" -o "$tarFileName".tar
        echo "------------------------------------------------------"
    done <$fileName
}

function retrieveImageFromHelm {
    fileName="../cdList.txt"
    while read -r line; do
        cd $CODEBUILD_SRC_DIR/k8s/$line
        helm template . |
            yq '..|.image? | select(.)' |
            sort |
            uniq | sed 's/"//g' >>$CODEBUILD_SRC_DIR/repoImageList.txt
    done <$fileName
}

# Main

# change directory to k8s directory
cd $CODEBUILD_SRC_DIR/k8s
ls
echo "generating repo image list file"

# generate repo image list file
echo "$(grep -rnw . -e "image:")" | awk -F "image:" '{print $2}' | awk -F " " '{print $1}' | sed 's/[{") ]//g' | grep '\S' | sed 's/\//∕/g' | sed 's/$/.tar/g' | sort | uniq >$CODEBUILD_SRC_DIR/repoImageList.txt

# Find helm images and add to list
echo "Finding helm images"
for i in $(find . -name "Chart.yaml" -type f); do
    echo "$i" | sed 's/Chart.yaml//g' | sed 's/\.\///g' >>../cdList.txt
done

cat ../cdList.txt | grep -v "/charts/" >$CODEBUILD_SRC_DIR/cdList.txt

retrieveImageFromHelm

# Change directory to dbs-ada
echo "change directory to main directory"
cd $CODEBUILD_SRC_DIR

# Generate Images inS3 List
echo "Generating S3 List"
aws s3 ls s3://dbsada-artifacts/images/ | awk -F " " '{print $4}' | sed '/^$/d' | sort | uniq >listOfImagesInS3.txt

# Compare new repo image list with S3 Images list
echo "Comparing repo image list with S3 list"
comm -23 <(sort repoImageList.txt) <(sort listOfImagesInS3.txt) >listOfImagesInRepoNotInS3.txt

# Edit file back to original format for download
echo "Editing file back to original format to download"
sed 's/∕/\//g' listOfImagesInRepoNotInS3.txt | sed 's/.tar//g' >listOfImageToUpload.txt

echo "-------------------------"
echo "list of images To upload"
cat listOfImageToUpload.txt
echo "-------------------------"

echo "Running docker pull and docker save for each line in listOfImageToUpload.txt"
downloadingImages
# upload to S3 Bucket
echo "Uploading to S3"
cd ..
aws s3 cp docker-images s3://dbsada-artifacts/images --recursive --exclude "*" --include "*.tar"