#!/usr/bin/env bash

kubectl delete apps --all -nargocd
kubectl delete appproj -all -nargocd

NS_ARRAY=( argocd ngress-nginx istio-system cert-manager )
for i in "${NS_ARRAY[@]}"
do
    kubectl delete statefulsets --all -n$i
    kubectl delete daemonsets -all -n$i
    kubectl delete deployments --all -n$i
    kubectl delete pods --all -n$i
done