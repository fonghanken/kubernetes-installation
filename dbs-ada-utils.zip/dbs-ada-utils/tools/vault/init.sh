#!/usr/bin/env bash
set -e

nginx_ns=edsf-vlt
vault_name=vault-0

WORK_DIR=$(cd `dirname $BASH_SOURCE` && pwd)

### Setup Vault ###
while ! kubectl exec $vault_name -n $nginx_ns -- hostname; do echo 'trying again in 20s..'; sleep 20; done

# upload: execution steps
kubectl cp ${WORK_DIR}/bootstrap-vault.sh $nginx_ns/$vault_name:/home/vault/bootstrap-vault.sh
# upload: policies
kubectl cp ${WORK_DIR}/policies/admin.hcl $nginx_ns/$vault_name:/home/vault/admin.hcl
kubectl cp ${WORK_DIR}/policies/autounseal.hcl $nginx_ns/$vault_name:/home/vault/autounseal.hcl
kubectl cp ${WORK_DIR}/policies/user.hcl $nginx_ns/$vault_name:/home/vault/user.hcl
# run
kubectl exec $vault_name  -n $nginx_ns -- sh -c "sh /home/vault/bootstrap-vault.sh"

echo '-- vault initialization complete --'
