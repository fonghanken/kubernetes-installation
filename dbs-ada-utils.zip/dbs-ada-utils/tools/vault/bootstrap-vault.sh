## unseal and login ##
WORK_DIR='/vault/data'
SECRET_FILE=${WORK_DIR}/unsealkeys.yaml

if [ ! -f "${SECRET_FILE}" ]; then
  vault operator init  -key-shares 1 -key-threshold 1 -format yaml > ${SECRET_FILE}
else
  echo "found unsealkeys.yaml"
fi
VAULT_UNSEAL_KEY=$(cat ${SECRET_FILE} | grep - | head -n1 | awk '{ printf $2 }')
VAULT_TOKEN=$(cat ${SECRET_FILE} | grep root_token | awk '{ printf $2 }')

### APPLY TO MAIN VAULT ###
vault operator unseal ${VAULT_UNSEAL_KEY}
vault login ${VAULT_TOKEN}

## enable USERPASS auth ##
vault auth enable userpass

## create admin user
vault policy write admin-policy /home/vault/admin.hcl
vault write auth/userpass/users/admin \
  password=password \
  policies=admin-policy

## create example user
vault policy write user-policy /home/vault/user.hcl
vault write auth/userpass/users/example-user \
  password=password \
  policies=user-policy

## create example secret store
vault secrets enable -version=2 -path=example-store kv
vault kv put example-store/appsecrets some-key=some-provided-value
