#!/usr/bin/env bash
source functions.sh;
DATE_NOW=$(date +%s)

WORK_DIR=$(pwd)
OVERLAY_REPO=git@github.com:Versent/dbs-ada.git
OUTPUT_DIR=outputs/deploy
cluster=alpha
environment=core
app_v=1.0.1
argo_v=2.4.8
nginx_v=1.2.1
argo_ns=adak8s-argocd
nginx_ns=adak8s-nginx
vault_ns=edsf-vault
rm -rf $WORK_DIR/$OUTPUT_DIR;
git clone $OVERLAY_REPO -b adak8s-deploy --recursive $OUTPUT_DIR

kubectl patch storageclass gp2 -p '{"metadata": {"annotations":{"storageclass.kubernetes.io/is-default-class":"false"}}}'

### Create Namspaces ###
echo "***************************";
echo "***  Create Namespaces  ***";
echo "***************************";
kubectl create namespace $argo_ns --dry-run=client -o yaml | kubectl apply -f - ;
kubectl create namespace $nginx_ns --dry-run=client -o yaml | kubectl apply -f - ;

f_wait 5;

### Create CRDS ###
echo ""
echo "***************************";
echo "****  Create ArgoCRDS  ****";
echo "***************************";
kubectl apply -k $OUTPUT_DIR/manifest/aasynccrds/argocd;

f_wait 5;

### Apply Secrets into cluster ###
echo ""
echo "***************************";
echo "*****  Import Secret  *****";
echo "***************************";
aws secretsmanager get-secret-value --secret-id dbs-ada/argocd/gitcred-ssh-allrepos --output text --query 'SecretString' | kubectl apply -n $argo_ns -f - &&
aws secretsmanager get-secret-value --secret-id dbs-ada/argocd/vault-cred --output text --query 'SecretString' | kubectl apply -n $argo_ns -f -

kubectl create namespace $vault_ns --dry-run=client -o yaml | kubectl apply -n $vault_ns -f - ;
aws secretsmanager get-secret-value --secret-id dbs-ada/vault/vault-cred --output text --query 'SecretString' | kubectl apply -n $vault_ns -f - &&
aws secretsmanager get-secret-value --secret-id dbs-ada/vault/storage-secrets --output text --query 'SecretString' | kubectl apply -n $vault_ns -f -
f_wait 5;

### Deploy Nginx ###
echo ""
echo "***************************";
echo "*****  Deploy Nginx   *****";
echo "***************************";
kustomize build $OUTPUT_DIR/overlays/$cluster/$environment/adak8s/nginx | kubectl apply -n $nginx_ns -f - &&
kubectl wait -n $nginx_ns \
  --for=condition=Ready pod \
  --selector=app.kubernetes.io/name=ingress-nginx,app.kubernetes.io/component=controller,app.kubernetes.io/instance=ingress-nginx \
  --timeout=180s

f_wait 5;

### Deploy Argocd ###
echo ""
echo "***************************";
echo "*****  Deploy ArgoCD  *****";
echo "***************************";
kustomize build $OUTPUT_DIR/overlays/$cluster/$environment/adak8s/argocd | kubectl apply -n $argo_ns -f - &&
kubectl wait -n $argo_ns \
  --for=condition=Ready pod \
  --selector=app.kubernetes.io/name=argocd-server \
  --timeout=180s;

f_wait 30;

### Create App of App ###
echo ""
echo "***************************";
echo "***  Create App of App ****";
echo "***************************";
helm template $OUTPUT_DIR/manifest/aasyncapp/$app_v \
  --values $OUTPUT_DIR/overlays/$cluster/$environment/adak8s/aasyncapp/values.yaml \
  --values $OUTPUT_DIR/overlays/$cluster/$environment/adak8s/aasyncapp/values-tenants.yaml \
  --values $OUTPUT_DIR/overlays/$cluster/$environment/adak8s/aasyncapp/values-bootstrap.yaml \
  | kubectl apply -n $argo_ns -f -

# helm template $OUTPUT_DIR/manifest/aasyncapp/$app_v \
#   --values $OUTPUT_DIR/overlays/$cluster/$environment/adak8s/aasyncapp/values-tools.yaml \
#   --values $OUTPUT_DIR/overlays/$cluster/$environment/adak8s/aasyncapp/values-tenants.yaml \
#   | kubectl apply -n $argo_ns -f -
# #kustomize build $OUTPUT_DIR/schema/argocd/application | kubectl apply -n $argo_ns -f -

rm -rf $WORK_DIR/$OUTPUT_DIR;
f_printEndTime;
