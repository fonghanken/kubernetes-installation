#!/usr/bin/env bash
source functions.sh;
DATE_NOW=$(date +%s)

COREENV=core
MAINTNT=adak8s
ARGONAME=argocd
APPNAME=app

echo "***************************";
echo "***  Disable ArgoSync  ****";
echo "***************************";
kubectl patch app $COREENV-$MAINTNT-$APPNAME -n$MAINTNT-$ARGONAME --type='json' -p='[{"op": "remove", "path": "/spec/syncPolicy/automated"}]' &&
kubectl get app -n$MAINTNT-$ARGONAME -oname | grep -Ev "$COREENV-$MAINTNT-$APPNAME" | xargs -I{} kubectl patch {} -n$MAINTNT-$ARGONAME --type='json' -p='[{"op": "remove", "path": "/spec/syncPolicy/automated"}]'
kubectl get app -n$MAINTNT-$ARGONAME -oname | xargs -I{} kubectl patch {} -n$MAINTNT-$ARGONAME --type='json' -p='{"metadata": {"finalizers": ["resources-finalizer.argocd.argoproj.io"]}}' --type merge
f_wait 5

echo "";
echo "***************************";
echo "****  Delete ArgoApp  *****";
echo "***************************";
kubectl delete app --all -n$MAINTNT-$ARGONAME --wait=false
f_wait 5

echo "";
echo "***************************";
echo "****  Delete ArgoProj  ****";
echo "***************************";
kubectl delete appproj --all -n$MAINTNT-$ARGONAME --wait=false
f_wait 5

echo "";
echo "***************************";
echo "****  Delete PVolumes  ****";
echo "***************************";
kubectl delete pvc --all -A --wait=false
kubectl delete pv --all --wait=false
f_wait 5

echo "";
echo "***************************";
echo "****  Delete All CRDS  ****";
echo "***************************";
kubectl delete crds --all --wait=false
kubectl delete apiservices v1beta1.metrics.k8s.io
kubectl delete apiservices v1beta1.custom.metrics.k8s.io
f_wait 5

echo "";
echo "***************************";
echo "****  Delete All Pods  ****";
echo "***************************";
kubectl get ns --no-headers | grep -Ev "kube-|default|$MAINTNT-$ARGONAME" | awk '{ print $1 }' | xargs -I{} kubectl delete pods --all --force -n{}
f_wait 5

echo "";
echo "***************************";
echo "****  Patch App/Projs  ****";
echo "***************************";
kubectl get app -n$MAINTNT-$ARGONAME -oname | xargs -I{} kubectl patch {} -n$MAINTNT-$ARGONAME --type='json' -p='[{"op": "remove", "path": "/metadata/finalizers"}]'
kubectl get appproj -n$MAINTNT-$ARGONAME -oname | xargs -I{} kubectl patch {} -n$MAINTNT-$ARGONAME --type='json' -p='[{"op": "remove", "path": "/metadata/finalizers"}]'
f_wait 5

echo "";
echo "***************************";
echo "*****  Delete All NS  *****";
echo "***************************";
kubectl get ns -oname | grep -Ev 'kube-|default' | xargs kubectl delete
f_printEndTime;