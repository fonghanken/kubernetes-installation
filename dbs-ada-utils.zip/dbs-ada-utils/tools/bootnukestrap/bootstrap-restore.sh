#!/usr/bin/env bash
set -e
source functions.sh;
DATE_NOW=$(date +%s)

WORK_DIR=$(pwd)
OVERLAY_REPO=git@github.com:Versent/dbs-ada.git
OUTPUT_DIR=outputs/deploy
CLSR=$1
ENVT=core
RSTR=$2
V_APP=1.0.1
NAME_APP=aasyncapp
NAME_HELM=helmofapp
TNT_EDSF=edsf
TNT_AK8S=adak8s
NS_ARG=$TNT_AK8S-argocd
NS_NGX=$TNT_AK8S-nginx
NS_VLT=$TNT_EDSF-vault
NS_AWF=$TNT_AK8S-argowf
NS_TDB=$TNT_AK8S-tidb
NS_RMQ=$TNT_AK8S-rabbitmq

if [ -z "$CLSR" ]; then
    CLSR=alpha
fi
if [ -z "$RSTR" ]; then
    RSTR=false;
fi

rm -rf $WORK_DIR/$OUTPUT_DIR;
git clone $OVERLAY_REPO -b adak8s-deploy --recursive $OUTPUT_DIR

### Create Namspaces ###
echo "***************************";
echo "***  Create Namespaces  ***";
echo "***************************";
kubectl create namespace $NS_ARG --dry-run=client -o yaml | kubectl apply -f - ;
kubectl create namespace $NS_NGX --dry-run=client -o yaml | kubectl apply -f - ;
# kubectl create namespace $NS_VLT --dry-run=client -o yaml | kubectl apply -f - ;
# kubectl create namespace $NS_AWF --dry-run=client -o yaml | kubectl apply -f - ;
# kubectl create namespace $NS_TDB --dry-run=client -o yaml | kubectl apply -f - ;
# kubectl create namespace $NS_RMQ --dry-run=client -o yaml | kubectl apply -f - ;

f_wait 5;

### Create CRDS ###
echo ""
echo "***************************";
echo "****  Create ArgoCRDS  ****";
echo "***************************";
kubectl apply -k $OUTPUT_DIR/manifest/aasynccrds/argocd;

f_wait 5;

### Apply Secrets into cluster ###
echo ""
echo "***************************";
echo "*****  Import Secret  *****";
echo "***************************";
aws secretsmanager get-secret-value --secret-id dbs-ada/argocd/gitcred-ssh-allrepos --output text --query 'SecretString' | kubectl apply -n $NS_ARG -f - &&
aws secretsmanager get-secret-value --secret-id dbs-ada/argocd/vault-cred --output text --query 'SecretString' | kubectl apply -n $NS_ARG -f -

if [ "$CLSR" != "bigcluster" ]; then
  kubectl create namespace $NS_VLT --dry-run=client -o yaml | kubectl apply -f - &&
  aws secretsmanager get-secret-value --secret-id dbs-ada/vault/vault-cred --output text --query 'SecretString' | kubectl apply -n $NS_VLT -f - &&
  aws secretsmanager get-secret-value --secret-id dbs-ada/vault/storage-secrets --output text --query 'SecretString' | kubectl apply -n $NS_VLT -f -;
fi
f_wait 5;

### Deploy Nginx ###
echo ""
echo "***************************";
echo "*****  Deploy Nginx   *****";
echo "***************************";
kustomize build $OUTPUT_DIR/overlays/$CLSR/$ENVT/$TNT_AK8S/nginx | kubectl apply -n $NS_NGX -f - &&
kubectl wait -n $NS_NGX \
  --for=condition=Ready pod \
  --selector=app.kubernetes.io/name=ingress-nginx,app.kubernetes.io/component=controller,app.kubernetes.io/instance=ingress-nginx \
  --timeout=180s

f_wait 5;

### Deploy Argocd ###
echo ""
echo "***************************";
echo "*****  Deploy ArgoCD  *****";
echo "***************************";
kustomize build $OUTPUT_DIR/overlays/$CLSR/$ENVT/$TNT_AK8S/argocd | kubectl apply -n $NS_ARG -f - &&
kubectl wait -n $NS_ARG \
  --for=condition=Ready pod \
  --selector=app.kubernetes.io/name=argocd-server \
  --timeout=180s;

f_wait 5;

# Bootstrapping Resources
echo ""
echo "***************************";
echo "** Generate Helm Template *";
echo "***************************";
helm template $OUTPUT_DIR/manifest/$NAME_APP/$V_APP \
	--values $OUTPUT_DIR/overlays/$CLSR/$ENVT/$TNT_AK8S/$NAME_APP/values-tools.yaml \
	--values $OUTPUT_DIR/overlays/$CLSR/$ENVT/$TNT_AK8S/$NAME_APP/values.yaml \
	--values $OUTPUT_DIR/overlays/$CLSR/$ENVT/$TNT_AK8S/$NAME_APP/values-tenants.yaml  > $OUTPUT_DIR/$NAME_HELM.yaml \
  && echo "Successfully generated helm" || echo "Failed to generate helm"

echo ""
echo "***************************";
echo "******  Create Apps  ******";
echo "***************************";
# Remove default from gp2
kubectl patch storageclass gp2 -p '{"metadata": {"annotations":{"storageclass.kubernetes.io/is-default-class":"false"}}}' || true

# Storage Class
yq 'select(.kind=="StorageClass") | select(.metadata.name=="'$TNT_AK8S'-sc")' \
  $OUTPUT_DIR/$NAME_HELM.yaml | kubectl apply -f -;

# AppProject Resource
yq 'select(.kind=="AppProject") | select(.metadata.name=="'$TNT_AK8S'" or .metadata.name=="'$TNT_EDSF'")' \
  $OUTPUT_DIR/$NAME_HELM.yaml | kubectl apply -n $NS_ARG -f -;

# CRD Resource
yq 'select(.kind=="Application") | select(.metadata.name=="aasynccrds")' \
  $OUTPUT_DIR/$NAME_HELM.yaml | kubectl apply -n $NS_ARG -f -;

if [ "$CLSR" != "bigcluster" ]; then
  # Vault Resource
  yq 'select(.kind=="Application" or .kind=="Namespace") | select(.metadata.name|test("'$TNT_EDSF'-vault"))' \
    $OUTPUT_DIR/$NAME_HELM.yaml | kubectl apply -n $NS_ARG -f -;
  f_wait 5;
  kubectl wait app/$ENVT-$TNT_EDSF-vault -n$NS_ARG \
    --for=jsonpath='{.status.operationState.phase}'=Succeeded \
    --timeout=180s;
  kubectl wait -n $NS_VLT \
    --for=condition=Ready pod \
    --selector=app.kubernetes.io/instance=$ENVT-$TNT_EDSF-vault,app.kubernetes.io/name=vault  \
    --timeout=180s;
fi

# AVP Resource
yq 'select(.kind=="Application") | select(.metadata.name=="aasyncavp")' \
  $OUTPUT_DIR/$NAME_HELM.yaml | kubectl apply -n $NS_ARG -f -;
kubectl wait app/aasyncavp -n$NS_ARG \
  --for=jsonpath='{.status.operationState.phase}'=Succeeded \
  --timeout=180s;

# ArgoWF Resource
yq 'select(.kind=="Application" or .kind=="Namespace") | select(.metadata.name|test("'$TNT_AK8S'-argowf"))' \
  $OUTPUT_DIR/$NAME_HELM.yaml | kubectl apply -n $NS_ARG -f -;
f_wait 5;
kubectl wait app/$ENVT-$TNT_AK8S-argowf -n$NS_ARG \
  --for=jsonpath='{.status.operationState.phase}'=Succeeded \
  --timeout=180s;
kubectl wait -n $NS_AWF \
  --for=condition=Ready pod \
  --selector=app.kubernetes.io/instance=$ENVT-$TNT_AK8S-argowf,app.kubernetes.io/name=argo-workflows-server  \
  --timeout=180s;
  
# TiDB Resource
yq 'select(.kind=="Application" or .kind=="Namespace") | select(.metadata.name|test("'$TNT_AK8S'-tidb"))' \
  $OUTPUT_DIR/$NAME_HELM.yaml | kubectl apply -n $NS_ARG -f -;
f_wait 5;
kubectl wait app/$ENVT-$TNT_AK8S-tidb -n$NS_ARG \
  --for=jsonpath='{.status.operationState.phase}'=Succeeded \
  --timeout=180s;
kubectl wait -n $NS_TDB \
  --for=condition=Ready pod \
  --selector=app.kubernetes.io/instance=$ENVT-$TNT_AK8S-tidb,app.kubernetes.io/name=tidb-cluster,app.kubernetes.io/component=tidb  \
  --timeout=180s;

# RabbitMQ Resource
yq 'select(.kind=="Application" or .kind=="Namespace") | select(.metadata.name|test("'$TNT_AK8S'-rabbitmq"))' \
  $OUTPUT_DIR/$NAME_HELM.yaml | kubectl apply -n $NS_ARG -f -;
f_wait 5;
kubectl wait app/$ENVT-$TNT_AK8S-rabbitmq -n$NS_ARG \
  --for=jsonpath='{.status.operationState.phase}'=Succeeded \
  --timeout=180s;
kubectl wait -n $NS_RMQ \
  --for=condition=Ready pod \
  --selector=app.kubernetes.io/instance=$ENVT-$TNT_AK8S-rabbitmq,app.kubernetes.io/name=rabbitmq  \
  --timeout=180s;

### Create App of App ###
echo ""
echo "***************************";
echo "***  Create App of App  ***";
echo "***************************";
yq 'select(.kind=="Application") | select(.metadata.name=="aasyncapp")' \
  $OUTPUT_DIR/$NAME_HELM.yaml | kubectl apply -n $NS_ARG -f -;

# helm template $OUTPUT_DIR/manifest/$NAME_APP/$V_APP \
#   --values $OUTPUT_DIR/overlays/$CLSR/$ENVT/$TNT_AK8S/$NAME_APP/values-tools.yaml \
#   --values $OUTPUT_DIR/overlays/$CLSR/$ENVT/$TNT_AK8S/$NAME_APP/values-tenants.yaml \
#   | kubectl apply -n $NS_ARG -f -
# #kustomize build $OUTPUT_DIR/schema/argocd/application | kubectl apply -n $NS_ARG -f -

if [ "$RSTR" == "true" ]; then
  kubectl wait -n $NS_AWF \
  --for=condition=Ready pod \
  --selector=app.kubernetes.io/instance=$ENVT-$TNT_AK8S-argowf,app.kubernetes.io/name=argo-workflows-server \
  --timeout=180s;
  echo "***************************";
  echo "****  Rabbimq Restore  ****";
  echo "***************************";
  ARGO_URL=https://argowf.dev.ada.dbs-sandbox.versent-innovation.au1.staxapp.cloud &&
  RMQ_NS_NAME=adak8s-rabbitmq &&
  RMQ_WFTEMPLATE_NAME=rabbitmq-backup-restore

  kubectl wait workflowtemplate/$RMQ_WFTEMPLATE_NAME --for=jsonpath='{.metadata.name}'=$RMQ_WFTEMPLATE_NAME --timeout=180s -n$RMQ_NS_NAME
  ### Submit Workflow Template
  RMQ_WF_NAME=$(curl -skX POST -H 'content-type: application/json' $ARGO_URL/api/v1/workflows/$RMQ_NS_NAME/submit \
    --data '{ 
      "resourceKind": "WorkflowTemplate",
      "namespace": "'$RMQ_NS_NAME'",
      "resourceName": "'$RMQ_WFTEMPLATE_NAME'",
      "submitOptions": {
          "parameters": ["action=RESTORE","backupFilename=latest_definition.json"]}
    }' | jq -r '.metadata.name')

  kubectl wait --for=jsonpath='{.status.phase}'=Succeeded --timeout=180s workflow/$RMQ_WF_NAME -n$RMQ_NS_NAME && 
  RMQ_BACKUP_STATUS=$(kubectl get workflow/$RMQ_WF_NAME -n$RMQ_NS_NAME -ojsonpath={.status.phase})

  echo ""
  echo "***************************";
  echo "******  TiDB Restore  *****";
  echo "***************************";
  TDB_NS_NAME=adak8s-tidb &&
  TDB_WFTEMPLATE_NAME=tidb-restore-full-wf-template &&

  kubectl wait workflowtemplate/$TDB_WFTEMPLATE_NAME --for=jsonpath='{.metadata.name}'=$TDB_WFTEMPLATE_NAME --timeout=180s -n$TDB_NS_NAME
  ### Submit Workflow Template
  TDB_WF_NAME=$(curl -skX POST -H 'content-type: application/json' --url $ARGO_URL/api/v1/workflows/$TDB_NS_NAME/submit \
    --data '{ 
      "resourceKind": "WorkflowTemplate",
      "namespace": "'$TDB_NS_NAME'",
      "resourceName": "'$TDB_WFTEMPLATE_NAME'",
      "submitOptions": {
          "parameters": ["action=RESTORE","backupFilename=latest_definition.json"]}
    }' | jq -r '.metadata.name')

  kubectl wait --for=jsonpath='{.status.phase}'=Succeeded --timeout=180s workflow/$TDB_WF_NAME -n$TDB_NS_NAME && 
  TDB_BACKUP_STATUS=$(kubectl get workflow/$TDB_WF_NAME -n$TDB_NS_NAME -ojsonpath={.status.phase})

  echo ""
  echo "***************************";
  echo "***  Restore Completed  ***";
  echo "***************************";
  echo "RMQ - $RMQ_WF_NAME: $RMQ_BACKUP_STATUS"
  echo "TDB - $TDB_WF_NAME: $TDB_BACKUP_STATUS"
fi

rm -rf $WORK_DIR/$OUTPUT_DIR;
f_printEndTime;