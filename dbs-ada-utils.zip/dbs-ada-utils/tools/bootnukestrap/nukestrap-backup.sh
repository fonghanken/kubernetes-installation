#!/usr/bin/env bash
set -e
source functions.sh;
DATE_NOW=$(date +%s)

COREENV=core
MAINTNT=adak8s
ARGONAME=argocd
APPNAME=app
BACKUP=$1

if [ "$BACKUP" == "true" ]; then
  ARGO_URL=https://argowf.dev.ada.dbs-sandbox.versent-innovation.au1.staxapp.cloud &&
  RMQ_NS_NAME=adak8s-rabbitmq &&
  RMQ_WFTEMPLATE_NAME=rabbitmq-backup-restore

  echo "***************************";
  echo "****  Rabbimq Backup  *****";
  echo "***************************";
  ### Submit Workflow Template
  RMQ_WF_NAME=$(curl -skX POST -H 'content-type: application/json' $ARGO_URL/api/v1/workflows/$RMQ_NS_NAME/submit \
    --data '{ 
      "resourceKind": "WorkflowTemplate",
      "namespace": "'$RMQ_NS_NAME'",
      "resourceName": "'$RMQ_WFTEMPLATE_NAME'",
      "submitOptions": {
          "parameters": ["action=BACKUP"]}
    }' | jq -r '.metadata.name')

  kubectl wait --for=jsonpath='{.status.phase}'=Succeeded --timeout=180s workflow/$RMQ_WF_NAME -n$RMQ_NS_NAME; 
  RMQ_BACKUP_STATUS=$(kubectl get workflow/$RMQ_WF_NAME -n$RMQ_NS_NAME -ojsonpath={.status.phase})

  echo ""
  echo "***************************";
  echo "******  TiDB Backup  ******";
  echo "***************************";
  TDB_NS_NAME=adak8s-tidb &&
  TDB_WFTEMPLATE_NAME=tidb-backup-full-wf-template &&

  ### Submit Workflow Template
  TDB_WF_NAME=$(curl -skX POST -H 'content-type: application/json' --url $ARGO_URL/api/v1/workflows/$TDB_NS_NAME/submit \
    --data '{ 
      "resourceKind": "WorkflowTemplate",
      "namespace": "'$TDB_NS_NAME'",
      "resourceName": "'$TDB_WFTEMPLATE_NAME'",
      "submitOptions": {
          "parameters": ["backupname=latest"]}
    }' | jq -r '.metadata.name')

  kubectl wait --for=jsonpath='{.status.phase}'=Succeeded --timeout=180s workflow/$TDB_WF_NAME -n$TDB_NS_NAME;
  TDB_BACKUP_STATUS=$(kubectl get workflow/$TDB_WF_NAME -n$TDB_NS_NAME -ojsonpath={.status.phase})

  echo ""
  echo "***************************";
  echo "*****  Backup Status  *****";
  echo "***************************";
  echo "RMQ - $RMQ_WF_NAME: $RMQ_BACKUP_STATUS"
  echo "TDB - $TDB_WF_NAME: $TDB_BACKUP_STATUS"
fi

if [ "$RMQ_BACKUP_STATUS" == "Succeeded" ] && [ "$TDB_BACKUP_STATUS" == "Succeeded" ]; then
  echo ""
  echo "***************************";
  echo "***  Disable ArgoSync  ****";
  echo "***************************";
  kubectl patch app aasyncapp -n$MAINTNT-$ARGONAME --type='json' -p='[{"op": "remove", "path": "/spec/syncPolicy/automated"}]' &&
  kubectl get app -n$MAINTNT-$ARGONAME -oname | grep -Ev "aasyncapp" | xargs -I{} kubectl patch {} -n$MAINTNT-$ARGONAME --type='json' -p='[{"op": "remove", "path": "/spec/syncPolicy/automated"}]'
  kubectl get app -n$MAINTNT-$ARGONAME -oname | xargs -I{} kubectl patch {} -n$MAINTNT-$ARGONAME --type='json' -p='{"metadata": {"finalizers": ["resources-finalizer.argocd.argoproj.io"]}}' --type merge
  f_wait 5

  echo "";
  echo "***************************";
  echo "****  Delete ArgoApp  *****";
  echo "***************************";
  kubectl delete app --all -n$MAINTNT-$ARGONAME --wait=false
  f_wait 5

  echo "";
  echo "***************************";
  echo "****  Delete ArgoProj  ****";
  echo "***************************";
  kubectl delete appproj --all -n$MAINTNT-$ARGONAME --wait=false
  f_wait 5

  echo "";
  echo "***************************";
  echo "****  Delete PVolumes  ****";
  echo "***************************";
  kubectl delete pvc --all -A --wait=false
  kubectl delete pv --all --wait=false
  f_wait 5

  echo "";
  echo "***************************";
  echo "****  Delete All CRDS  ****";
  echo "***************************";
  kubectl delete crds --all --wait=false
  kubectl delete apiservices v1beta1.metrics.k8s.io
  kubectl delete apiservices v1beta1.custom.metrics.k8s.io
  f_wait 5

  echo "";
  echo "***************************";
  echo "****  Delete All Pods  ****";
  echo "***************************";
  kubectl get ns --no-headers | grep -Ev "kube-|default|$MAINTNT-$ARGONAME" | awk '{ print $1 }' | xargs -I{} kubectl delete pods --all --force -n{}
  f_wait 5

  echo "";
  echo "***************************";
  echo "****  Patch App/Projs  ****";
  echo "***************************";
  kubectl get app -n$MAINTNT-$ARGONAME -oname | xargs -I{} kubectl patch {} -n$MAINTNT-$ARGONAME --type='json' -p='[{"op": "remove", "path": "/metadata/finalizers"}]'
  kubectl get appproj -n$MAINTNT-$ARGONAME -oname | xargs -I{} kubectl patch {} -n$MAINTNT-$ARGONAME --type='json' -p='[{"op": "remove", "path": "/metadata/finalizers"}]'
  f_wait 5

  echo "";
  echo "***************************";
  echo "*****  Delete All NS  *****";
  echo "***************************";
  kubectl get ns -oname | grep -Ev 'kube-|default' | xargs kubectl delete
else
  echo "";
  echo "Backup Failed ---> Stopping Destruction"
fi
f_printEndTime;