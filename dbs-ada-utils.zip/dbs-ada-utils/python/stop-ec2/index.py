import os
import boto3

_region_name = os.getenv("AWS_REGIONS")
_tag_key = os.getenv("TAG_KEY")
_tag_value = os.getenv("TAG_VALUE")

def extract_name_tag(tags):
    return [tag['Value'] for tag in tags if tag['Key'] == 'Name'][0]

def lambda_handler(event, context):
    # Start
    print("-- Environment Variables --")
    print(f'AWS_REGIONS : {_region_name}')
    print(f'TAG_KEY     : {_tag_key}')
    print(f'TAG_VALUE   : {_tag_value}')
    print("-- start --")
    ec2 = boto3.client("ec2", region_name=_region_name)
    asg = boto3.client("autoscaling", region_name=_region_name)

    # Existing State - EC2s
    ec2_instances = ec2.describe_instances(
        Filters=[
            {
                'Name': f'tag:{_tag_key}',
                'Values': [_tag_value]
            },
            {
                'Name': 'instance-state-name',
                'Values': ['running']
            }
        ])
    print(f"EC2 Instances: {len(ec2_instances['Reservations'])}")
    ec2_instances_flattened = [ec2_instance for ec2_reservations in ec2_instances['Reservations'] for ec2_instance in ec2_reservations['Instances']]
    for ec2_instance in ec2_instances_flattened:
        ec2_tags = ec2_instance['Tags']
        ec2_id = ec2_instance['InstanceId']
        print(f'{ec2_id} /// {extract_name_tag(ec2_tags)}')
    
    # Existing State - ASGs
    autoscaling_groups = asg.describe_auto_scaling_groups(
        Filters=[
            {
                'Name': f'tag:{_tag_key}',
                'Values': [_tag_value]
            }
        ]
    )
    print(f"Auto Scaling Groups: {len(autoscaling_groups['AutoScalingGroups'])}")
    for autoscaling_group in autoscaling_groups['AutoScalingGroups']:
        asg_name = autoscaling_group['AutoScalingGroupName']
        print(f"{asg_name}")
    
    # Change Stage - ASGs
    for autoscaling_group in autoscaling_groups['AutoScalingGroups']:
        autoscaling_group_name = autoscaling_group['AutoScalingGroupName']
        print(f'Suspending process in ASG ({autoscaling_group_name})')
        suspend_response = asg.suspend_processes(
            AutoScalingGroupName=autoscaling_group_name,
            ScalingProcesses=[
                'HealthCheck',
                'Terminate'
            ]
        )
        print(suspend_response)

    # Change Stage - EC2s
    for ec2_instance in ec2_instances_flattened:
        ec2_id = ec2_instance['InstanceId']
        print(f'Stopping EC2 Instance ({ec2_id})')
        ec2_stop_response = ec2.stop_instances(
            InstanceIds=[ec2_id]
        )
        print(ec2_stop_response)

    # End
    print("-- end --")
    return event