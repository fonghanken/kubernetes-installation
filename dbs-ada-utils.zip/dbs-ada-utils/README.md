# Terraform
Deployment instructions [here](https://versent.atlassian.net/wiki/spaces/DBS/pages/8433958989/Terraform-ing+the+AWS+Environment)

## Shared Resource `terraform/shared`
- tfstates stored locally (i.e. Git)

## Environment-specific Resource `terraform/deployments`
- tfstates stored on backend (i.e. S3)

## Known Issues
- Unable to ignore lambda's python package creation timestamp. Each developer poses a different timestamp-ed build package, resulting in overwrite.
- Resource name getting too long (i.e. alb target groups was hitting more than 32 characters)

