# JupyterHub on Kubernetes

## Architecture
![JupyterHub Architecture Diagram](images/jupyterhub-architecture.png)

Each user is provided a pod, with attached pv. After pod is in-active for a prolong period, it gets deleted. User's data is persisted by pv and becomes available on next login.
### Other Components
```{list-table}
:header-rows: 1

* - Name
  - Description
* - Image Puller, daemonset
  - Pre-loads notebook images on all nodes.
  (Hook) Pulls image upon new image in profile list.
  (Continuous) Pulls image into newly created node during node scale up.
* - Culler, deployment
  - deletes in-active pods
```

## Concepts
- Single User Storage
  - Each user is provided a pod that comes with a pv to persist their data
- User Environment
  - set of s/w packages, env vars, files, and tools, that are availble to the user upon logs in
  - how to copy files?
    - copy files from `/tmp/`
    - or use gitpuller
  - how to choose notebook environment?
    - specify notebook images under the profile list, which becomes available for user selection upon login
    - allow user to install own conda environments ??
- User Resources
  - set limites on cpu/memory
  - mount additional cache volumes
- User Storage
  - persistent storage is automatically provisioned through StorageClass
- Dedicated Node Pool for Users
  - isolation for other services to allow user pods to scale from 0 to X, and X to 0.
  - via taints/tolerations

## Notebook Images
  - Samples from [Docker Stacks](https://jupyter-docker-stacks.readthedocs.io/en/latest/index.html)
  - Binder, open-source tool that runs on K8
    - Sources a repository to:
      - build image based on requirements/environment file
      - include sourcecodes avaiable

## Considerations
- There are limits to Number of PVs allowed to be attached to a Node. Relavent as each user login corresponds to a pod with pv attachment.
- Limit-Guarantee ratios for user's pod resource requirements.