# jupyter-book toc from-project jupyterbook -f jb-book > jupyterbook/_toc.yml
# sed -I '' -e 's/- file\: README.*$//g' jupyterbook/_toc.yml
jupyter-book clean jupyterbook/
jupyter-book build jupyterbook/ -q