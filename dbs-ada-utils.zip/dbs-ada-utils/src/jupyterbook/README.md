## Purpose
Python with jupyterbook to build markdown/notebook files into html

## Building the Image
```
docker build -t public.ecr.aws/e7y4y7w2/py-jupyterbook:v1.0 .

aws ecr-public get-login-password --region us-east-1 | docker login --username AWS --password-stdin public.ecr.aws
docker push public.ecr.aws/e7y4y7w2/py-jupyterbook:v1.0
```

### Jupyterbook (local development)
1. Host the site locally (http://localhost:8080/) with docker.
```
docker run -dit --name jupyterbook-dev -p 8080:80 -v "$PWD/jupyterbook/_build/html":/usr/local/apache2/htdocs/ httpd:2.4.53-alpine
```
1. Update the `_toc.yml` to include new content
1. Rebuild the site
```
jupyter-book clean jupyterbook/
jupyter-book build jupyterbook/ -q
```