# Image Registry

| Name | Tags | Description |
|---|---|---|
| adak8s/http-receiver | `v1.0`<br>- includes custom executable | Trino needing sidecar to redirect HTTR events to STDOUT |
| adak8s/jenkins |  | Jenkins base image |
| adak8s/jupyterbook | `v1.0`<br>- includes Jupyterbook executable | Jupyterbook base image |
| adak8s/tidb-tools | `debian-v5.4.0`<br>- includes tidb-enterprise-tools | Tooling for TiDB backup and restore |
| apache/airflow | `v2.2.3-ada1`<br>- includes Java<br>- includes Airflow Provider for Spark<br>`2.2.3-ada2`<br>- pip installs w/o cache<br>- includes Airflow Provider for Trino <br>`2.2.3-ada3`<br>- undos pip install w/o cache <br>- includes jars for S3 connectivity | Airflow requiring additional modules |
| apache/superset |  |  |
| bitnami/spark | `3.2.1-ada`<br>- includes jars for S3 connectivity | Spark pod needing access to Hadoop/S3 |
| jupyter/all-spark-notebook | `2022-04-24-ada1`<br>- includes jars for S3 connectivity | Spark notebook needing access to Hadoop/S3 |