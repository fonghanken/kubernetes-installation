# Access to kubernetes cluster –

1.	Connect to the Bastion server[Use Git Bash or Putty]
> ssh -p64022 adak8s1@10.52.14.52
2.	Connect to the Kubernetes master node
> ssh x01tadapoc65a -p64022
3.	> Su root  [password is same as the hostname]
4.	> Kubectl get nodes

NOTE: We can access the cluster from the Bastion server too. 
      There are other cluster configs in the server. 
      So we can check with the teams before adding one more context to the kube config in the bastion server. 
