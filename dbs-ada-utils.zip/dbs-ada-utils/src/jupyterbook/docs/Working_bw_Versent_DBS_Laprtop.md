# Working between Versent and DBS Laptops

## List of tools needed to work in Versent Laptop
1.	GitHub Repo in the Versent organisation.
https://github.com/Versent/dbs-ada
2.	Kubernetes – Local machine or in Versent environment.
3.	S3 Bucket – Versent Stax account.   
    Account id - Innovation 1   
    Bucket - dbs-versent-ada

## How to get Versent GitHub Repositories to sync with DBS Bitbucket
1.	Push all your changes to the Versent GitHub Repo from Versent laptop.
https://github.com/Versent/dbs-ada
2.	Open the GitHub repo in the DBS Laptop.
3.	Cloning the GitHub repo doesn’t work in the DBS network/laptop.
4.	Download the GitHub repo as a zip file.
5.	Unzip the file and copy your changes to the DBS Bitbucket repo.   
https://bitbucket.sgp.dbs.com:8443/dcifgit/projects/ADA_ADAK8
https://bitbucket.sgp.dbs.com:8443/dcifgit/projects/ADA_ADAK8S/repos/ada_adak8s/browse

## How to move public docker images from Versent Laptop to DBS servers
1.	Download the docker image in the Versent laptop.
> docker pull {image-name}
2.	Create a tar file of the docker image.
> docker save {image-name} > {image-name}.tar
3.	Copy the tar file to the S3 Bucket. S3 Bucket can be from your own AWS account.
4.	Open the AWS console in the DBS laptop.
5.	Download the tar file from the S3 bucket.
6.	In the Git Bash, copy the tar file to Bastion server.
> scp -P 64022 -r {tar file} adak8s1@10.52.14.52:/data/.
7.	SSH into the Bastion server.
> ssh -p64022 adak8s1@10.52.14.52
8.	Copy the tar file to the K8s Master node. Docker image tarballs are stored in the folder /data/tarballs.
> scp -P 64022 -r {tar file} x01tadapoc65a:/data/tarballs/.
9.	SSH into the Master server.
> ssh -p64022 x01tadapoc65a
10.	Load the docker image in the server.
> docker load -I /data/tarballs/{tar file}
11.	Tag the image to push to the ADA docker registry.
> docker tag {image-name}:<version> docker -registry:5000/{image-name}:{version}
> docker push docker -registry:5000/{image-name}:{version}

## How to copy files from DBS Laptop to Versent Laptop
Use the same S3 Bucket to copy only documents/files which we created.
Don’t move unless if its very important and nothing related to DBS.  
