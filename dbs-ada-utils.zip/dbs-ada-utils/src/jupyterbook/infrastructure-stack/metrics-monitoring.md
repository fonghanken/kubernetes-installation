# Metrics Monitoring
Prometheus-Thanos-Kibana

## Overview

## Prometheus
An open-source monitoring and alerting toolkit. Metrics are collected and stored in a timeseries database, along with key-value pairs called labels to help with filtering in queries.Metrics are numerical measurements that are recovered over time. They syntax used for queries is PromQL.

### Exposing Metrics for Collection
#### Metrics Exporters
Though it is possible to have metrics pushed into Prometheus, it's is often preferred to have metrics made available through a HTTP endpoint (i.e. GET /metrics) to be scraped by Prometheus. An application can be instrumented with client libraries (e.g. in Go/Java/Python/etc), or utilize (third-party exporters) [https://prometheus.io/docs/instrumenting/exporters/]. They are called metrics exporters.

#### Job Configs via Prometheus CRDs
Jobs are then configured to define where and how the metrics are pulled. Configuration includes the endpoint, port, scrape intervals, and labels to be appended to the metrics. This has been made convenient using PodMonitors and ServiceMonitors, which are (Promethues CRDs)[https://github.com/prometheus-operator/prometheus-operator/blob/main/Documentation/user-guides/getting-started.md]

#### Currently Exported Metrics

```{list-table}
:header-rows: 1

* - Exporters
  - Metrics Collected
* - Kubernetes Control Plane exporters
  -
* - Node exporters
  - node-level resource utization (i.e. storage, memory, cpu)
* - Kube State Metrics
  - k8 resources utilization (i.e. storage, memory, cpu), metrics (e.g. deployment available/ready count), and status levels.
* - JMX Exporters on Trino
  - Read more [here](https://trino.io/docs/current/admin/jmx.html)
```

## Thanos
An abstraction layer over Prometheus that helps it run at scale.

It comes with a sidecar that captures and forwards metrics from the Prometheus server to a block storage (i.e. S3) for data archival. Metrics consolidated on the block storage are fronted by a querier that understands that native PromQL. The querier does the following:
1.  allows the query of present and historical metrics
2.  deduplicates metrics when Prometheus is run in high-availability mode
3.  provides a global view for a multi-cluster kubernetes setup

Thanos can be easily integrated with Prometheus, as configuration is only on Thanos. Prometheus has no awareness of Thanos abstraction layer.

### Components
![Thanos High Level Diagram](images/thanos-high-level-diagram.png)
Other components that supports the system includes:
- Store Gateway - the interfaces to the block storage
- Compacter - that routinely compacts and downsamples the metrics on the block storage
- Query frontend - caching of queries. visualisation tools (i.e. Grafana) should use this a source instead of directly to Thanos Query


