# Policy Mangement

## Overview

Policy management helps us tackle day 2 problems. Platform teams aims to provide a secure, compliant, infrastructure to application teams. Application teams need to interact with the infrastructure safely. Policy managements comes in by putting in place guardrails that prevents non-compliance and guides development teams with policy report messages.

## Kyverno
CNCF Project at Sandbox project maturity level.

Kyverno is a policy engine designed for Kubernetes. With Kyverno, policies are managed as Kubernetes resources and no new language is required to write policies. This allows using familiar tools such as kubectl, git, and kustomize to manage policies. Kyverno policies can validate, mutate, and generate Kubernetes resources plus ensure OCI image supply chain security.
