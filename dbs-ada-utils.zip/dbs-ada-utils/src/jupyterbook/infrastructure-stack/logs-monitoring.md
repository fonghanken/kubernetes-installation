# Logs Monitroing

## Overview

For a good introduction to cluster-level logging can be read [here](https://kubernetes.io/docs/concepts/cluster-administration/logging/).

A node-level logging agent that runs on every node is what is use for log collection. Both container-level logs and node-level logs are collected.

- Node-level logs
  - Mouting to `/var/log/journal`
  - Includes logs for kubedns, and kubelet
- Container-level logs
  - Mounting to `/var/log/containers/`
  - Include logs for all containers, and kubeproxy

## Architecture Diagram
![EFK Architecture Diagram](images/efk-diagram.png)

- FluentBit - Deployed as a DaemonSet on each Node. Collects all logs
- FluentD -  Receives logs from FluentBit, parses and transforms them. Forwards to to ElasticSearch
- ElasticSearch - Receives and stores logs in Indexes.
- Kibana - Uses ElasticSearch as the data source

### Note
- `tail` input plugin on FluentBit
  - To avoid picking up logs from FluentBit as this would lead to a loopback
  - To avoid picking up rotated logs
- Buffering on FluentBit and FluentD
  - In-memory buffering is the default option used by the log shippers. It is the temporary storage used before forwarding to the next component (i.e. FluentD / ElasticSearch). There would be periods of network congestion that will result in the fill up in-memory buffers, and possibly an `Out of Memory` error if no memory limits are absent. Buffering to file should be enabled, so data safety can be guranteed.
  - More information (here)[https://docs.fluentbit.io/manual/administration/buffering-and-storage]

### FluentBit vs FluentD

```{list-table}
:header-rows: 1

* - 
  - FluentD
  - FluentBit
* - Scope
  - Containers / Servers
  - Embedded Linux / Containers / Servers
* - Languagesssss
  - C & Ruby
  - C
* - Memory
  - ~40MB
  - ~650KB
* - Performance
  - High Performance
  - High Performance
* - Dependencies
  - Built as a Ruby Gem, it requires a certain number of gems.
  - Zero dependencies, unless some special plugin requires them.
* - Plugins
  - More than 1000 plugins available
  - Around 70 plugins available
* - GitHub Stats
  - Stars: 10.9k, Contributors: 222
  - Stars: 3.3k, Contributors: 270
```