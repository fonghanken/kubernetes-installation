SET GLOBAL tidb_enable_noop_functions=1;
CREATE USER 'airflow' IDENTIFIED BY 'airflow';
GRANT ALL ON airflow.* TO 'airflow';
/*!40101 SET NAMES binary*/;
CREATE DATABASE `airflow` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci */;
/*!40101 SET NAMES binary*/;
USE airflow;
/*!40101 SET NAMES binary*/;
CREATE TABLE `ab_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci AUTO_INCREMENT=30001;
/*!40101 SET NAMES binary*/;
INSERT INTO `ab_role` VALUES
(1,'Admin'),
(2,'Public'),
(3,'Viewer'),
(4,'User'),
(5,'Op');
/*!40101 SET NAMES binary*/;
CREATE TABLE `ab_view_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci AUTO_INCREMENT=30001;
/*!40101 SET NAMES binary*/;
INSERT INTO `ab_view_menu` VALUES
(1,'Connections'),
(2,'DAGs'),
(3,'DAG Runs'),
(4,'Task Instances'),
(5,'Audit Logs'),
(6,'ImportError'),
(7,'Pools'),
(8,'Providers'),
(9,'Variables'),
(10,'XComs'),
(11,'DAG Code'),
(12,'Configurations'),
(13,'Plugins'),
(14,'Roles'),
(15,'Permissions'),
(16,'Users'),
(17,'DAG Dependencies'),
(18,'Jobs'),
(19,'My Password'),
(20,'My Profile'),
(21,'SLA Misses'),
(22,'Task Logs'),
(23,'Website'),
(24,'Browse'),
(25,'Documentation'),
(26,'Docs'),
(27,'Admin'),
(28,'Task Reschedules'),
(29,'Triggers'),
(30,'Passwords'),
(31,'IndexView'),
(32,'UtilView'),
(33,'LocaleView'),
(34,'SecurityApi'),
(35,'AuthDBView'),
(36,'List Users'),
(37,'Security'),
(38,'List Roles'),
(39,'User Stats Chart'),
(40,'User\'s Statistics'),
(41,'Base Permissions'),
(42,'View Menus'),
(43,'Views/Menus'),
(44,'Permission Views'),
(45,'Permission on Views/Menus'),
(46,'MenuApi'),
(47,'AutocompleteView'),
(48,'Airflow'),
(49,'DagDependenciesView'),
(50,'RedocView'),
(51,'DAG:simple_spark_submiter'),
(52,'DAG:tpch_query_runner'),
(53,'DAG:trino-tpcds-benchmark'),
(54,'DAG:trino-tpch-benchmark'),
(55,'DAG:simple_k8spark_submiter');
/*!40101 SET NAMES binary*/;
CREATE TABLE `ab_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci AUTO_INCREMENT=30001;
/*!40101 SET NAMES binary*/;
INSERT INTO `ab_permission` VALUES
(1,'can_read'),
(2,'can_edit'),
(3,'can_delete'),
(4,'can_create'),
(5,'menu_access'),
(6,'can_get');
/*!40101 SET NAMES binary*/;
CREATE TABLE `ab_permission_view` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permission_id` int(11) DEFAULT NULL,
  `view_menu_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `permission_id` (`permission_id`,`view_menu_id`),
  CONSTRAINT `permission_id` FOREIGN KEY (`permission_id`) REFERENCES `ab_permission` (`id`),
  CONSTRAINT `view_menu_id` FOREIGN KEY (`view_menu_id`) REFERENCES `ab_view_menu` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci AUTO_INCREMENT=30001;
/*!40101 SET NAMES binary*/;
INSERT INTO `ab_permission_view` VALUES
(1,3,1),
(2,1,1),
(3,2,1),
(4,4,1),
(5,1,2),
(6,2,2),
(7,3,2),
(8,1,3),
(9,1,4),
(10,2,4),
(11,3,3),
(12,4,3),
(13,2,3),
(14,1,5),
(15,1,6),
(16,3,7),
(17,1,7),
(18,2,7),
(19,4,7),
(20,1,8),
(21,3,9),
(22,1,9),
(23,2,9),
(24,4,9),
(25,1,10),
(26,1,11),
(27,1,12),
(28,1,13),
(29,1,14),
(30,1,15),
(31,3,14),
(32,2,14),
(33,4,14),
(34,1,16),
(35,4,16),
(36,2,16),
(37,3,16),
(38,1,17),
(39,1,18),
(40,1,19),
(41,2,19),
(42,1,20),
(43,2,20),
(44,1,21),
(45,1,22),
(46,1,23),
(47,5,24),
(48,5,17),
(49,5,3),
(50,5,25),
(51,5,26),
(52,5,18),
(53,5,5),
(54,5,13),
(55,5,21),
(56,5,4),
(57,4,4),
(58,3,4),
(59,5,27),
(60,5,12),
(61,5,1),
(62,5,7),
(63,5,9),
(64,5,10),
(65,3,10),
(66,1,28),
(67,5,28),
(68,1,29),
(69,5,29),
(70,1,30),
(71,2,30),
(72,5,36),
(73,5,37),
(74,5,38),
(75,1,39),
(76,5,40),
(77,5,41),
(78,1,42),
(79,5,43),
(80,1,44),
(81,5,45),
(82,6,46),
(83,5,8),
(84,4,10),
(85,1,51),
(86,2,51),
(87,1,52),
(88,2,52),
(89,1,53),
(90,2,53),
(91,1,54),
(92,2,54),
(93,1,55),
(94,2,55);
/*!40101 SET NAMES binary*/;
CREATE TABLE `ab_permission_view_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permission_view_id` int(11) DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `permission_view_id` (`permission_view_id`,`role_id`),
  CONSTRAINT `permission_view_id` FOREIGN KEY (`permission_view_id`) REFERENCES `ab_permission_view` (`id`),
  CONSTRAINT `role_id` FOREIGN KEY (`role_id`) REFERENCES `ab_role` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci AUTO_INCREMENT=30001;
/*!40101 SET NAMES binary*/;
INSERT INTO `ab_permission_view_role` VALUES
(1,14,3),
(2,5,3),
(3,38,3),
(4,26,3),
(5,8,3),
(6,15,3),
(7,39,3),
(8,40,3),
(9,41,3),
(10,42,3),
(11,43,3),
(12,28,3),
(13,44,3),
(14,9,3),
(15,45,3),
(16,25,3),
(17,46,3),
(18,47,3),
(19,48,3),
(20,49,3),
(21,50,3),
(22,51,3),
(23,52,3),
(24,53,3),
(25,54,3),
(26,55,3),
(27,56,3),
(28,14,4),
(29,5,4),
(30,38,4),
(31,26,4),
(32,8,4),
(33,15,4),
(34,39,4),
(35,40,4),
(36,41,4),
(37,42,4),
(38,43,4),
(39,28,4),
(40,44,4),
(41,9,4),
(42,45,4),
(43,25,4),
(44,46,4),
(45,47,4),
(46,48,4),
(47,49,4),
(48,50,4),
(49,51,4),
(50,52,4),
(51,53,4),
(52,54,4),
(53,55,4),
(54,56,4),
(55,6,4),
(56,7,4),
(57,57,4),
(58,10,4),
(59,58,4),
(60,12,4),
(61,13,4),
(62,11,4),
(63,14,5),
(64,5,5),
(65,38,5),
(66,26,5),
(67,8,5),
(68,15,5),
(69,39,5),
(70,40,5),
(71,41,5),
(72,42,5),
(73,43,5),
(74,28,5),
(75,44,5),
(76,9,5),
(77,45,5),
(78,25,5),
(79,46,5),
(80,47,5),
(81,48,5),
(82,49,5),
(83,50,5),
(84,51,5),
(85,52,5),
(86,53,5),
(87,54,5),
(88,55,5),
(89,56,5),
(90,6,5),
(91,7,5),
(92,57,5),
(93,10,5),
(94,58,5),
(95,12,5),
(96,13,5),
(97,11,5),
(98,27,5),
(99,59,5),
(100,60,5),
(101,61,5),
(102,62,5),
(103,63,5),
(104,64,5),
(105,4,5),
(106,2,5),
(107,3,5),
(108,1,5),
(109,19,5),
(110,17,5),
(111,18,5),
(112,16,5),
(113,20,5),
(114,24,5),
(115,22,5),
(116,23,5),
(117,21,5),
(118,65,5),
(119,14,1),
(120,5,1),
(121,38,1),
(122,26,1),
(123,8,1),
(124,15,1),
(125,39,1),
(126,40,1),
(127,41,1),
(128,42,1),
(129,43,1),
(130,28,1),
(131,44,1),
(132,9,1),
(133,45,1),
(134,25,1),
(135,46,1),
(136,47,1),
(137,48,1),
(138,49,1),
(139,50,1),
(140,51,1),
(141,52,1),
(142,53,1),
(143,54,1),
(144,55,1),
(145,56,1),
(146,6,1),
(147,7,1),
(148,57,1),
(149,10,1),
(150,58,1),
(151,12,1),
(152,13,1),
(153,11,1),
(154,27,1),
(155,59,1),
(156,60,1),
(157,61,1),
(158,62,1),
(159,63,1),
(160,64,1),
(161,4,1),
(162,2,1),
(163,3,1),
(164,1,1),
(165,19,1),
(166,17,1),
(167,18,1),
(168,16,1),
(169,20,1),
(170,24,1),
(171,22,1),
(172,23,1),
(173,21,1),
(174,65,1),
(175,66,1),
(176,67,1),
(177,68,1),
(178,69,1),
(179,70,1),
(180,71,1),
(181,29,1),
(182,32,1),
(183,33,1),
(184,36,1),
(185,31,1),
(186,34,1),
(187,30,1),
(188,35,1),
(189,37,1),
(190,72,1),
(191,73,1),
(192,74,1),
(193,75,1),
(194,76,1),
(195,77,1),
(196,78,1),
(197,79,1),
(198,80,1),
(199,81,1),
(200,82,1),
(201,83,1),
(202,84,1);
/*!40101 SET NAMES binary*/;
CREATE TABLE `ab_register_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(64) COLLATE utf8_general_ci NOT NULL,
  `last_name` varchar(64) COLLATE utf8_general_ci NOT NULL,
  `username` varchar(64) COLLATE utf8_general_ci NOT NULL,
  `password` varchar(256) COLLATE utf8_general_ci DEFAULT NULL,
  `email` varchar(64) COLLATE utf8_general_ci NOT NULL,
  `registration_date` datetime DEFAULT NULL,
  `registration_hash` varchar(256) COLLATE utf8_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET NAMES binary*/;
CREATE TABLE `ab_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(64) COLLATE utf8_general_ci NOT NULL,
  `last_name` varchar(64) COLLATE utf8_general_ci NOT NULL,
  `username` varchar(64) COLLATE utf8_general_ci NOT NULL,
  `password` varchar(256) COLLATE utf8_general_ci DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL,
  `email` varchar(64) COLLATE utf8_general_ci NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `login_count` int(11) DEFAULT NULL,
  `fail_login_count` int(11) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `changed_on` datetime DEFAULT NULL,
  `created_by_fk` int(11) DEFAULT NULL,
  `changed_by_fk` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `username` (`username`),
  CONSTRAINT `changed_by_fk` FOREIGN KEY (`changed_by_fk`) REFERENCES `ab_user` (`id`),
  CONSTRAINT `created_by_fk` FOREIGN KEY (`created_by_fk`) REFERENCES `ab_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci AUTO_INCREMENT=30001;
/*!40101 SET NAMES binary*/;
INSERT INTO `ab_user` VALUES
(1,'admin','admin','admin','pbkdf2:sha256:150000$Fl0Jw4hy$5d77ad8afa9f1b7060cf9d7748a8218df68ffa60a610c57f5881c859be200933',1,'admin@example.com','2022-06-02 07:59:03',1,0,'2022-06-02 07:56:22','2022-06-02 07:56:22',NULL,NULL);
/*!40101 SET NAMES binary*/;
CREATE TABLE `ab_user_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `user_id` (`user_id`,`role_id`),
  CONSTRAINT `role_id_ab_user_role` FOREIGN KEY (`role_id`) REFERENCES `ab_role` (`id`),
  CONSTRAINT `user_id_ab_user_role` FOREIGN KEY (`user_id`) REFERENCES `ab_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci AUTO_INCREMENT=30001;
/*!40101 SET NAMES binary*/;
INSERT INTO `ab_user_role` VALUES
(1,1,1);

/*!40101 SET NAMES binary*/;
CREATE TABLE `alembic_version` (
  `version_num` varchar(32) COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`version_num`) /*T![clustered_index] NONCLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET NAMES binary*/;
INSERT INTO `alembic_version` VALUES
('be2bfac3da23');
/*!40101 SET NAMES binary*/;
CREATE TABLE `celery_taskmeta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` varchar(155) COLLATE utf8_general_ci DEFAULT NULL,
  `status` varchar(50) COLLATE utf8_general_ci DEFAULT NULL,
  `result` blob DEFAULT NULL,
  `date_done` datetime DEFAULT NULL,
  `traceback` text COLLATE utf8_general_ci DEFAULT NULL,
  `name` varchar(155) COLLATE utf8_general_ci DEFAULT NULL,
  `args` blob DEFAULT NULL,
  `kwargs` blob DEFAULT NULL,
  `worker` varchar(155) COLLATE utf8_general_ci DEFAULT NULL,
  `retries` int(11) DEFAULT NULL,
  `queue` varchar(155) COLLATE utf8_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `task_id` (`task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET NAMES binary*/;
CREATE TABLE `celery_tasksetmeta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `taskset_id` varchar(155) COLLATE utf8_general_ci DEFAULT NULL,
  `result` blob DEFAULT NULL,
  `date_done` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `taskset_id` (`taskset_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET NAMES binary*/;
CREATE TABLE `connection` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `conn_id` varchar(250) COLLATE utf8_general_ci NOT NULL,
  `conn_type` varchar(500) COLLATE utf8_general_ci NOT NULL,
  `host` varchar(500) COLLATE utf8_general_ci DEFAULT NULL,
  `schema` varchar(500) COLLATE utf8_general_ci DEFAULT NULL,
  `login` varchar(500) COLLATE utf8_general_ci DEFAULT NULL,
  `password` varchar(5000) COLLATE utf8_general_ci DEFAULT NULL,
  `port` int(11) DEFAULT NULL,
  `extra` text COLLATE utf8_general_ci DEFAULT NULL,
  `is_encrypted` tinyint(1) DEFAULT NULL,
  `is_extra_encrypted` tinyint(1) DEFAULT NULL,
  `description` text COLLATE utf8_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] NONCLUSTERED */,
  UNIQUE KEY `unique_conn_id` (`conn_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci AUTO_INCREMENT=30001;
/*!40101 SET NAMES binary*/;
INSERT INTO `connection` VALUES
(1,'spark-standalone','spark','spark://spark-master-svc.spark.svc.cluster.local',NULL,NULL,NULL,7077,NULL,0,0,NULL),
(3,'spark-k8','spark','k8s://https://kubernetes.default.svc.cluster.local',NULL,NULL,NULL,443,NULL,0,0,NULL);
/*!40101 SET NAMES binary*/;
CREATE TABLE `dag` (
  `dag_id` varchar(250) COLLATE utf8_general_ci NOT NULL,
  `is_paused` tinyint(1) DEFAULT NULL,
  `is_subdag` tinyint(1) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `last_parsed_time` timestamp NULL DEFAULT NULL,
  `last_pickled` timestamp(6) NULL DEFAULT NULL,
  `last_expired` timestamp(6) NULL DEFAULT NULL,
  `scheduler_lock` tinyint(1) DEFAULT NULL,
  `pickle_id` int(11) DEFAULT NULL,
  `fileloc` varchar(2000) COLLATE utf8_general_ci DEFAULT NULL,
  `owners` varchar(2000) COLLATE utf8_general_ci DEFAULT NULL,
  `description` text COLLATE utf8_general_ci DEFAULT NULL,
  `default_view` varchar(25) COLLATE utf8_general_ci DEFAULT NULL,
  `schedule_interval` text COLLATE utf8_general_ci DEFAULT NULL,
  `root_dag_id` varchar(250) COLLATE utf8_general_ci DEFAULT NULL,
  `next_dagrun` timestamp(6) NULL DEFAULT NULL,
  `next_dagrun_create_after` timestamp(6) NULL DEFAULT NULL,
  `max_active_tasks` int(11) NOT NULL,
  `has_task_concurrency_limits` tinyint(1) NOT NULL,
  `max_active_runs` int(11) DEFAULT NULL,
  `next_dagrun_data_interval_start` timestamp(6) NULL DEFAULT NULL,
  `next_dagrun_data_interval_end` timestamp(6) NULL DEFAULT NULL,
  `has_import_errors` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`dag_id`) /*T![clustered_index] NONCLUSTERED */,
  KEY `idx_root_dag_id` (`root_dag_id`),
  KEY `idx_next_dagrun_create_after` (`next_dagrun_create_after`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET NAMES binary*/;
INSERT INTO `dag` VALUES
('simple_spark_submiter',1,0,1,'2022-06-03 03:20:19',NULL,NULL,NULL,NULL,'/opt/airflow/dags/repo/src/dags/spark_submitter_dag.py','airflow',NULL,'tree','null',NULL,NULL,NULL,16,0,16,NULL,NULL,0),
('tpch_query_runner',1,0,1,'2022-06-03 03:20:19',NULL,NULL,NULL,NULL,'/opt/airflow/dags/repo/src/dags/tpch_query_runner.py','airflow',NULL,'tree','null',NULL,NULL,NULL,16,0,16,NULL,NULL,0),
('trino-tpcds-benchmark',1,0,1,'2022-06-03 03:20:20',NULL,NULL,NULL,NULL,'/opt/airflow/dags/repo/src/dags/trino_tpcds_benchmark.py','airflow','DAG runs TPC-DS benchmark queries over Trino','tree','null',NULL,NULL,NULL,16,0,16,NULL,NULL,0),
('trino-tpch-benchmark',1,0,1,'2022-06-03 03:20:20',NULL,NULL,NULL,NULL,'/opt/airflow/dags/repo/src/dags/trino_tpch_benchmark.py','airflow','DAG runs TPCH benchmark queries over Trino','tree','null',NULL,NULL,NULL,16,0,16,NULL,NULL,0),
('simple_k8spark_submiter',1,0,1,'2022-06-03 03:20:21',NULL,NULL,NULL,NULL,'/opt/airflow/dags/repo/src/dags/k8spark_submitter_dag.py','airflow',NULL,'tree','null',NULL,NULL,NULL,16,0,16,NULL,NULL,0);
/*!40101 SET NAMES binary*/;
CREATE TABLE `dag_code` (
  `fileloc_hash` bigint(20) NOT NULL,
  `fileloc` varchar(2000) COLLATE utf8_general_ci NOT NULL,
  `source_code` mediumtext COLLATE utf8_general_ci NOT NULL,
  `last_updated` timestamp NOT NULL,
  PRIMARY KEY (`fileloc_hash`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET NAMES binary*/;
INSERT INTO `dag_code` VALUES
(567218068107241,'/opt/airflow/dags/repo/src/dags/trino_tpch_benchmark.py','\"\"\"\nExample DAG demonstrating the usage of the TaskFlow API to execute Python functions natively and within a\nvirtual environment.\n\"\"\"\n\nfrom pprint import pprint\nfrom timeit import timeit\n\nfrom airflow import DAG\nfrom airflow.utils.db import provide_session\nfrom airflow.models import XCom, Variable\nfrom airflow.decorators import task\nfrom airflow.models.baseoperator import chain\nfrom airflow.providers.trino.hooks.trino import TrinoHook\n\nimport pendulum\nfrom ada.sql_perf.common import QueryCollection\n\ntrino_benchmark_type = \'tpch\'\ntrino_tpch_benchmark_connection= Variable.get(\"trino_tpch_benchmark_connection\", default_var=None)\ntrino_tpch_benchmark_query_filter = Variable.get(\"trino_tpch_benchmark_query_filter\", default_var=None)\n\ndef trino_query(connection_id, query_statement):\n    trino = TrinoHook(\n        trino_conn_id=connection_id\n    )\n    print(f\'query statement:\\n{query_statement}\\n\')\n    query_results = trino.get_records(query_statement)\n    print(f\'query results:\\n{query_results}\\n\')\n\nwith DAG(\n    dag_id=\'trino-tpch-benchmark\',\n    description=\'DAG runs TPCH benchmark queries over Trino\',\n    schedule_interval=None,\n    start_date=pendulum.datetime(2021, 1, 1, tz=\"UTC\"),\n    catchup=False,\n    tags=[\'benchmarking\', \'tpc\', \'tpch\']\n) as dag:\n\n    task_list = []\n\n    # retrieve benchmark queries\n    qc = QueryCollection(trino_benchmark_type)\n    query_objects = qc.filter_by_selection(trino_tpch_benchmark_query_filter)\n    task_ids = [f\'benchmark_{trino_benchmark_type}_{query_object.sort_key}\' for query_object in query_objects]\n\n    for task_idx in range(len(query_objects)):\n        query_object = query_objects[task_idx]\n        task_id = task_ids[task_idx]\n        prev_task_id = task_ids[task_idx-1] if task_idx > 0 else None\n\n        @task(task_id=task_id, trigger_rule=\"all_done\")\n        def run_query(trino_connection, query_object, task_id, prev_task_id, **kwargs):\n            \"\"\"Execute query task\"\"\"\n\n            ti = kwargs[\'ti\']\n            if prev_task_id is None:\n                benchmark_results = []\n            else:\n                benchmark_results = ti.xcom_pull(key=f\'{prev_task_id}_benchmark_results\', task_ids=prev_task_id)\n\n            try:\n                execution_time = timeit(lambda: trino_query(trino_connection, query_object.statement), number=1)\n            except Exception as err:\n                execution_time = None\n                benchmark_results.append({\n                    \'query_name\': f\'{query_object.sort_key}\',\n                    \'execution_time\': execution_time\n                })\n                ti.xcom_push(key=f\'{task_id}_benchmark_results\', value=benchmark_results)\n                raise err\n            else:\n                benchmark_results.append({\n                    \'query_name\': f\'{query_object.sort_key}\',\n                    \'execution_time\': execution_time\n                })\n                ti.xcom_push(key=f\'{task_id}_benchmark_results\', value=benchmark_results)\n                    \n        query_task = run_query(trino_tpch_benchmark_connection, query_object, task_id, prev_task_id)\n        task_list.append(query_task)\n\n    @task(task_id=f\'benchmark_results\', trigger_rule=\"all_done\")\n    def print_results(prev_task_id, **kwargs):\n        \"\"\"Log benchmark results\"\"\"\n        ti = kwargs[\'ti\']\n        benchmark_results = ti.xcom_pull(key=f\'{prev_task_id}_benchmark_results\', task_ids=[prev_task_id])\n        print(f\'-- benchmark results --\')\n        print(\"{:>10} | {:<20}\".format(\'Task ID\', \'Execution Time (seconds)\'))\n        if benchmark_results:\n            for benchmark_result in benchmark_results[0]:\n                execution_time = benchmark_result[\'execution_time\'] if benchmark_result[\'execution_time\'] else \'failed\'\n                print(\"{:>10} | {:<20}\".format(benchmark_result[\'query_name\'], execution_time))\n        else:\n            print(\'no results found..\')\n        print(\'-----\')\n    task_list.append(print_results(task_ids[-1]))\n\n    @task(task_id=f\'clean_xcom\', trigger_rule=\"all_done\")\n    @provide_session\n    def cleanup_xcom(session=None, **context):     \n        dag = context[\"dag\"]\n        dag_id = dag._dag_id\n        session.query(XCom).filter(XCom.dag_id == dag_id).delete()\n    task_list.append(cleanup_xcom())\n\n    chain(*task_list)\n','2022-06-03 03:19:17'),
(25116999314156411,'/opt/airflow/dags/repo/src/dags/spark_submitter_dag.py','#\n# Licensed to the Apache Software Foundation (ASF) under one\n# or more contributor license agreements. See the NOTICE file\n# distributed with this work for additional information\n# regarding copyright ownership. The ASF licenses this file\n# to you under the Apache License, Version 2.0 (the\n# \"License\"); you may not use this file except in compliance\n# with the License. You may obtain a copy of the License at\n#\n# http://www.apache.org/licenses/LICENSE-2.0\n#\n# Unless required by applicable law or agreed to in writing,\n# software distributed under the License is distributed on an\n# \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY\n# KIND, either express or implied. See the License for the\n# specific language governing permissions and limitations\n# under the License.\n\n\"\"\"\nExample Airflow DAG to submit Apache Spark applications using\n`SparkSubmitOperator`, `SparkJDBCOperator` and `SparkSqlOperator`.\n\"\"\"\n\nfrom datetime import datetime\n\nfrom airflow.models import DAG\nfrom airflow.providers.apache.spark.operators.spark_submit import SparkSubmitOperator\n\nwith DAG(\n    dag_id=\'simple_spark_submiter\',\n    schedule_interval=None,\n    start_date=datetime(2022, 2, 22),\n    catchup=False,\n    tags=[\'example\'],\n) as dag:\n    base_config = {\n        \"task_id\":\"spark_submit\",\n        \"conn_id\":\"spark-standalone\",\n        \"application\": \"/opt/bitnami/spark/examples/jars/spark-examples_2.12-3.2.1.jar\",\n        # \"application\": \"/opt/airflow/dags/repo/src/dags/spark-examples_2.12-3.2.1.jar\",\n        \"application_args\": [\"1\"],\n        \"executor_memory\":\"512M\",\n        \"driver_memory\":\"512M\",\n        \"executor_cores\":1,\n        \"application_args\":\"10\",\n        \"java_class\": \"org.apache.spark.examples.SparkPi\"\n        #\"principal\":\"test-host@test\"\n        #\"keytab\":\"/home/test-host.keytab\",\n        #\"env_vars\":{\"SPARK_MAJOR_VERSION\":2}\n    }\n    spark_config = {\n        \"spark.submit.deployMode\": \"cluster\",\n        \"spark.eventLog.enabled\": \"true\",\n        \"spark.eventLog.dir\": \"/data/spark/events\"\n        #\"spark.yarn.queue\":\"test\",\n        #\"spark.dynamicAllocation.minExecutors\":5,\n        #\"spark.dynamicAllocation.maxExecutors\":10,\n        #\"spark.yarn.driver.memoryOverhead\":5120,\n        #\"spark.driver.maxResultSize\":\"2G\",\n        #\"spark.yarn.executor.memoryOverhead\":5120,\n        #\"spark.kryoserializer.buffer.max\":\"1000m\",\n        #\"spark.executor.extraJavaOptions\":\"-XX:+UseG1GC\",\n        #\"spark.network.timeout\":\"15000s\",\n        #\"spark.executor.heartbeatInterval\":\"1500s\",\n        #\"spark.task.maxDirectResultSize\":\"8G\",\n        #\"spark.ui.view.acls\":\"*\"\n    }\n    #spark_submit = SparkSubmitOperator(task_id=\'spark_submit\', application=\'/opt/bitnami/spark/examples/jars/spark-examples_2.12-3.2.1.jar\', java_class=\'org.apache.spark.examples.SparkPi\')\n    spark_submit = SparkSubmitOperator(**base_config, conf=spark_config)\n','2022-06-03 03:19:17'),
(31713643128362712,'/opt/airflow/dags/repo/src/dags/trino_tpcds_benchmark.py','\"\"\"\nExample DAG demonstrating the usage of the TaskFlow API to execute Python functions natively and within a\nvirtual environment.\n\"\"\"\n\nfrom pprint import pprint\nfrom timeit import timeit\n\nfrom airflow import DAG\nfrom airflow.utils.db import provide_session\nfrom airflow.models import XCom, Variable\nfrom airflow.decorators import task\nfrom airflow.models.baseoperator import chain\nfrom airflow.providers.trino.hooks.trino import TrinoHook\n\nimport pendulum\nfrom ada.sql_perf.common import QueryCollection\n\ntrino_benchmark_type = \'tpcd\'\ntrino_tpcds_benchmark_connection= Variable.get(\"trino_tpcds_benchmark_connection\", default_var=None)\ntrino_tpcds_benchmark_query_filter = Variable.get(\"trino_tpcds_benchmark_query_filter\", default_var=None)\n\ndef trino_query(connection_id, query_statement):\n    trino = TrinoHook(\n        trino_conn_id=connection_id\n    )\n    print(f\'query statement:\\n{query_statement}\\n\')\n    query_results = trino.get_records(query_statement)\n    print(f\'query results:\\n{query_results}\\n\')\n\nwith DAG(\n    dag_id=\'trino-tpcds-benchmark\',\n    description=\'DAG runs TPC-DS benchmark queries over Trino\',\n    schedule_interval=None,\n    start_date=pendulum.datetime(2021, 1, 1, tz=\"UTC\"),\n    catchup=False,\n    tags=[\'benchmarking\', \'tpc\', \'tpc-ds\']\n) as dag:\n\n    task_list = []\n\n    # retrieve benchmark queries\n    qc = QueryCollection(trino_benchmark_type)\n    query_objects = qc.filter_by_selection(trino_tpcds_benchmark_query_filter)\n    task_ids = [f\'benchmark_{trino_benchmark_type}_{query_object.sort_key}\' for query_object in query_objects]\n\n    for task_idx in range(len(query_objects)):\n        query_object = query_objects[task_idx]\n        task_id = task_ids[task_idx]\n        prev_task_id = task_ids[task_idx-1] if task_idx > 0 else None\n\n        @task(task_id=task_id, trigger_rule=\"all_done\")\n        def run_query(trino_connection, query_object, task_id, prev_task_id, **kwargs):\n            \"\"\"Execute query task\"\"\"\n\n            ti = kwargs[\'ti\']\n            if prev_task_id is None:\n                benchmark_results = []\n            else:\n                benchmark_results = ti.xcom_pull(key=f\'{prev_task_id}_benchmark_results\', task_ids=prev_task_id)\n\n            try:\n                execution_time = timeit(lambda: trino_query(trino_connection, query_object.statement), number=1)\n            except Exception as err:\n                execution_time = None\n                benchmark_results.append({\n                    \'query_name\': f\'{query_object.sort_key}\',\n                    \'execution_time\': execution_time\n                })\n                ti.xcom_push(key=f\'{task_id}_benchmark_results\', value=benchmark_results)\n                raise err\n            else:\n                benchmark_results.append({\n                    \'query_name\': f\'{query_object.sort_key}\',\n                    \'execution_time\': execution_time\n                })\n                ti.xcom_push(key=f\'{task_id}_benchmark_results\', value=benchmark_results)\n                    \n        query_task = run_query(trino_tpcds_benchmark_connection, query_object, task_id, prev_task_id)\n        task_list.append(query_task)\n\n    @task(task_id=f\'benchmark_results\', trigger_rule=\"all_done\")\n    def print_results(prev_task_id, **kwargs):\n        \"\"\"Log benchmark results\"\"\"\n        ti = kwargs[\'ti\']\n        benchmark_results = ti.xcom_pull(key=f\'{prev_task_id}_benchmark_results\', task_ids=[prev_task_id])\n        print(f\'-- benchmark results --\')\n        print(\"{:>10} | {:<20}\".format(\'Task ID\', \'Execution Time (seconds)\'))\n        if benchmark_results:\n            for benchmark_result in benchmark_results[0]:\n                execution_time = benchmark_result[\'execution_time\'] if benchmark_result[\'execution_time\'] else \'failed\'\n                print(\"{:>10} | {:<20}\".format(benchmark_result[\'query_name\'], execution_time))\n        else:\n            print(\'no results found..\')\n        print(\'-----\')\n    task_list.append(print_results(task_ids[-1]))\n\n    @task(task_id=f\'clean_xcom\', trigger_rule=\"all_done\")\n    @provide_session\n    def cleanup_xcom(session=None, **context):     \n        dag = context[\"dag\"]\n        dag_id = dag._dag_id\n        session.query(XCom).filter(XCom.dag_id == dag_id).delete()\n    task_list.append(cleanup_xcom())\n\n    chain(*task_list)\n','2022-06-03 03:19:17'),
(40011592971637170,'/opt/airflow/dags/repo/src/dags/tpch_query_runner.py','\"\"\"\nExample DAG demonstrating the usage of the TaskFlow API to execute Python functions natively and within a\nvirtual environment.\n\"\"\"\n\nimport time\nfrom pprint import pprint\n\nimport pendulum\nfrom airflow import DAG\nfrom airflow.decorators import task\nfrom airflow.providers.trino.hooks.trino import TrinoHook\n# apache-airflow-providers-trino\n\nsql1 = \'\'\'\nselect\n	returnflag,\n	linestatus,\n	sum(quantity) as sum_qty,\n	sum(extendedprice) as sum_base_price,\n	sum(extendedprice * (1 - discount)) as sum_disc_price,\n	sum(extendedprice * (1 - discount) * (1 + tax)) as sum_charge,\n	avg(quantity) as avg_qty,\n	avg(extendedprice) as avg_price,\n	avg(discount) as avg_disc,\n	count(*) as count_order\nfrom\n	lineitem\nwhere\n	shipdate <= date \'1998-12-01\' - interval \'90\' day\ngroup by\n	returnflag,\n	linestatus\norder by\n	returnflag,\n	linestatus\n\'\'\'\n\nwith DAG(\n    dag_id=\'tpch_query_runner\',\n    schedule_interval=None,\n    start_date=pendulum.datetime(2021, 1, 1, tz=\"UTC\"),\n    catchup=False,\n    tags=[\'example\'],\n) as dag:\n    @task(task_id=\"print_the_context\")\n    def print_context(ds=None, **kwargs):\n        \"\"\"Print the Airflow context and ds variable from the context.\"\"\"\n        pprint(kwargs)\n        print(ds)\n\n    run_this = print_context()\n\n    @task(task_id=f\'sleep_half_second\')\n    def run_sleep():\n        \"\"\"This is a sleep task\"\"\"\n        time.sleep(0.5111)\n        print(\'have slept..\')\n\n    task_1 = run_sleep()\n    run_this >> task_1\n\n    @task(task_id=f\'run_query\')\n    def run_query(query):\n        \"\"\"This is a query task\"\"\"\n        trino = TrinoHook(\n            trino_conn_id=\'trino_tpch\'\n        )\n        query_results = trino.get_records(query)\n        print(\'printing results..\')\n        pprint(query_results)\n        print(\'run query complete..\')\n\n    task_2 = run_query(sql1)\n    run_this >> task_2\n','2022-06-03 03:19:17'),
(63934184024333571,'/opt/airflow/dags/repo/src/dags/k8spark_submitter_dag.py','#\n# Licensed to the Apache Software Foundation (ASF) under one\n# or more contributor license agreements. See the NOTICE file\n# distributed with this work for additional information\n# regarding copyright ownership. The ASF licenses this file\n# to you under the Apache License, Version 2.0 (the\n# \"License\"); you may not use this file except in compliance\n# with the License. You may obtain a copy of the License at\n#\n# http://www.apache.org/licenses/LICENSE-2.0\n#\n# Unless required by applicable law or agreed to in writing,\n# software distributed under the License is distributed on an\n# \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY\n# KIND, either express or implied. See the License for the\n# specific language governing permissions and limitations\n# under the License.\n\n\"\"\"\nExample Airflow DAG to submit Apache Spark applications using\n`SparkSubmitOperator`, `SparkJDBCOperator` and `SparkSqlOperator`.\n\"\"\"\n\nfrom datetime import datetime\n\nfrom airflow.models import DAG\nfrom airflow.providers.apache.spark.operators.spark_submit import SparkSubmitOperator\n\nwith DAG(\n    dag_id=\'simple_k8spark_submiter\',\n    schedule_interval=None,\n    start_date=datetime(2022, 2, 22),\n    catchup=False,\n    tags=[\'example\'],\n) as dag:\n    base_config = {\n        \"task_id\":\"k8spark_submit\",\n        \"conn_id\":\"spark-k8\",\n        # \"application\": \"/opt/bitnami/spark/examples/jars/spark-examples_2.12-3.2.1.jar\",\n        \"application\": \"/opt/airflow/dags/repo/src/dags/spark-examples_2.12-3.2.1.jar\",\n        \"application_args\": [\"1\"],\n        \"executor_memory\":\"512M\",\n        \"driver_memory\":\"512M\",\n        \"executor_cores\":1,\n        \"application_args\":\"10\",\n        \"java_class\": \"org.apache.spark.examples.SparkPi\"\n        #\"principal\":\"test-host@test\"\n        #\"keytab\":\"/home/test-host.keytab\",\n        #\"env_vars\":{\"SPARK_MAJOR_VERSION\":2}\n    }\n    spark_config = {\n        \"spark.submit.deployMode\": \"cluster\",\n        \"spark.eventLog.enabled\": \"true\",\n        \"spark.eventLog.dir\": \"/data/spark/events\",\n        \"spark.executor.instances\": 2,\n        \"spark.kubernetes.namespace\": \"spark\",\n        \"spark.kubernetes.container.image\": \"seanlimvsg/spark-py:ada4\",\n        \"spark.kubernetes.authenticate.driver.serviceAccountName\": \"k8spark\",\n        \"spark.kubernetes.file.upload.path\": \"s3a://spark/tmp\",\n        \"spark.hadoop.fs.s3a.endpoint\": \"https://s3-api.stg.ada.dbs-sandbox.versent-innovation.au1.staxapp.cloud\",\n        \"spark.hadoop.fs.s3a.access.key\": \"sa-access-key\",\n        \"spark.hadoop.fs.s3a.secret.key\": \"sa-secret-key\",\n        # \"spark.hadoop.fs.s3a.impl\": \"org.apache.hadoop.fs.s3a.S3AFileSystem\",\n        \"spark.hadoop.fs.s3a.path.style.access\": \"true\",\n        \"spark.hadoop.fs.s3a.fast.upload\": \"true\",\n        \"spark.driver.extraJavaOptions\": \"\'-Divy.cache.dir=/tmp -Divy.home=/tmp\'\"\n        #\"spark.yarn.queue\":\"test\",\n        #\"spark.dynamicAllocation.minExecutors\":5,\n        #\"spark.dynamicAllocation.maxExecutors\":10,\n        #\"spark.yarn.driver.memoryOverhead\":5120,\n        #\"spark.driver.maxResultSize\":\"2G\",\n        #\"spark.yarn.executor.memoryOverhead\":5120,\n        #\"spark.kryoserializer.buffer.max\":\"1000m\",\n        #\"spark.executor.extraJavaOptions\":\"-XX:+UseG1GC\",\n        #\"spark.network.timeout\":\"15000s\",\n        #\"spark.executor.heartbeatInterval\":\"1500s\",\n        #\"spark.task.maxDirectResultSize\":\"8G\",\n        #\"spark.ui.view.acls\":\"*\"\n    }\n    #spark_submit = SparkSubmitOperator(task_id=\'spark_submit\', application=\'/opt/bitnami/spark/examples/jars/spark-examples_2.12-3.2.1.jar\', java_class=\'org.apache.spark.examples.SparkPi\')\n    spark_submit = SparkSubmitOperator(**base_config, conf=spark_config)\n','2022-06-03 03:19:17');
/*!40101 SET NAMES binary*/;
CREATE TABLE `dag_pickle` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pickle` blob DEFAULT NULL,
  `created_dttm` timestamp(6) NULL DEFAULT NULL,
  `pickle_hash` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] NONCLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET NAMES binary*/;
CREATE TABLE `dag_run` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dag_id` varchar(250) COLLATE utf8_general_ci NOT NULL,
  `execution_date` datetime(6) NOT NULL,
  `state` varchar(50) COLLATE utf8_general_ci DEFAULT NULL,
  `run_id` varchar(250) COLLATE utf8_general_ci NOT NULL,
  `external_trigger` tinyint(1) DEFAULT NULL,
  `conf` blob DEFAULT NULL,
  `end_date` timestamp(6) NULL DEFAULT NULL,
  `start_date` timestamp(6) NULL DEFAULT NULL,
  `run_type` varchar(50) COLLATE utf8_general_ci NOT NULL,
  `last_scheduling_decision` timestamp(6) NULL DEFAULT NULL,
  `dag_hash` varchar(32) COLLATE utf8_general_ci DEFAULT NULL,
  `creating_job_id` int(11) DEFAULT NULL,
  `queued_at` datetime DEFAULT NULL,
  `data_interval_start` timestamp(6) NULL DEFAULT NULL,
  `data_interval_end` timestamp(6) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] NONCLUSTERED */,
  KEY `dag_id_state` (`dag_id`,`state`),
  KEY `idx_last_scheduling_decision` (`last_scheduling_decision`),
  KEY `idx_dag_run_dag_id` (`dag_id`),
  KEY `idx_dag_run_running_dags` (`state`,`dag_id`),
  KEY `idx_dag_run_queued_dags` (`state`,`dag_id`),
  UNIQUE KEY `dag_run_dag_id_execution_date_key` (`dag_id`,`execution_date`),
  UNIQUE KEY `dag_run_dag_id_run_id_key` (`dag_id`,`run_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET NAMES binary*/;
CREATE TABLE `dag_tag` (
  `name` varchar(100) COLLATE utf8_general_ci NOT NULL,
  `dag_id` varchar(250) COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`name`,`dag_id`) /*T![clustered_index] NONCLUSTERED */,
  CONSTRAINT `dag_id` FOREIGN KEY (`dag_id`) REFERENCES `dag` (`dag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET NAMES binary*/;
INSERT INTO `dag_tag` VALUES
('example','simple_spark_submiter'),
('example','tpch_query_runner'),
('benchmarking','trino-tpcds-benchmark'),
('tpc','trino-tpcds-benchmark'),
('tpc-ds','trino-tpcds-benchmark'),
('tpch','trino-tpch-benchmark'),
('benchmarking','trino-tpch-benchmark'),
('tpc','trino-tpch-benchmark'),
('example','simple_k8spark_submiter');
/*!40101 SET NAMES binary*/;
CREATE TABLE `import_error` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `timestamp` timestamp(6) NULL DEFAULT NULL,
  `filename` varchar(1024) COLLATE utf8_general_ci DEFAULT NULL,
  `stacktrace` text COLLATE utf8_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] NONCLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci AUTO_INCREMENT=90001;
/*!40101 SET NAMES binary*/;
INSERT INTO `import_error` VALUES
(60427,'2022-06-03 03:20:19.059752','/opt/airflow/dags/repo/src/dags/trino_benchmark_runner.py','Traceback (most recent call last):\n  File \"/opt/airflow/dags/repo/src/dags/trino_benchmark_runner.py\", line 38, in <module>\n    qc = QueryCollection(trino_benchmark_type)\n  File \"/opt/airflow/dags/repo/src/dags/ada/sql_perf/common.py\", line 102, in __init__\n    query_directory = QUERY_DIRECTORIES[type_selection]\nKeyError: None\n');
/*!40101 SET NAMES binary*/;
CREATE TABLE `job` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dag_id` varchar(250) COLLATE utf8_general_ci DEFAULT NULL,
  `state` varchar(20) COLLATE utf8_general_ci DEFAULT NULL,
  `job_type` varchar(30) COLLATE utf8_general_ci DEFAULT NULL,
  `start_date` timestamp(6) NULL DEFAULT NULL,
  `end_date` timestamp(6) NULL DEFAULT NULL,
  `latest_heartbeat` timestamp(6) NULL DEFAULT NULL,
  `executor_class` varchar(500) COLLATE utf8_general_ci DEFAULT NULL,
  `hostname` varchar(500) COLLATE utf8_general_ci DEFAULT NULL,
  `unixname` varchar(1000) COLLATE utf8_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] NONCLUSTERED */,
  KEY `job_type_heart` (`job_type`,`latest_heartbeat`),
  KEY `idx_job_state_heartbeat` (`state`,`latest_heartbeat`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci AUTO_INCREMENT=90001;
/*!40101 SET NAMES binary*/;
INSERT INTO `job` VALUES
(1,NULL,'failed','SchedulerJob','2022-06-02 07:55:51.098641',NULL,'2022-06-02 12:00:12.761101','CeleryExecutor','airflow-scheduler-c7f5f89df-7wnnk','airflow'),
(30001,NULL,'failed','SchedulerJob','2022-06-02 12:43:08.426614',NULL,'2022-06-02 16:41:26.511994','CeleryExecutor','airflow-scheduler-c7f5f89df-7wnnk','airflow'),
(60001,NULL,'success','SchedulerJob','2022-06-03 01:05:06.792379','2022-06-03 01:53:39.132480','2022-06-03 01:52:58.396997','CeleryExecutor','airflow-scheduler-c7f5f89df-7wnnk','airflow'),
(60003,NULL,'success','SchedulerJob','2022-06-03 01:54:44.084318','2022-06-03 01:58:56.531852','2022-06-03 01:58:05.126654','CeleryExecutor','airflow-scheduler-c7f5f89df-7wnnk','airflow'),
(60005,NULL,'failed','SchedulerJob','2022-06-03 02:00:28.382923',NULL,'2022-06-03 02:00:28.382944','CeleryExecutor','airflow-scheduler-c7f5f89df-7wnnk','airflow'),
(60007,NULL,'failed','SchedulerJob','2022-06-03 02:07:43.885675',NULL,'2022-06-03 02:07:43.885690','CeleryExecutor','airflow-scheduler-c7f5f89df-7wnnk','airflow'),
(60009,NULL,'success','SchedulerJob','2022-06-03 02:16:10.709359','2022-06-03 02:16:13.135950','2022-06-03 02:16:10.709374','CeleryExecutor','airflow-scheduler-c7f5f89df-7wnnk','airflow'),
(60011,NULL,'running','SchedulerJob','2022-06-03 02:16:22.414313',NULL,'2022-06-03 03:20:18.492579','CeleryExecutor','airflow-scheduler-c7f5f89df-7wnnk','airflow');
/*!40101 SET NAMES binary*/;
CREATE TABLE `log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dttm` timestamp(6) NULL DEFAULT NULL,
  `dag_id` varchar(250) COLLATE utf8_general_ci DEFAULT NULL,
  `task_id` varchar(250) COLLATE utf8_general_ci DEFAULT NULL,
  `event` varchar(30) COLLATE utf8_general_ci DEFAULT NULL,
  `execution_date` timestamp(6) NULL DEFAULT NULL,
  `owner` varchar(500) COLLATE utf8_general_ci DEFAULT NULL,
  `extra` text COLLATE utf8_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] NONCLUSTERED */,
  KEY `idx_log_dag` (`dag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci AUTO_INCREMENT=90001;
/*!40101 SET NAMES binary*/;
INSERT INTO `log` VALUES
(1,'2022-06-02 07:02:42.237072',NULL,NULL,'cli_check',NULL,'airflow','{\"host_name\": \"airflow-db-migrations-85dbdbc579-5jbww\", \"full_command\": \"[\'/home/airflow/.local/bin/airflow\', \'db\', \'check\']\"}'),
(3,'2022-06-02 07:19:43.673844',NULL,NULL,'cli_check',NULL,'airflow','{\"host_name\": \"airflow-db-migrations-85dbdbc579-7ptcm\", \"full_command\": \"[\'/home/airflow/.local/bin/airflow\', \'db\', \'check\']\"}'),
(5,'2022-06-02 07:36:40.903562',NULL,NULL,'cli_check',NULL,'airflow','{\"host_name\": \"airflow-db-migrations-85dbdbc579-msjkm\", \"full_command\": \"[\'/home/airflow/.local/bin/airflow\', \'db\', \'check\']\"}'),
(7,'2022-06-02 07:40:03.344211',NULL,NULL,'cli_check',NULL,'airflow','{\"host_name\": \"airflow-db-migrations-85dbdbc579-lt4wh\", \"full_command\": \"[\'/home/airflow/.local/bin/airflow\', \'db\', \'check\']\"}'),
(9,'2022-06-02 07:45:57.556325',NULL,NULL,'cli_check',NULL,'airflow','{\"host_name\": \"airflow-db-migrations-85dbdbc579-726mv\", \"full_command\": \"[\'/home/airflow/.local/bin/airflow\', \'db\', \'check\']\"}'),
(11,'2022-06-02 07:51:36.044168',NULL,NULL,'cli_flower',NULL,'airflow','{\"host_name\": \"airflow-flower-86445c756b-pblp2\", \"full_command\": \"[\'/home/airflow/.local/bin/airflow\', \'celery\', \'flower\']\"}'),
(13,'2022-06-02 07:55:09.166286',NULL,NULL,'cli_webserver',NULL,'airflow','{\"host_name\": \"airflow-web-59c5b54d87-vjg2d\", \"full_command\": \"[\'/home/airflow/.local/bin/airflow\', \'webserver\']\"}'),
(15,'2022-06-02 07:55:40.306432',NULL,NULL,'cli_worker',NULL,'airflow','{\"host_name\": \"airflow-worker-0\", \"full_command\": \"[\'/home/airflow/.local/bin/airflow\', \'celery\', \'worker\']\"}'),
(17,'2022-06-02 07:55:50.921881',NULL,NULL,'cli_scheduler',NULL,'airflow','{\"host_name\": \"airflow-scheduler-c7f5f89df-7wnnk\", \"full_command\": \"[\'/home/airflow/.local/bin/airflow\', \'scheduler\', \'-n\', \'-1\']\"}'),
(19,'2022-06-02 07:59:13.285550','trino-tpcds-benchmark',NULL,'tree',NULL,'admin','[(\'dag_id\', \'trino-tpcds-benchmark\')]'),
(30001,'2022-06-02 12:42:25.305374',NULL,NULL,'cli_check',NULL,'airflow','{\"host_name\": \"airflow-web-59c5b54d87-vjg2d\", \"full_command\": \"[\'/home/airflow/.local/bin/airflow\', \'db\', \'check\']\"}'),
(30003,'2022-06-02 12:42:26.072626',NULL,NULL,'cli_check',NULL,'airflow','{\"host_name\": \"airflow-worker-0\", \"full_command\": \"[\'/home/airflow/.local/bin/airflow\', \'db\', \'check\']\"}'),
(30005,'2022-06-02 12:42:32.546189',NULL,NULL,'cli_check',NULL,'airflow','{\"host_name\": \"airflow-sync-connections-5f978f54b6-8x28g\", \"full_command\": \"[\'/home/airflow/.local/bin/airflow\', \'db\', \'check\']\"}'),
(30007,'2022-06-02 12:42:36.431056',NULL,NULL,'cli_check',NULL,'airflow','{\"host_name\": \"airflow-scheduler-c7f5f89df-7wnnk\", \"full_command\": \"[\'/home/airflow/.local/bin/airflow\', \'db\', \'check\']\"}'),
(30009,'2022-06-02 12:42:43.878240',NULL,NULL,'cli_check',NULL,'airflow','{\"host_name\": \"airflow-flower-86445c756b-pblp2\", \"full_command\": \"[\'/home/airflow/.local/bin/airflow\', \'db\', \'check\']\"}'),
(30011,'2022-06-02 12:43:08.328270',NULL,NULL,'cli_scheduler',NULL,'airflow','{\"host_name\": \"airflow-scheduler-c7f5f89df-7wnnk\", \"full_command\": \"[\'/home/airflow/.local/bin/airflow\', \'scheduler\', \'-n\', \'-1\']\"}'),
(30013,'2022-06-02 12:43:09.339945',NULL,NULL,'cli_webserver',NULL,'airflow','{\"host_name\": \"airflow-web-59c5b54d87-vjg2d\", \"full_command\": \"[\'/home/airflow/.local/bin/airflow\', \'webserver\']\"}'),
(30015,'2022-06-02 12:43:45.485913',NULL,NULL,'cli_check',NULL,'airflow','{\"host_name\": \"airflow-db-migrations-85dbdbc579-726mv\", \"full_command\": \"[\'/home/airflow/.local/bin/airflow\', \'db\', \'check\']\"}'),
(30017,'2022-06-02 12:44:07.344714',NULL,NULL,'cli_check',NULL,'airflow','{\"host_name\": \"airflow-sync-users-f9f4b689d-8bxxr\", \"full_command\": \"[\'/home/airflow/.local/bin/airflow\', \'db\', \'check\']\"}'),
(30019,'2022-06-02 12:44:08.493758',NULL,NULL,'cli_check',NULL,'airflow','{\"host_name\": \"airflow-sync-variables-65b554d579-kczmr\", \"full_command\": \"[\'/home/airflow/.local/bin/airflow\', \'db\', \'check\']\"}'),
(30021,'2022-06-02 12:44:13.980949',NULL,NULL,'cli_worker',NULL,'airflow','{\"host_name\": \"airflow-worker-0\", \"full_command\": \"[\'/home/airflow/.local/bin/airflow\', \'celery\', \'worker\']\"}'),
(30023,'2022-06-02 12:44:14.129588',NULL,NULL,'cli_flower',NULL,'airflow','{\"host_name\": \"airflow-flower-86445c756b-pblp2\", \"full_command\": \"[\'/home/airflow/.local/bin/airflow\', \'celery\', \'flower\']\"}'),
(60001,'2022-06-03 01:04:18.331077',NULL,NULL,'cli_check',NULL,'airflow','{\"host_name\": \"airflow-sync-users-f9f4b689d-8bxxr\", \"full_command\": \"[\'/home/airflow/.local/bin/airflow\', \'db\', \'check\']\"}'),
(60003,'2022-06-03 01:04:28.589937',NULL,NULL,'cli_check',NULL,'airflow','{\"host_name\": \"airflow-web-59c5b54d87-vjg2d\", \"full_command\": \"[\'/home/airflow/.local/bin/airflow\', \'db\', \'check\']\"}'),
(60005,'2022-06-03 01:04:31.188854',NULL,NULL,'cli_check',NULL,'airflow','{\"host_name\": \"airflow-worker-0\", \"full_command\": \"[\'/home/airflow/.local/bin/airflow\', \'db\', \'check\']\"}'),
(60007,'2022-06-03 01:04:33.264439',NULL,NULL,'cli_check',NULL,'airflow','{\"host_name\": \"airflow-scheduler-c7f5f89df-7wnnk\", \"full_command\": \"[\'/home/airflow/.local/bin/airflow\', \'db\', \'check\']\"}'),
(60009,'2022-06-03 01:04:36.658122',NULL,NULL,'cli_check',NULL,'airflow','{\"host_name\": \"airflow-flower-86445c756b-pblp2\", \"full_command\": \"[\'/home/airflow/.local/bin/airflow\', \'db\', \'check\']\"}'),
(60011,'2022-06-03 01:04:37.957476',NULL,NULL,'cli_check',NULL,'airflow','{\"host_name\": \"airflow-db-migrations-85dbdbc579-726mv\", \"full_command\": \"[\'/home/airflow/.local/bin/airflow\', \'db\', \'check\']\"}'),
(60013,'2022-06-03 01:04:39.985834',NULL,NULL,'cli_check',NULL,'airflow','{\"host_name\": \"airflow-sync-connections-5f978f54b6-8x28g\", \"full_command\": \"[\'/home/airflow/.local/bin/airflow\', \'db\', \'check\']\"}'),
(60015,'2022-06-03 01:04:46.015498',NULL,NULL,'cli_check',NULL,'airflow','{\"host_name\": \"airflow-sync-variables-65b554d579-kczmr\", \"full_command\": \"[\'/home/airflow/.local/bin/airflow\', \'db\', \'check\']\"}'),
(60017,'2022-06-03 01:05:06.686933',NULL,NULL,'cli_scheduler',NULL,'airflow','{\"host_name\": \"airflow-scheduler-c7f5f89df-7wnnk\", \"full_command\": \"[\'/home/airflow/.local/bin/airflow\', \'scheduler\', \'-n\', \'-1\']\"}'),
(60019,'2022-06-03 01:05:14.134553',NULL,NULL,'cli_webserver',NULL,'airflow','{\"host_name\": \"airflow-web-59c5b54d87-vjg2d\", \"full_command\": \"[\'/home/airflow/.local/bin/airflow\', \'webserver\']\"}'),
(60021,'2022-06-03 01:05:27.143576',NULL,NULL,'cli_worker',NULL,'airflow','{\"host_name\": \"airflow-worker-0\", \"full_command\": \"[\'/home/airflow/.local/bin/airflow\', \'celery\', \'worker\']\"}'),
(60023,'2022-06-03 01:05:29.630487',NULL,NULL,'cli_flower',NULL,'airflow','{\"host_name\": \"airflow-flower-86445c756b-pblp2\", \"full_command\": \"[\'/home/airflow/.local/bin/airflow\', \'celery\', \'flower\']\"}'),
(60025,'2022-06-03 01:53:58.277956',NULL,NULL,'cli_scheduler',NULL,'airflow','{\"host_name\": \"airflow-scheduler-c7f5f89df-7wnnk\", \"full_command\": \"[\'/home/airflow/.local/bin/airflow\', \'scheduler\', \'-n\', \'-1\']\"}'),
(60027,'2022-06-03 01:59:20.000609',NULL,NULL,'cli_scheduler',NULL,'airflow','{\"host_name\": \"airflow-scheduler-c7f5f89df-7wnnk\", \"full_command\": \"[\'/home/airflow/.local/bin/airflow\', \'scheduler\', \'-n\', \'-1\']\"}'),
(60029,'2022-06-03 02:01:39.168711',NULL,NULL,'cli_webserver',NULL,'airflow','{\"host_name\": \"airflow-web-59c5b54d87-vjg2d\", \"full_command\": \"[\'/home/airflow/.local/bin/airflow\', \'webserver\']\"}'),
(60031,'2022-06-03 02:05:04.123092',NULL,NULL,'cli_scheduler',NULL,'airflow','{\"host_name\": \"airflow-scheduler-c7f5f89df-7wnnk\", \"full_command\": \"[\'/home/airflow/.local/bin/airflow\', \'scheduler\', \'-n\', \'-1\']\"}'),
(60033,'2022-06-03 02:05:34.948498',NULL,NULL,'cli_webserver',NULL,'airflow','{\"host_name\": \"airflow-web-59c5b54d87-vjg2d\", \"full_command\": \"[\'/home/airflow/.local/bin/airflow\', \'webserver\']\"}'),
(60035,'2022-06-03 02:11:04.124242',NULL,NULL,'cli_scheduler',NULL,'airflow','{\"host_name\": \"airflow-scheduler-c7f5f89df-7wnnk\", \"full_command\": \"[\'/home/airflow/.local/bin/airflow\', \'scheduler\', \'-n\', \'-1\']\"}'),
(60037,'2022-06-03 02:13:14.698999',NULL,NULL,'cli_webserver',NULL,'airflow','{\"host_name\": \"airflow-web-59c5b54d87-vjg2d\", \"full_command\": \"[\'/home/airflow/.local/bin/airflow\', \'webserver\']\"}'),
(60039,'2022-06-03 02:16:22.218058',NULL,NULL,'cli_scheduler',NULL,'airflow','{\"host_name\": \"airflow-scheduler-c7f5f89df-7wnnk\", \"full_command\": \"[\'/home/airflow/.local/bin/airflow\', \'scheduler\', \'-n\', \'-1\']\"}');
/*!40101 SET NAMES binary*/;
CREATE TABLE `rendered_task_instance_fields` (
  `dag_id` varchar(250) COLLATE utf8_general_ci NOT NULL,
  `task_id` varchar(250) COLLATE utf8_general_ci NOT NULL,
  `execution_date` timestamp(6) NOT NULL,
  `rendered_fields` json NOT NULL,
  `k8s_pod_yaml` json DEFAULT NULL,
  PRIMARY KEY (`dag_id`,`task_id`,`execution_date`) /*T![clustered_index] NONCLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET NAMES binary*/;
CREATE TABLE `sensor_instance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` varchar(250) COLLATE utf8_general_ci NOT NULL,
  `dag_id` varchar(250) COLLATE utf8_general_ci NOT NULL,
  `execution_date` timestamp(6) NOT NULL,
  `state` varchar(20) COLLATE utf8_general_ci DEFAULT NULL,
  `try_number` int(11) DEFAULT NULL,
  `start_date` timestamp(6) NULL DEFAULT NULL,
  `operator` varchar(1000) COLLATE utf8_general_ci NOT NULL,
  `op_classpath` varchar(1000) COLLATE utf8_general_ci NOT NULL,
  `hashcode` bigint(20) NOT NULL,
  `shardcode` int(11) NOT NULL,
  `poke_context` text COLLATE utf8_general_ci NOT NULL,
  `execution_context` text COLLATE utf8_general_ci DEFAULT NULL,
  `created_at` timestamp(6) NOT NULL,
  `updated_at` timestamp(6) NOT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `ti_primary_key` (`dag_id`,`task_id`,`execution_date`),
  KEY `si_hashcode` (`hashcode`),
  KEY `si_shardcode` (`shardcode`),
  KEY `si_state_shard` (`state`,`shardcode`),
  KEY `si_updated_at` (`updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET NAMES binary*/;
CREATE TABLE `serialized_dag` (
  `dag_id` varchar(250) COLLATE utf8_general_ci NOT NULL,
  `fileloc` varchar(2000) COLLATE utf8_general_ci NOT NULL,
  `fileloc_hash` bigint(20) NOT NULL,
  `data` json NOT NULL,
  `last_updated` timestamp(6) NOT NULL,
  `dag_hash` varchar(32) COLLATE utf8_general_ci NOT NULL DEFAULT 'Hash not calculated yet',
  PRIMARY KEY (`dag_id`) /*T![clustered_index] NONCLUSTERED */,
  KEY `idx_fileloc_hash` (`fileloc_hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET NAMES binary*/;
INSERT INTO `serialized_dag` VALUES
('simple_spark_submiter','/opt/airflow/dags/repo/src/dags/spark_submitter_dag.py',25116999314156411,'{\"__version\": 1, \"dag\": {\"_dag_id\": \"simple_spark_submiter\", \"_task_group\": {\"_group_id\": null, \"children\": {\"spark_submit\": [\"operator\", \"spark_submit\"]}, \"downstream_group_ids\": [], \"downstream_task_ids\": [], \"prefix_group_id\": true, \"tooltip\": \"\", \"ui_color\": \"CornflowerBlue\", \"ui_fgcolor\": \"#000\", \"upstream_group_ids\": [], \"upstream_task_ids\": []}, \"catchup\": false, \"dag_dependencies\": [], \"edge_info\": {}, \"fileloc\": \"/opt/airflow/dags/repo/src/dags/spark_submitter_dag.py\", \"params\": {}, \"schedule_interval\": null, \"start_date\": 1645488000, \"tags\": [\"example\"], \"tasks\": [{\"_application\": \"/opt/bitnami/spark/examples/jars/spark-examples_2.12-3.2.1.jar\", \"_application_args\": \"10\", \"_conf\": {\"spark.eventLog.dir\": \"/data/spark/events\", \"spark.eventLog.enabled\": \"true\", \"spark.submit.deployMode\": \"cluster\"}, \"_downstream_task_ids\": [], \"_inlets\": [], \"_is_dummy\": false, \"_name\": \"arrow-spark\", \"_outlets\": [], \"_task_module\": \"airflow.providers.apache.spark.operators.spark_submit\", \"_task_type\": \"SparkSubmitOperator\", \"label\": \"spark_submit\", \"pool\": \"default_pool\", \"task_id\": \"spark_submit\", \"template_ext\": [], \"template_fields\": [\"_application\", \"_conf\", \"_files\", \"_py_files\", \"_jars\", \"_driver_class_path\", \"_packages\", \"_exclude_packages\", \"_keytab\", \"_principal\", \"_proxy_user\", \"_name\", \"_application_args\", \"_env_vars\"], \"template_fields_renderers\": {}, \"ui_color\": \"#FF9933\", \"ui_fgcolor\": \"#000\"}], \"timezone\": \"UTC\"}}','2022-06-02 07:55:54.610715','c662caffe2bfa60ca83e4f414936eb0d'),
('tpch_query_runner','/opt/airflow/dags/repo/src/dags/tpch_query_runner.py',40011592971637170,'{\"__version\": 1, \"dag\": {\"_dag_id\": \"tpch_query_runner\", \"_task_group\": {\"_group_id\": null, \"children\": {\"print_the_context\": [\"operator\", \"print_the_context\"], \"run_query\": [\"operator\", \"run_query\"], \"sleep_half_second\": [\"operator\", \"sleep_half_second\"]}, \"downstream_group_ids\": [], \"downstream_task_ids\": [], \"prefix_group_id\": true, \"tooltip\": \"\", \"ui_color\": \"CornflowerBlue\", \"ui_fgcolor\": \"#000\", \"upstream_group_ids\": [], \"upstream_task_ids\": []}, \"catchup\": false, \"dag_dependencies\": [], \"edge_info\": {}, \"fileloc\": \"/opt/airflow/dags/repo/src/dags/tpch_query_runner.py\", \"params\": {}, \"schedule_interval\": null, \"start_date\": 1609459200, \"tags\": [\"example\"], \"tasks\": [{\"_downstream_task_ids\": [\"run_query\", \"sleep_half_second\"], \"_inlets\": [], \"_is_dummy\": false, \"_outlets\": [], \"_task_module\": \"airflow.decorators.python\", \"_task_type\": \"_PythonDecoratedOperator\", \"doc_md\": \"Print the Airflow context and ds variable from the context.\", \"label\": \"print_the_context\", \"op_args\": [], \"op_kwargs\": {}, \"pool\": \"default_pool\", \"task_id\": \"print_the_context\", \"template_ext\": [], \"template_fields\": [\"op_args\", \"op_kwargs\"], \"template_fields_renderers\": {\"op_args\": \"py\", \"op_kwargs\": \"py\"}, \"ui_color\": \"#ffefeb\", \"ui_fgcolor\": \"#000\"}, {\"_downstream_task_ids\": [], \"_inlets\": [], \"_is_dummy\": false, \"_outlets\": [], \"_task_module\": \"airflow.decorators.python\", \"_task_type\": \"_PythonDecoratedOperator\", \"doc_md\": \"This is a sleep task\", \"label\": \"sleep_half_second\", \"op_args\": [], \"op_kwargs\": {}, \"pool\": \"default_pool\", \"task_id\": \"sleep_half_second\", \"template_ext\": [], \"template_fields\": [\"op_args\", \"op_kwargs\"], \"template_fields_renderers\": {\"op_args\": \"py\", \"op_kwargs\": \"py\"}, \"ui_color\": \"#ffefeb\", \"ui_fgcolor\": \"#000\"}, {\"_downstream_task_ids\": [], \"_inlets\": [], \"_is_dummy\": false, \"_outlets\": [], \"_task_module\": \"airflow.decorators.python\", \"_task_type\": \"_PythonDecoratedOperator\", \"doc_md\": \"This is a query task\", \"label\": \"run_query\", \"op_args\": [\"\\nselect\\n\\treturnflag,\\n\\tlinestatus,\\n\\tsum(quantity) as sum_qty,\\n\\tsum(extendedprice) as sum_base_price,\\n\\tsum(extendedprice * (1 - discount)) as sum_disc_price,\\n\\tsum(extendedprice * (1 - discount) * (1 + tax)) as sum_charge,\\n\\tavg(quantity) as avg_qty,\\n\\tavg(extendedprice) as avg_price,\\n\\tavg(discount) as avg_disc,\\n\\tcount(*) as count_order\\nfrom\\n\\tlineitem\\nwhere\\n\\tshipdate <= date \'1998-12-01\' - interval \'90\' day\\ngroup by\\n\\treturnflag,\\n\\tlinestatus\\norder by\\n\\treturnflag,\\n\\tlinestatus\\n\"], \"op_kwargs\": {}, \"pool\": \"default_pool\", \"task_id\": \"run_query\", \"template_ext\": [], \"template_fields\": [\"op_args\", \"op_kwargs\"], \"template_fields_renderers\": {\"op_args\": \"py\", \"op_kwargs\": \"py\"}, \"ui_color\": \"#ffefeb\", \"ui_fgcolor\": \"#000\"}], \"timezone\": \"UTC\"}}','2022-06-02 07:56:05.237331','724ce13b8f130ed6cb3b57665518e0c8'),
('trino-tpcds-benchmark','/opt/airflow/dags/repo/src/dags/trino_tpcds_benchmark.py',31713643128362712,'{\"__version\": 1, \"dag\": {\"_dag_id\": \"trino-tpcds-benchmark\", \"_description\": \"DAG runs TPC-DS benchmark queries over Trino\", \"_task_group\": {\"_group_id\": null, \"children\": {\"benchmark_results\": [\"operator\", \"benchmark_results\"], \"benchmark_tpcd_1\": [\"operator\", \"benchmark_tpcd_1\"], \"benchmark_tpcd_2\": [\"operator\", \"benchmark_tpcd_2\"], \"benchmark_tpcd_3\": [\"operator\", \"benchmark_tpcd_3\"], \"benchmark_tpcd_4\": [\"operator\", \"benchmark_tpcd_4\"], \"benchmark_tpcd_5\": [\"operator\", \"benchmark_tpcd_5\"], \"clean_xcom\": [\"operator\", \"clean_xcom\"]}, \"downstream_group_ids\": [], \"downstream_task_ids\": [], \"prefix_group_id\": true, \"tooltip\": \"\", \"ui_color\": \"CornflowerBlue\", \"ui_fgcolor\": \"#000\", \"upstream_group_ids\": [], \"upstream_task_ids\": []}, \"catchup\": false, \"dag_dependencies\": [], \"edge_info\": {}, \"fileloc\": \"/opt/airflow/dags/repo/src/dags/trino_tpcds_benchmark.py\", \"params\": {}, \"schedule_interval\": null, \"start_date\": 1609459200, \"tags\": [\"benchmarking\", \"tpc\", \"tpc-ds\"], \"tasks\": [{\"_downstream_task_ids\": [\"benchmark_tpcd_2\"], \"_inlets\": [], \"_is_dummy\": false, \"_outlets\": [], \"_task_module\": \"airflow.decorators.python\", \"_task_type\": \"_PythonDecoratedOperator\", \"doc_md\": \"Execute query task\", \"label\": \"benchmark_tpcd_1\", \"op_args\": \"(\'tpcds-tiny\', <ada.sql_perf.common.Query object at 0x7f207bf44ed0>, \'benchmark_tpcd_1\', None)\", \"op_kwargs\": {}, \"pool\": \"default_pool\", \"task_id\": \"benchmark_tpcd_1\", \"template_ext\": [], \"template_fields\": [\"op_args\", \"op_kwargs\"], \"template_fields_renderers\": {\"op_args\": \"py\", \"op_kwargs\": \"py\"}, \"trigger_rule\": \"all_done\", \"ui_color\": \"#ffefeb\", \"ui_fgcolor\": \"#000\"}, {\"_downstream_task_ids\": [\"benchmark_tpcd_3\"], \"_inlets\": [], \"_is_dummy\": false, \"_outlets\": [], \"_task_module\": \"airflow.decorators.python\", \"_task_type\": \"_PythonDecoratedOperator\", \"doc_md\": \"Execute query task\", \"label\": \"benchmark_tpcd_2\", \"op_args\": \"(\'tpcds-tiny\', <ada.sql_perf.common.Query object at 0x7f207bf44e90>, \'benchmark_tpcd_2\', \'benchmark_tpcd_1\')\", \"op_kwargs\": {}, \"pool\": \"default_pool\", \"task_id\": \"benchmark_tpcd_2\", \"template_ext\": [], \"template_fields\": [\"op_args\", \"op_kwargs\"], \"template_fields_renderers\": {\"op_args\": \"py\", \"op_kwargs\": \"py\"}, \"trigger_rule\": \"all_done\", \"ui_color\": \"#ffefeb\", \"ui_fgcolor\": \"#000\"}, {\"_downstream_task_ids\": [\"benchmark_tpcd_4\"], \"_inlets\": [], \"_is_dummy\": false, \"_outlets\": [], \"_task_module\": \"airflow.decorators.python\", \"_task_type\": \"_PythonDecoratedOperator\", \"doc_md\": \"Execute query task\", \"label\": \"benchmark_tpcd_3\", \"op_args\": \"(\'tpcds-tiny\', <ada.sql_perf.common.Query object at 0x7f207bf44e50>, \'benchmark_tpcd_3\', \'benchmark_tpcd_2\')\", \"op_kwargs\": {}, \"pool\": \"default_pool\", \"task_id\": \"benchmark_tpcd_3\", \"template_ext\": [], \"template_fields\": [\"op_args\", \"op_kwargs\"], \"template_fields_renderers\": {\"op_args\": \"py\", \"op_kwargs\": \"py\"}, \"trigger_rule\": \"all_done\", \"ui_color\": \"#ffefeb\", \"ui_fgcolor\": \"#000\"}, {\"_downstream_task_ids\": [\"benchmark_tpcd_5\"], \"_inlets\": [], \"_is_dummy\": false, \"_outlets\": [], \"_task_module\": \"airflow.decorators.python\", \"_task_type\": \"_PythonDecoratedOperator\", \"doc_md\": \"Execute query task\", \"label\": \"benchmark_tpcd_4\", \"op_args\": \"(\'tpcds-tiny\', <ada.sql_perf.common.Query object at 0x7f207bf44e10>, \'benchmark_tpcd_4\', \'benchmark_tpcd_3\')\", \"op_kwargs\": {}, \"pool\": \"default_pool\", \"task_id\": \"benchmark_tpcd_4\", \"template_ext\": [], \"template_fields\": [\"op_args\", \"op_kwargs\"], \"template_fields_renderers\": {\"op_args\": \"py\", \"op_kwargs\": \"py\"}, \"trigger_rule\": \"all_done\", \"ui_color\": \"#ffefeb\", \"ui_fgcolor\": \"#000\"}, {\"_downstream_task_ids\": [\"benchmark_results\"], \"_inlets\": [], \"_is_dummy\": false, \"_outlets\": [], \"_task_module\": \"airflow.decorators.python\", \"_task_type\": \"_PythonDecoratedOperator\", \"doc_md\": \"Execute query task\", \"label\": \"benchmark_tpcd_5\", \"op_args\": \"(\'tpcds-tiny\', <ada.sql_perf.common.Query object at 0x7f207bf44dd0>, \'benchmark_tpcd_5\', \'benchmark_tpcd_4\')\", \"op_kwargs\": {}, \"pool\": \"default_pool\", \"task_id\": \"benchmark_tpcd_5\", \"template_ext\": [], \"template_fields\": [\"op_args\", \"op_kwargs\"], \"template_fields_renderers\": {\"op_args\": \"py\", \"op_kwargs\": \"py\"}, \"trigger_rule\": \"all_done\", \"ui_color\": \"#ffefeb\", \"ui_fgcolor\": \"#000\"}, {\"_downstream_task_ids\": [\"clean_xcom\"], \"_inlets\": [], \"_is_dummy\": false, \"_outlets\": [], \"_task_module\": \"airflow.decorators.python\", \"_task_type\": \"_PythonDecoratedOperator\", \"doc_md\": \"Log benchmark results\", \"label\": \"benchmark_results\", \"op_args\": [\"benchmark_tpcd_5\"], \"op_kwargs\": {}, \"pool\": \"default_pool\", \"task_id\": \"benchmark_results\", \"template_ext\": [], \"template_fields\": [\"op_args\", \"op_kwargs\"], \"template_fields_renderers\": {\"op_args\": \"py\", \"op_kwargs\": \"py\"}, \"trigger_rule\": \"all_done\", \"ui_color\": \"#ffefeb\", \"ui_fgcolor\": \"#000\"}, {\"_downstream_task_ids\": [], \"_inlets\": [], \"_is_dummy\": false, \"_outlets\": [], \"_task_module\": \"airflow.decorators.python\", \"_task_type\": \"_PythonDecoratedOperator\", \"label\": \"clean_xcom\", \"op_args\": [], \"op_kwargs\": {}, \"pool\": \"default_pool\", \"task_id\": \"clean_xcom\", \"template_ext\": [], \"template_fields\": [\"op_args\", \"op_kwargs\"], \"template_fields_renderers\": {\"op_args\": \"py\", \"op_kwargs\": \"py\"}, \"trigger_rule\": \"all_done\", \"ui_color\": \"#ffefeb\", \"ui_fgcolor\": \"#000\"}], \"timezone\": \"UTC\"}}','2022-06-03 03:20:20.216245','d8272b975e4dc64dd67114170557b49a'),
('trino-tpch-benchmark','/opt/airflow/dags/repo/src/dags/trino_tpch_benchmark.py',567218068107241,'{\"__version\": 1, \"dag\": {\"_dag_id\": \"trino-tpch-benchmark\", \"_description\": \"DAG runs TPCH benchmark queries over Trino\", \"_task_group\": {\"_group_id\": null, \"children\": {\"benchmark_results\": [\"operator\", \"benchmark_results\"], \"benchmark_tpch_1\": [\"operator\", \"benchmark_tpch_1\"], \"benchmark_tpch_2\": [\"operator\", \"benchmark_tpch_2\"], \"benchmark_tpch_3\": [\"operator\", \"benchmark_tpch_3\"], \"benchmark_tpch_4\": [\"operator\", \"benchmark_tpch_4\"], \"benchmark_tpch_5\": [\"operator\", \"benchmark_tpch_5\"], \"clean_xcom\": [\"operator\", \"clean_xcom\"]}, \"downstream_group_ids\": [], \"downstream_task_ids\": [], \"prefix_group_id\": true, \"tooltip\": \"\", \"ui_color\": \"CornflowerBlue\", \"ui_fgcolor\": \"#000\", \"upstream_group_ids\": [], \"upstream_task_ids\": []}, \"catchup\": false, \"dag_dependencies\": [], \"edge_info\": {}, \"fileloc\": \"/opt/airflow/dags/repo/src/dags/trino_tpch_benchmark.py\", \"params\": {}, \"schedule_interval\": null, \"start_date\": 1609459200, \"tags\": [\"benchmarking\", \"tpc\", \"tpch\"], \"tasks\": [{\"_downstream_task_ids\": [\"benchmark_tpch_2\"], \"_inlets\": [], \"_is_dummy\": false, \"_outlets\": [], \"_task_module\": \"airflow.decorators.python\", \"_task_type\": \"_PythonDecoratedOperator\", \"doc_md\": \"Execute query task\", \"label\": \"benchmark_tpch_1\", \"op_args\": \"(\'tpch-tiny\', <ada.sql_perf.common.Query object at 0x7f207bf3bdd0>, \'benchmark_tpch_1\', None)\", \"op_kwargs\": {}, \"pool\": \"default_pool\", \"task_id\": \"benchmark_tpch_1\", \"template_ext\": [], \"template_fields\": [\"op_args\", \"op_kwargs\"], \"template_fields_renderers\": {\"op_args\": \"py\", \"op_kwargs\": \"py\"}, \"trigger_rule\": \"all_done\", \"ui_color\": \"#ffefeb\", \"ui_fgcolor\": \"#000\"}, {\"_downstream_task_ids\": [\"benchmark_tpch_3\"], \"_inlets\": [], \"_is_dummy\": false, \"_outlets\": [], \"_task_module\": \"airflow.decorators.python\", \"_task_type\": \"_PythonDecoratedOperator\", \"doc_md\": \"Execute query task\", \"label\": \"benchmark_tpch_2\", \"op_args\": \"(\'tpch-tiny\', <ada.sql_perf.common.Query object at 0x7f207bf3be50>, \'benchmark_tpch_2\', \'benchmark_tpch_1\')\", \"op_kwargs\": {}, \"pool\": \"default_pool\", \"task_id\": \"benchmark_tpch_2\", \"template_ext\": [], \"template_fields\": [\"op_args\", \"op_kwargs\"], \"template_fields_renderers\": {\"op_args\": \"py\", \"op_kwargs\": \"py\"}, \"trigger_rule\": \"all_done\", \"ui_color\": \"#ffefeb\", \"ui_fgcolor\": \"#000\"}, {\"_downstream_task_ids\": [\"benchmark_tpch_4\"], \"_inlets\": [], \"_is_dummy\": false, \"_outlets\": [], \"_task_module\": \"airflow.decorators.python\", \"_task_type\": \"_PythonDecoratedOperator\", \"doc_md\": \"Execute query task\", \"label\": \"benchmark_tpch_3\", \"op_args\": \"(\'tpch-tiny\', <ada.sql_perf.common.Query object at 0x7f207bf41b10>, \'benchmark_tpch_3\', \'benchmark_tpch_2\')\", \"op_kwargs\": {}, \"pool\": \"default_pool\", \"task_id\": \"benchmark_tpch_3\", \"template_ext\": [], \"template_fields\": [\"op_args\", \"op_kwargs\"], \"template_fields_renderers\": {\"op_args\": \"py\", \"op_kwargs\": \"py\"}, \"trigger_rule\": \"all_done\", \"ui_color\": \"#ffefeb\", \"ui_fgcolor\": \"#000\"}, {\"_downstream_task_ids\": [\"benchmark_tpch_5\"], \"_inlets\": [], \"_is_dummy\": false, \"_outlets\": [], \"_task_module\": \"airflow.decorators.python\", \"_task_type\": \"_PythonDecoratedOperator\", \"doc_md\": \"Execute query task\", \"label\": \"benchmark_tpch_4\", \"op_args\": \"(\'tpch-tiny\', <ada.sql_perf.common.Query object at 0x7f207bf41a10>, \'benchmark_tpch_4\', \'benchmark_tpch_3\')\", \"op_kwargs\": {}, \"pool\": \"default_pool\", \"task_id\": \"benchmark_tpch_4\", \"template_ext\": [], \"template_fields\": [\"op_args\", \"op_kwargs\"], \"template_fields_renderers\": {\"op_args\": \"py\", \"op_kwargs\": \"py\"}, \"trigger_rule\": \"all_done\", \"ui_color\": \"#ffefeb\", \"ui_fgcolor\": \"#000\"}, {\"_downstream_task_ids\": [\"benchmark_results\"], \"_inlets\": [], \"_is_dummy\": false, \"_outlets\": [], \"_task_module\": \"airflow.decorators.python\", \"_task_type\": \"_PythonDecoratedOperator\", \"doc_md\": \"Execute query task\", \"label\": \"benchmark_tpch_5\", \"op_args\": \"(\'tpch-tiny\', <ada.sql_perf.common.Query object at 0x7f207bf41610>, \'benchmark_tpch_5\', \'benchmark_tpch_4\')\", \"op_kwargs\": {}, \"pool\": \"default_pool\", \"task_id\": \"benchmark_tpch_5\", \"template_ext\": [], \"template_fields\": [\"op_args\", \"op_kwargs\"], \"template_fields_renderers\": {\"op_args\": \"py\", \"op_kwargs\": \"py\"}, \"trigger_rule\": \"all_done\", \"ui_color\": \"#ffefeb\", \"ui_fgcolor\": \"#000\"}, {\"_downstream_task_ids\": [\"clean_xcom\"], \"_inlets\": [], \"_is_dummy\": false, \"_outlets\": [], \"_task_module\": \"airflow.decorators.python\", \"_task_type\": \"_PythonDecoratedOperator\", \"doc_md\": \"Log benchmark results\", \"label\": \"benchmark_results\", \"op_args\": [\"benchmark_tpch_5\"], \"op_kwargs\": {}, \"pool\": \"default_pool\", \"task_id\": \"benchmark_results\", \"template_ext\": [], \"template_fields\": [\"op_args\", \"op_kwargs\"], \"template_fields_renderers\": {\"op_args\": \"py\", \"op_kwargs\": \"py\"}, \"trigger_rule\": \"all_done\", \"ui_color\": \"#ffefeb\", \"ui_fgcolor\": \"#000\"}, {\"_downstream_task_ids\": [], \"_inlets\": [], \"_is_dummy\": false, \"_outlets\": [], \"_task_module\": \"airflow.decorators.python\", \"_task_type\": \"_PythonDecoratedOperator\", \"label\": \"clean_xcom\", \"op_args\": [], \"op_kwargs\": {}, \"pool\": \"default_pool\", \"task_id\": \"clean_xcom\", \"template_ext\": [], \"template_fields\": [\"op_args\", \"op_kwargs\"], \"template_fields_renderers\": {\"op_args\": \"py\", \"op_kwargs\": \"py\"}, \"trigger_rule\": \"all_done\", \"ui_color\": \"#ffefeb\", \"ui_fgcolor\": \"#000\"}], \"timezone\": \"UTC\"}}','2022-06-03 03:20:20.208983','0101d03406301d50be02d6e1a396bb66'),
('simple_k8spark_submiter','/opt/airflow/dags/repo/src/dags/k8spark_submitter_dag.py',63934184024333571,'{\"__version\": 1, \"dag\": {\"_dag_id\": \"simple_k8spark_submiter\", \"_task_group\": {\"_group_id\": null, \"children\": {\"k8spark_submit\": [\"operator\", \"k8spark_submit\"]}, \"downstream_group_ids\": [], \"downstream_task_ids\": [], \"prefix_group_id\": true, \"tooltip\": \"\", \"ui_color\": \"CornflowerBlue\", \"ui_fgcolor\": \"#000\", \"upstream_group_ids\": [], \"upstream_task_ids\": []}, \"catchup\": false, \"dag_dependencies\": [], \"edge_info\": {}, \"fileloc\": \"/opt/airflow/dags/repo/src/dags/k8spark_submitter_dag.py\", \"params\": {}, \"schedule_interval\": null, \"start_date\": 1645488000, \"tags\": [\"example\"], \"tasks\": [{\"_application\": \"/opt/airflow/dags/repo/src/dags/spark-examples_2.12-3.2.1.jar\", \"_application_args\": \"10\", \"_conf\": {\"spark.driver.extraJavaOptions\": \"\'-Divy.cache.dir=/tmp -Divy.home=/tmp\'\", \"spark.eventLog.dir\": \"/data/spark/events\", \"spark.eventLog.enabled\": \"true\", \"spark.executor.instances\": 2, \"spark.hadoop.fs.s3a.access.key\": \"sa-access-key\", \"spark.hadoop.fs.s3a.endpoint\": \"https://s3-api.stg.ada.dbs-sandbox.versent-innovation.au1.staxapp.cloud\", \"spark.hadoop.fs.s3a.fast.upload\": \"true\", \"spark.hadoop.fs.s3a.path.style.access\": \"true\", \"spark.hadoop.fs.s3a.secret.key\": \"sa-secret-key\", \"spark.kubernetes.authenticate.driver.serviceAccountName\": \"k8spark\", \"spark.kubernetes.container.image\": \"seanlimvsg/spark-py:ada4\", \"spark.kubernetes.file.upload.path\": \"s3a://spark/tmp\", \"spark.kubernetes.namespace\": \"spark\", \"spark.submit.deployMode\": \"cluster\"}, \"_downstream_task_ids\": [], \"_inlets\": [], \"_is_dummy\": false, \"_name\": \"arrow-spark\", \"_outlets\": [], \"_task_module\": \"airflow.providers.apache.spark.operators.spark_submit\", \"_task_type\": \"SparkSubmitOperator\", \"label\": \"k8spark_submit\", \"pool\": \"default_pool\", \"task_id\": \"k8spark_submit\", \"template_ext\": [], \"template_fields\": [\"_application\", \"_conf\", \"_files\", \"_py_files\", \"_jars\", \"_driver_class_path\", \"_packages\", \"_exclude_packages\", \"_keytab\", \"_principal\", \"_proxy_user\", \"_name\", \"_application_args\", \"_env_vars\"], \"template_fields_renderers\": {}, \"ui_color\": \"#FF9933\", \"ui_fgcolor\": \"#000\"}], \"timezone\": \"UTC\"}}','2022-06-02 07:56:08.734025','86cfa3e344de9c22cdb87963d5ab0bef');
/*!40101 SET NAMES binary*/;
CREATE TABLE `sla_miss` (
  `task_id` varchar(250) COLLATE utf8_general_ci NOT NULL,
  `dag_id` varchar(250) COLLATE utf8_general_ci NOT NULL,
  `execution_date` timestamp(6) NOT NULL,
  `email_sent` tinyint(1) DEFAULT NULL,
  `timestamp` timestamp(6) NULL DEFAULT NULL,
  `description` text COLLATE utf8_general_ci DEFAULT NULL,
  `notification_sent` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`task_id`,`dag_id`,`execution_date`) /*T![clustered_index] NONCLUSTERED */,
  KEY `sm_dag` (`dag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET NAMES binary*/;
CREATE TABLE `slot_pool` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pool` varchar(256) COLLATE utf8_general_ci DEFAULT NULL,
  `slots` int(11) DEFAULT NULL,
  `description` text COLLATE utf8_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] NONCLUSTERED */,
  UNIQUE KEY `pool` (`pool`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci AUTO_INCREMENT=30001;
/*!40101 SET NAMES binary*/;
INSERT INTO `slot_pool` VALUES
(1,'default_pool',128,'Default pool');
/*!40101 SET NAMES binary*/;
CREATE TABLE `task_fail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` varchar(250) COLLATE utf8_general_ci NOT NULL,
  `dag_id` varchar(250) COLLATE utf8_general_ci NOT NULL,
  `execution_date` timestamp(6) NOT NULL,
  `start_date` timestamp(6) NULL DEFAULT NULL,
  `end_date` timestamp(6) NULL DEFAULT NULL,
  `duration` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] NONCLUSTERED */,
  KEY `idx_task_fail_dag_task_date` (`dag_id`,`task_id`,`execution_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET NAMES binary*/;
CREATE TABLE `task_instance` (
  `task_id` varchar(250) COLLATE utf8_general_ci NOT NULL,
  `dag_id` varchar(250) COLLATE utf8_general_ci NOT NULL,
  `start_date` timestamp(6) NULL DEFAULT NULL,
  `end_date` timestamp(6) NULL DEFAULT NULL,
  `duration` float DEFAULT NULL,
  `state` varchar(20) COLLATE utf8_general_ci DEFAULT NULL,
  `try_number` int(11) DEFAULT NULL,
  `hostname` varchar(1000) COLLATE utf8_general_ci DEFAULT NULL,
  `unixname` varchar(1000) COLLATE utf8_general_ci DEFAULT NULL,
  `job_id` int(11) DEFAULT NULL,
  `pool` varchar(256) COLLATE utf8_general_ci NOT NULL,
  `queue` varchar(256) COLLATE utf8_general_ci DEFAULT NULL,
  `priority_weight` int(11) DEFAULT NULL,
  `operator` varchar(1000) COLLATE utf8_general_ci DEFAULT NULL,
  `queued_dttm` timestamp(6) NULL DEFAULT NULL,
  `pid` int(11) DEFAULT NULL,
  `max_tries` int(11) DEFAULT '-1',
  `executor_config` blob DEFAULT NULL,
  `pool_slots` int(11) NOT NULL,
  `queued_by_job_id` int(11) DEFAULT NULL,
  `external_executor_id` varchar(250) COLLATE utf8_general_ci DEFAULT NULL,
  `trigger_id` int(11) DEFAULT NULL,
  `trigger_timeout` datetime DEFAULT NULL,
  `next_method` varchar(1000) COLLATE utf8_general_ci DEFAULT NULL,
  `next_kwargs` json DEFAULT NULL,
  `run_id` varchar(250) COLLATE utf8_general_ci NOT NULL,
  KEY `ti_dag_state` (`dag_id`,`state`),
  KEY `ti_pool` (`pool`,`state`,`priority_weight`),
  KEY `ti_state` (`state`),
  KEY `ti_job_id` (`job_id`),
  KEY `ti_trigger_id` (`trigger_id`),
  PRIMARY KEY (`dag_id`,`task_id`,`run_id`) /*T![clustered_index] NONCLUSTERED */,
  KEY `ti_dag_run` (`dag_id`,`run_id`),
  KEY `ti_state_lkp` (`dag_id`,`task_id`,`run_id`,`state`),
  CONSTRAINT `task_instance_trigger_id_fkey` FOREIGN KEY (`trigger_id`) REFERENCES `trigger` (`id`) ON DELETE CASCADE,
  CONSTRAINT `task_instance_dag_run_fkey` FOREIGN KEY (`dag_id`,`run_id`) REFERENCES `dag_run` (`dag_id`,`run_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET NAMES binary*/;
CREATE TABLE `task_reschedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` varchar(250) COLLATE utf8_general_ci NOT NULL,
  `dag_id` varchar(250) COLLATE utf8_general_ci NOT NULL,
  `try_number` int(11) NOT NULL,
  `start_date` timestamp(6) NOT NULL,
  `end_date` timestamp(6) NOT NULL,
  `duration` int(11) NOT NULL,
  `reschedule_date` timestamp(6) NOT NULL,
  `run_id` varchar(250) COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  KEY `idx_task_reschedule_dag_task_run` (`dag_id`,`task_id`,`run_id`),
  CONSTRAINT `task_reschedule_ti_fkey` FOREIGN KEY (`dag_id`,`task_id`,`run_id`) REFERENCES `task_instance` (`dag_id`,`task_id`,`run_id`) ON DELETE CASCADE,
  CONSTRAINT `task_reschedule_dr_fkey` FOREIGN KEY (`dag_id`,`run_id`) REFERENCES `dag_run` (`dag_id`,`run_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET NAMES binary*/;
CREATE TABLE `trigger` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `classpath` varchar(1000) COLLATE utf8_general_ci NOT NULL,
  `kwargs` json NOT NULL,
  `created_date` datetime NOT NULL,
  `triggerer_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET NAMES binary*/;
CREATE TABLE `variable` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(250) COLLATE utf8_general_ci DEFAULT NULL,
  `val` mediumtext COLLATE utf8_general_ci DEFAULT NULL,
  `is_encrypted` tinyint(1) DEFAULT NULL,
  `description` text COLLATE utf8_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] NONCLUSTERED */,
  UNIQUE KEY `key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci AUTO_INCREMENT=30001;
/*!40101 SET NAMES binary*/;
INSERT INTO `variable` VALUES
(1,'trino_tpcds_benchmark_connection','gAAAAABimGwGKU_XgZ6Ob3hM5A0xLExsj-FV1F-BOY6TUgKrWpttGYUWRTqSxQcXutjGvzcQ7k2ZMiklAzYDKO5upZLAmwpIXQ==',1,NULL),
(3,'trino_tpcds_benchmark_query_filter','gAAAAABimGwHrkoEOC9WVOBBIEZgHaOcCDtplovWdUmjO5AhB9KeegnmpKRg1254W_YYXFf7Xuy_FEYRPyTRQAxFrpthIvQonw==',1,NULL),
(5,'trino_tpch_benchmark_connection','gAAAAABimGwHzGKdwl0JmaTj2Jg826bEzO4WFTth6Wq_Coq_Qt6YCvvVT2O4PvROu_NdYdPaQ1U7U8x6_WQg3w2s2Km2V4r1Tg==',1,NULL),
(7,'trino_tpch_benchmark_query_filter','gAAAAABimGwHrcFsQMQdjFmm9lTDaYEEFY-WzDdQKVplQHrNEDZJe8wetEOwM0VtcixIs5QFyF-ylZKgjQ5QBl1l3fH48LZukg==',1,NULL);
/*!40101 SET NAMES binary*/;
CREATE TABLE `xcom` (
  `key` varchar(512) COLLATE utf8_general_ci NOT NULL,
  `value` blob DEFAULT NULL,
  `timestamp` timestamp(6) NOT NULL,
  `execution_date` timestamp(6) NOT NULL,
  `task_id` varchar(250) COLLATE utf8_bin NOT NULL,
  `dag_id` varchar(250) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`key`) /*T![clustered_index] NONCLUSTERED */,
  KEY `idx_xcom_dag_task_date` (`dag_id`,`task_id`,`execution_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
