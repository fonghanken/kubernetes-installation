"""
Example DAG demonstrating the usage of the TaskFlow API to execute Python functions natively and within a
virtual environment.
"""

import time
from pprint import pprint

import pendulum
from airflow import DAG
from airflow.decorators import task
from airflow.providers.trino.hooks.trino import TrinoHook
# apache-airflow-providers-trino

sql1 = '''
select
	returnflag,
	linestatus,
	sum(quantity) as sum_qty,
	sum(extendedprice) as sum_base_price,
	sum(extendedprice * (1 - discount)) as sum_disc_price,
	sum(extendedprice * (1 - discount) * (1 + tax)) as sum_charge,
	avg(quantity) as avg_qty,
	avg(extendedprice) as avg_price,
	avg(discount) as avg_disc,
	count(*) as count_order
from
	lineitem
where
	shipdate <= date '1998-12-01' - interval '90' day
group by
	returnflag,
	linestatus
order by
	returnflag,
	linestatus
'''

with DAG(
    dag_id='tpch_query_runner',
    schedule_interval=None,
    start_date=pendulum.datetime(2021, 1, 1, tz="UTC"),
    catchup=False,
    tags=['example'],
) as dag:
    @task(task_id="print_the_context")
    def print_context(ds=None, **kwargs):
        """Print the Airflow context and ds variable from the context."""
        pprint(kwargs)
        print(ds)

    run_this = print_context()

    @task(task_id=f'sleep_half_second')
    def run_sleep():
        """This is a sleep task"""
        time.sleep(0.5111)
        print('have slept..')

    task_1 = run_sleep()
    run_this >> task_1

    @task(task_id=f'run_query')
    def run_query(query):
        """This is a query task"""
        trino = TrinoHook(
            trino_conn_id='trino_tpch'
        )
        query_results = trino.get_records(query)
        print('printing results..')
        pprint(query_results)
        print('run query complete..')

    task_2 = run_query(sql1)
    run_this >> task_2
