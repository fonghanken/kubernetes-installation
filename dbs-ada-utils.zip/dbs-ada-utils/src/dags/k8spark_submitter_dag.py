#
# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements. See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership. The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License. You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied. See the License for the
# specific language governing permissions and limitations
# under the License.

"""
Example Airflow DAG to submit Apache Spark applications using
`SparkSubmitOperator`, `SparkJDBCOperator` and `SparkSqlOperator`.
"""

from datetime import datetime

from airflow.models import DAG
from airflow.providers.apache.spark.operators.spark_submit import SparkSubmitOperator

with DAG(
    dag_id='simple_k8spark_submiter',
    schedule_interval=None,
    start_date=datetime(2022, 2, 22),
    catchup=False,
    tags=['example'],
) as dag:
    base_config = {
        "task_id":"k8spark_submit",
        "conn_id":"spark-k8",
        # "application": "/opt/bitnami/spark/examples/jars/spark-examples_2.12-3.2.1.jar",
        "application": "/opt/airflow/dags/repo/src/dags/spark-examples_2.12-3.2.1.jar",
        "application_args": ["1"],
        "executor_memory":"512M",
        "driver_memory":"512M",
        "executor_cores":1,
        "application_args":"10",
        "java_class": "org.apache.spark.examples.SparkPi"
        #"principal":"test-host@test"
        #"keytab":"/home/test-host.keytab",
        #"env_vars":{"SPARK_MAJOR_VERSION":2}
    }
    spark_config = {
        "spark.submit.deployMode": "cluster",
        "spark.eventLog.enabled": "true",
        "spark.eventLog.dir": "/data/spark/events",
        "spark.executor.instances": 2,
        "spark.kubernetes.namespace": "spark",
        "spark.kubernetes.container.image": "seanlimvsg/spark-py:ada4",
        "spark.kubernetes.authenticate.driver.serviceAccountName": "k8spark",
        "spark.kubernetes.file.upload.path": "s3a://spark/tmp",
        "spark.hadoop.fs.s3a.endpoint": "https://s3-api.stg.ada.dbs-sandbox.versent-innovation.au1.staxapp.cloud",
        "spark.hadoop.fs.s3a.access.key": "sa-access-key",
        "spark.hadoop.fs.s3a.secret.key": "sa-secret-key",
        # "spark.hadoop.fs.s3a.impl": "org.apache.hadoop.fs.s3a.S3AFileSystem",
        "spark.hadoop.fs.s3a.path.style.access": "true",
        "spark.hadoop.fs.s3a.fast.upload": "true",
        "spark.driver.extraJavaOptions": "'-Divy.cache.dir=/tmp -Divy.home=/tmp'"
        #"spark.yarn.queue":"test",
        #"spark.dynamicAllocation.minExecutors":5,
        #"spark.dynamicAllocation.maxExecutors":10,
        #"spark.yarn.driver.memoryOverhead":5120,
        #"spark.driver.maxResultSize":"2G",
        #"spark.yarn.executor.memoryOverhead":5120,
        #"spark.kryoserializer.buffer.max":"1000m",
        #"spark.executor.extraJavaOptions":"-XX:+UseG1GC",
        #"spark.network.timeout":"15000s",
        #"spark.executor.heartbeatInterval":"1500s",
        #"spark.task.maxDirectResultSize":"8G",
        #"spark.ui.view.acls":"*"
    }
    #spark_submit = SparkSubmitOperator(task_id='spark_submit', application='/opt/bitnami/spark/examples/jars/spark-examples_2.12-3.2.1.jar', java_class='org.apache.spark.examples.SparkPi')
    spark_submit = SparkSubmitOperator(**base_config, conf=spark_config)
