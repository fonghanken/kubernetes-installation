"""
Example DAG demonstrating the usage of the TaskFlow API to execute Python functions natively and within a
virtual environment.
"""

from pprint import pprint
from timeit import timeit

from airflow import DAG
from airflow.utils.db import provide_session
from airflow.models import XCom, Variable
from airflow.decorators import task
from airflow.models.baseoperator import chain
from airflow.providers.trino.hooks.trino import TrinoHook

import pendulum
from ada.sql_perf.common import QueryCollection

trino_benchmark_type = 'tpch'
trino_tpch_benchmark_connection= Variable.get("trino_tpch_benchmark_connection", default_var=None)
trino_tpch_benchmark_query_filter = Variable.get("trino_tpch_benchmark_query_filter", default_var=None)

def trino_query(connection_id, query_statement):
    trino = TrinoHook(
        trino_conn_id=connection_id
    )
    print(f'query statement:\n{query_statement}\n')
    query_results = trino.get_records(query_statement)
    print(f'query results:\n{query_results}\n')

with DAG(
    dag_id='trino-tpch-benchmark',
    description='DAG runs TPCH benchmark queries over Trino',
    schedule_interval=None,
    start_date=pendulum.datetime(2021, 1, 1, tz="UTC"),
    catchup=False,
    tags=['benchmarking', 'tpc', 'tpch']
) as dag:

    task_list = []

    # retrieve benchmark queries
    qc = QueryCollection(trino_benchmark_type)
    query_objects = qc.filter_by_selection(trino_tpch_benchmark_query_filter)
    task_ids = [f'benchmark_{trino_benchmark_type}_{query_object.sort_key}' for query_object in query_objects]

    for task_idx in range(len(query_objects)):
        query_object = query_objects[task_idx]
        task_id = task_ids[task_idx]
        prev_task_id = task_ids[task_idx-1] if task_idx > 0 else None

        @task(task_id=task_id, trigger_rule="all_done")
        def run_query(trino_connection, query_object, task_id, prev_task_id, **kwargs):
            """Execute query task"""

            ti = kwargs['ti']
            if prev_task_id is None:
                benchmark_results = []
            else:
                benchmark_results = ti.xcom_pull(key=f'{prev_task_id}_benchmark_results', task_ids=prev_task_id)

            try:
                execution_time = timeit(lambda: trino_query(trino_connection, query_object.statement), number=1)
            except Exception as err:
                execution_time = None
                benchmark_results.append({
                    'query_name': f'{query_object.sort_key}',
                    'execution_time': execution_time
                })
                ti.xcom_push(key=f'{task_id}_benchmark_results', value=benchmark_results)
                raise err
            else:
                benchmark_results.append({
                    'query_name': f'{query_object.sort_key}',
                    'execution_time': execution_time
                })
                ti.xcom_push(key=f'{task_id}_benchmark_results', value=benchmark_results)
                    
        query_task = run_query(trino_tpch_benchmark_connection, query_object, task_id, prev_task_id)
        task_list.append(query_task)

    @task(task_id=f'benchmark_results', trigger_rule="all_done")
    def print_results(prev_task_id, **kwargs):
        """Log benchmark results"""
        ti = kwargs['ti']
        benchmark_results = ti.xcom_pull(key=f'{prev_task_id}_benchmark_results', task_ids=[prev_task_id])
        print(f'-- benchmark results --')
        print("{:>10} | {:<20}".format('Task ID', 'Execution Time (seconds)'))
        if benchmark_results:
            for benchmark_result in benchmark_results[0]:
                execution_time = benchmark_result['execution_time'] if benchmark_result['execution_time'] else 'failed'
                print("{:>10} | {:<20}".format(benchmark_result['query_name'], execution_time))
        else:
            print('no results found..')
        print('-----')
    task_list.append(print_results(task_ids[-1]))

    @task(task_id=f'clean_xcom', trigger_rule="all_done")
    @provide_session
    def cleanup_xcom(session=None, **context):     
        dag = context["dag"]
        dag_id = dag._dag_id
        session.query(XCom).filter(XCom.dag_id == dag_id).delete()
    task_list.append(cleanup_xcom())

    chain(*task_list)
