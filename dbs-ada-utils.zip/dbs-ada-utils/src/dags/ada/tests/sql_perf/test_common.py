import pytest

from os import path

from ada.sql_perf.common import FileHelper, Query, QueryCollection

class TestFileHelper:
    def test_read_file(self):
        content = FileHelper.read_file(path.realpath(__file__))
        assert content
    def test_generates_file_object_list(self):
        current_path = path.dirname(path.realpath(__file__))
        file_objects = FileHelper.list_files_in_directory(current_path)
        assert isinstance(file_objects, list)
        assert len(file_objects) == 2
        assert file_objects[0]['filename'] == '__init__.py'
        assert file_objects[0]['filepath'] == f"{current_path}/__init__.py"

class TestQuery:
    sort_key = 'mock_sort_key'
    filepath = 'mock_filepath'
    statement = 'mock_statement'

    def test_constructs(self):
        q = Query(self.sort_key, self.filepath, self.statement)
        assert q.sort_key == self.sort_key
        assert q.filepath == self.filepath
        assert q.statement == self.statement

    def test_prints(self):
        q = Query(self.sort_key, self.filepath, self.statement)
        assert q.sort_key == self.sort_key
        assert q.filepath == self.filepath
        assert q.statement == self.statement


class TestQueryCollection:
    qc_tpch = QueryCollection('tpch')
    qc_tpcd = QueryCollection('tpch')

    def test_has_collections(self):
        assert len(self.qc_tpch.collection) > 0
        assert len(self.qc_tpcd.collection) > 0

    def test_has_sort_keys(self):
        assert len(self.qc_tpch.sort_keys) > 0
        assert len(self.qc_tpcd.sort_keys) > 0

    def test_filters_one_value(self):
        selection = self.qc_tpch.filter_by_selection('10')
        assert len(selection) == 1
        query_keys = [query.sort_key for query in selection]
        assert query_keys == ['10']

    def test_filters_one_set(self):
        selection = self.qc_tpch.filter_by_selection('1-10')
        assert len(selection) == 10
        query_keys = [query.sort_key for query in selection]
        assert query_keys == ['1','2','3','4','5','6','7','8','9','10']

    def test_filters_multiple_sets(self):
        selection = self.qc_tpch.filter_by_selection('1-5,6,7-10')
        assert len(selection) == 10
        query_keys = [query.sort_key for query in selection]
        assert query_keys == ['1','2','3','4','5','6','7','8','9','10']

    def test_filters_overlapping_sets(self):
        selection = self.qc_tpch.filter_by_selection('1-5,3-8,4-10')
        assert len(selection) == 10
        query_keys = [query.sort_key for query in selection]
        assert query_keys == ['1','2','3','4','5','6','7','8','9','10']

    def test_filter_validates_not_found(self):
        with pytest.raises(ValueError):
            self.qc_tpch.filter_by_selection('1-5,6,7-10,10a')

    def test_filter_validates_wrong_syntax(self):
        with pytest.raises(ValueError):
            self.qc_tpch.filter_by_selection('1-5#')
        with pytest.raises(ValueError):
            self.qc_tpch.filter_by_selection('@1-5')
        with pytest.raises(ValueError):
            self.qc_tpch.filter_by_selection('1-5,,8')
