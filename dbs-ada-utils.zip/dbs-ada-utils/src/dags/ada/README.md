# development
Python 3.7.12

# test
```
pytest -v
```
