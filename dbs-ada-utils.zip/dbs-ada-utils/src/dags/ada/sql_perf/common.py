"""
A group of modules to retrieve TPCH / TPCD query strings for benchmarking.

TPCH:   
    1,2,3,4,5,6,7,8,9,10,
    11,12,13,14,15,16,17,18,19,20,21,22
TPCD:
    1,2,3,4,5,6,7,8,9,10,
    11,12,13,14a,14b,15,16,17,18,19,
    20,21,22,23a,23b,24a,24b,25,26,27,28,29,
    30,31,32,33,34,35,36,37,38,39a,39b,
    40,41,42,43,44,45,46,47,48,49,
    50,51,52,53,54,55,56,57,58,59,
    60,61,62,63,64,65,66,67,68,69,
    70,71,72,73,74,75,76,77,78,79,
    80,81,82,83,84,85,86,87,88,89,
    90,91,92,93,94,95,96,97,98,99
"""

from os import walk, path
import re

SCRIPT_PATH = path.dirname(path.realpath(__file__))
QUERY_DIRECTORIES = {
    'tpch': f'{SCRIPT_PATH}/queries/tpch',
    'tpcd': f'{SCRIPT_PATH}/queries/tpcd',
    'trino_tpch': f'{SCRIPT_PATH}/queries/trino_tpch'
}

class FileHelper:
    """
    Helper to list and retrieve file contents
    """
    def list_files_in_directory(filepath):
        filenames = next(walk(filepath), (None, None, []))[2]
        sorted_filenames = FileHelper.sorted_nicely(filenames)
        file_objects = []
        for filename in sorted_filenames:
            file_object = {
                "filename": filename,
                "filepath": path.join(filepath, filename)
            }
            file_objects.append(file_object)
        return file_objects

    def sorted_nicely(l):
        """ Sort the given iterable in the way that humans expect.""" 
        convert = lambda text: int(text) if text.isdigit() else text 
        alphanum_key = lambda key: [ convert(c) for c in re.split('([0-9]+)', key) ] 
        return sorted(l, key = alphanum_key)
    
    def read_file(filepath):
        with open(filepath) as f:
            contents = f.read()
            return contents

class Query:
    """
    Representation of a Query

    Attributes
    ----------
    sort_key : str
        representation of query to aid with search filters
    filepath : str
        absolute path to the query file
        example '/.../ada/sql_perf/queries/tpcds/24a.sql'
    statement : str
        sql query statement to be executed
    """
    def __init__(self, sort_key, filepath, statement) -> None:
        self.sort_key = sort_key
        self.filepath = filepath
        self.statement = statement

    def __str__(self) -> str:
        statement = repr(self.statement[:20])
        return f"Query(sort_key='{self.sort_key}', filepath='{self.filepath}', statement='{statement}')"

class QueryCollection:
    """
    Entrypoint to the collection of a Queries

    Attributes
    ----------
    collection : list
        sorted list containing all queries belonging to a specific benchmark category
    sort_keys : list
        sort keys from the collection
    """

    collection = None
    sort_keys = None

    def __init__(self, type_selection) -> None:
        """
        Parameters
        ----------
        type_selection : str
            choice of benchmark category. 'tpcd' or 'tpch'
        """
        query_directory = QUERY_DIRECTORIES[type_selection]
        query_files = FileHelper.list_files_in_directory(query_directory)
        self.generate_collection(query_files)
        return

    def generate_collection(self, query_files):
        """
        Creates Query object representation of query files and store into collection
        """
        self.collection = []
        for query_file in query_files:
            sort_key = query_file['filename'].split('.')[0]
            statement = FileHelper.read_file(query_file['filepath'])
            query = Query(sort_key, query_file['filepath'], statement)
            self.collection.append(query)
        self.sort_keys = [query.sort_key for query in self.collection]

    def validate_and_extract_selection_sets(self, selection_str):
        """
        Validation of selection string
        """
        # remove whitespaces
        selection_str = selection_str.replace(' ', '')
        selection_sets = selection_str.split(',')
        for selection_set in selection_sets:
            # validation: hyphenated alphanumeric
            search = re.search('^([\w]+-[\w]+)|[\w]+$', selection_set)
            if not search:
                valid_selection = ','.join(self.sort_keys)
                raise ValueError(f"{selection_str} is invalid.\nValid selection includes: {valid_selection}")
            # validation: value within in query collection
            selection = selection_set.split('-')
            if selection[0] not in self.sort_keys:
                raise ValueError(f"'{selection[0]}' is not within query collection")
            if (len(selection) == 2) and (selection[1] not in self.sort_keys):
                raise ValueError(f"'{selection[1]}' is not within query collection")
        print(f"validated selection sets: {selection_sets}")
        return selection_sets

    def filter_by_selection(self, selection_str):
        """
        Use the query file names w/o prefix as the selection items
        Filter supports multiple selection sets/value, seperated by commas(,)
        Examples:
            '1-5', return queries from 1 to 5,
            '1-24a', return queries from 1 to 24a, excluding 24b
            '1-24', throws an error as 24 is not a valid option
            '2,3-5,10', return queries 2, 3, 4, 5, and 10
        """
        # validate selection sets
        selection_sets = self.validate_and_extract_selection_sets(selection_str)

        # generate filter
        selection_filter = set()
        for selection_set in selection_sets:
            # print(f"checking selection_set ({selection_set})")
            selection = selection_set.split('-')
            to_append = False
            if len(selection) == 2:
                for query in self.collection:
                    if query.sort_key == selection[0]:
                        to_append = True
                    if to_append:
                        selection_filter.add(query.sort_key)
                    if query.sort_key == selection[1]:
                        # print(f"breaking on ({query.sort_key})")
                        break
            else:
                query = next((query for query in self.collection if query.sort_key == selection[0]), None)
                selection_filter.add(query.sort_key)
        
        # filter query collection
        selected_queries = []
        for query in self.collection:
            if query.sort_key in selection_filter:
                selected_queries.append(query)
        
        return selected_queries
    
    def __str__(self) -> str:
        return '[' + ',\n'.join([query.__str__() for query in self.collection]) +']'
        
if __name__=='__main__':
    benchmark_category = 'tpcd'
    qc = QueryCollection(benchmark_category)
    print(qc)
    print('\n------\n')
    selection_filter = '20-24a,19-22,4, 10'
    print(f"{benchmark_category} queries (filter: '{selection_filter}') >")
    for query in qc.filter_by_selection(selection_filter):
        print(query)
