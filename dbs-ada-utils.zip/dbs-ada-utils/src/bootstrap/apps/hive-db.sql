CREATE DATABASE hive;
CREATE USER 'hive' IDENTIFIED BY 'hive1234';
GRANT ALL PRIVILEGES ON hive.* TO 'hive';

set GLOBAL tidb_skip_isolation_level_check=1;