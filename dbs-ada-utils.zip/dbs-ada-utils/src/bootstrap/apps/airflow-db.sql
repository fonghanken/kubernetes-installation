CREATE DATABASE airflow CHARACTER SET utf8 COLLATE utf8_general_ci;
CREATE USER 'airflow' IDENTIFIED BY 'airflow';
GRANT ALL PRIVILEGES ON airflow.* TO 'airflow';

SET GLOBAL tidb_enable_noop_functions=1;
--- Batch Query no.1 ---
ALTER TABLE airflow.sla_miss drop PRIMARY KEY;
ALTER TABLE airflow.sla_miss CHANGE execution_date execution_date TIMESTAMP(6) NOT NULL;
ALTER TABLE airflow.sla_miss ADD PRIMARY KEY(task_id,dag_id,execution_date);

ALTER TABLE airflow.task_instance drop PRIMARY KEY;
ALTER TABLE airflow.task_instance CHANGE execution_date execution_date TIMESTAMP(6) NOT NULL;
ALTER TABLE airflow.task_instance ADD PRIMARY KEY(task_id,dag_id,execution_date);

DROP TABLE airflow.xcom;
CREATE TABLE airflow.xcom (
  -- `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(512) CHARACTER SET utf8 NOT NULL,
  `value` blob DEFAULT NULL,
  `timestamp` timestamp(6) NOT NULL,
  `execution_date` timestamp(6) NOT NULL,
  `task_id` varchar(250) CHARACTER SET utf8 NOT NULL,
  `dag_id` varchar(250) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`key`) /*T![clustered_index] CLUSTERED */,
  KEY `idx_xcom_dag_task_date` (`dag_id`,`task_id`,`execution_date`)
);
--- Batch Query no.1 ---

--- Batch Query no.2 ---
CREATE INDEX task_reschedule_dag_task_date_fkey ON airflow.task_reschedule(task_id);
CREATE INDEX `dag_id` ON airflow.`dag_run`(`dag_id`);
CREATE INDEX `dag_id_2` ON airflow.`dag_run`(`dag_id`);
DROP INDEX dag_run_dag_id_run_id_key on airflow.dag_run;
DROP INDEX dag_run_dag_id_execution_date_key on airflow.dag_run;
ALTER TABLE airflow.task_instance DROP COLUMN run_id;
ALTER TABLE airflow.task_reschedule DROP COLUMN run_id;
ALTER TABLE airflow.task_reschedule ADD CONSTRAINT task_reschedule_dag_task_date_fkey FOREIGN KEY (id) REFERENCES airflow.dag_run(id);
--- Batch Query no.2 ---