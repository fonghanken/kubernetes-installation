CREATE DATABASE superset;
CREATE USER 'superset' IDENTIFIED BY 'superset';
GRANT ALL PRIVILEGES ON superset.* TO 'superset';

--- Batch Query no.1 ---
DROP TABLE superset.`columns`;
CREATE TABLE superset.`columns` (
  `created_on` datetime DEFAULT NULL,
  `changed_on` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datasource_name` varchar(255) DEFAULT NULL,
  `column_name` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `type` varchar(32) DEFAULT NULL,
  `groupby` tinyint(1) DEFAULT NULL,
  `count_distinct` tinyint(1) DEFAULT NULL,
  `sum` tinyint(1) DEFAULT NULL,
  `max` tinyint(1) DEFAULT NULL,
  `min` tinyint(1) DEFAULT NULL,
  `filterable` tinyint(1) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_by_fk` int(11) DEFAULT NULL,
  `changed_by_fk` int(11) DEFAULT NULL,
  `avg` tinyint(1) DEFAULT NULL,
  `dimension_spec_json` text DEFAULT NULL,
  `verbose_name` varchar(1024) DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  CONSTRAINT `created_by_fk` FOREIGN KEY (`created_by_fk`) REFERENCES `ab_user` (`id`),
  CONSTRAINT `changed_by_fk` FOREIGN KEY (`changed_by_fk`) REFERENCES `ab_user` (`id`)
);

DROP INDEX uq_datasources_cluster_name on superset.`datasources`;
--- Batch Query no.1 ---

--- Batch Query no.2 ---
DROP TABLE superset.`dbs`;
CREATE TABLE superset.`dbs` (
  `created_on` datetime DEFAULT NULL,
  `changed_on` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `database_name` varchar(250) NOT NULL,
  `sqlalchemy_uri` varchar(1024) DEFAULT NULL,
  `created_by_fk` int(11) DEFAULT NULL,
  `changed_by_fk` int(11) DEFAULT NULL,
  `password` blob DEFAULT NULL,
  `cache_timeout` int(11) DEFAULT NULL,
  `extra` text DEFAULT NULL,
  `select_as_create_table_as` tinyint(1) DEFAULT NULL,
  `allow_ctas` tinyint(1) DEFAULT NULL,
  `expose_in_sqllab` tinyint(1) DEFAULT NULL,
  `force_ctas_schema` varchar(250) DEFAULT NULL,
  `allow_run_async` tinyint(1) DEFAULT NULL,
  `allow_dml` tinyint(1) DEFAULT NULL,
  `perm` varchar(1000) DEFAULT NULL,
  `verbose_name` varchar(250) DEFAULT NULL,
  `impersonate_user` tinyint(1) DEFAULT NULL,
  `allow_multi_schema_metadata_fetch` tinyint(1) DEFAULT NULL,
  `allow_csv_upload` tinyint(1) NOT NULL DEFAULT '1',
  `encrypted_extra` blob DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `database_name` (`database_name`),
  UNIQUE KEY `verbose_name` (`verbose_name`),
  CONSTRAINT `created_by_fk` FOREIGN KEY (`created_by_fk`) REFERENCES `ab_user` (`id`),
  CONSTRAINT `changed_by_fk` FOREIGN KEY (`changed_by_fk`) REFERENCES `ab_user` (`id`)
);
--- Batch Query no.2 ---