#!/usr/bin/env bash

BOOTSTRAP_DIR=$(cd `dirname $BASH_SOURCE` && pwd)
K8S_DIR=$(cd $BOOTSTRAP_DIR/../../k8s && pwd)
SRC_OVERLAY_NAME=$1
DEST_OVERLAY_NAME=$2

#############################################################
### Functions                                             ###
#############################################################
function help() {
    echo "Usage: ./create-overlay.sh <src_overlay_name> <dest_overlay_name>"
    echo "  ./create-overlay.sh stage dbs"
}

function log_error() {
    RED='\033[0;31m'
    NC='\033[0m'
    echo -e "${RED}${1}${NC}"
}

## MACOS compatability issue
if [ "$(uname)" == "Darwin" ]; then
    alias sed="sed -i ''"
fi

#############################################################
### Entry Point                                           ###
#############################################################
echo '---------- input arguments ----------'
echo "BOOTSTRAP_DIR     : ${BOOTSTRAP_DIR}"
echo "K8S_DIR           : ${K8S_DIR}"
echo "SRC_OVERLAY_NAME  : ${SRC_OVERLAY_NAME}"
echo "DEST_OVERLAY_NAME : ${DEST_OVERLAY_NAME}"
echo "-------------------------------------"

## Validation
if [ -z "${SRC_OVERLAY_NAME}" ] || [ -z "${DEST_OVERLAY_NAME}" ]; then
    help
    echo "exiting.."
    exit
fi

read -r -p "Proceed with bootstraping [y|n] ? " CONTINUE;
if [ ${CONTINUE} != "y" ]; then \
    echo "exiting.."
    exit
fi

## creates ArgoCD projects + applications
ARGOCD_OVERLAY_PATH="${K8S_DIR}/argocd-config/overlays"
# remove old
rm -rf "${ARGOCD_OVERLAY_PATH}/dbs"
# create new
cp -R "${ARGOCD_OVERLAY_PATH}/stage" "${ARGOCD_OVERLAY_PATH}/dbs"

## create K8 kustomization + helm
CLUSTERCONFIG_PATH="${K8S_DIR}/cluster-config"
find "${CLUSTERCONFIG_PATH}" -type d -name stage | grep 'overlays/stage' | while read K8CONFIG_OVERLAY_SRC; do
    K8CONFIG_OVERLAY_PATH="${K8CONFIG_OVERLAY_SRC%%/stage}"
    K8CONFIG_OVERLAY_DEST="${K8CONFIG_OVERLAY_PATH}/dbs"
    # remove old
    rm -rf "${K8CONFIG_OVERLAY_DEST}"
    # create new
    cp -R "${K8CONFIG_OVERLAY_SRC}" "${K8CONFIG_OVERLAY_DEST}"
done
