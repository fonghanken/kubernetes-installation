### APPLY TO MAIN VAULT ###
# ## unseal & login ##
# vault operator unseal ${VAULT_UNSEAL_KEY_1}
vault login ${VAULT_TOKEN}

## enable USERPASS auth ##
vault auth enable userpass

## create admin user
vault policy write admin-policy /home/vault/admin.hcl
vault write auth/userpass/users/admin \
  password=password \
  policies=admin-policy

## create example user
vault policy write user-policy /home/vault/user.hcl
vault write auth/userpass/users/example-user \
  password=password \
  policies=user-policy

## create example secret store
vault secrets enable -version=2 -path=example-store kv
vault kv put example-store/appsecrets some-key=some-provided-value

## create example secret store
vault secrets enable -version=2 -path=ada-infra kv
## puts secrets
vault kv put ada-infra/sealedsecret-key @/home/vault/sealedsecret-key.json
vault kv put ada-infra/controller-secret @/home/vault/controller-secret.json
