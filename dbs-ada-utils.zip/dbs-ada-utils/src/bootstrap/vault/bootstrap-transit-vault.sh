### APPLY TO TRANSIT VAULT ###
# ## unseal & login ##
vault operator unseal ${VAULT_UNSEAL_KEY_1}
vault login ${VAULT_TOKEN}

## enable transit secrets ##
vault secrets enable transit
vault write -f transit/keys/autounseal
vault policy write autounseal  /home/vault/autounseal.hcl

## (option 1: K8 Service Account auth) ##
# enable auth
vault auth enable kubernetes
vault write auth/kubernetes/config \
  token_reviewer_jwt="${TOKEN_REVIEW_JWT}" \
  kubernetes_host="${KUBE_HOST}" \
  kubernetes_ca_cert="${KUBE_CA_CERT}"

# grant transit role to serviceaccount
vault write auth/kubernetes/role/transit-role \
  bound_service_account_names=vault \
  bound_service_account_namespaces=default \
  policies=autounseal \
  ttl=24h

## (option 2: USERPASS auth) ##
# enable auth
vault auth enable userpass
# grant transit policy to user
vault write auth/userpass/users/transit-user \
  password=password \
  policies=autounseal
