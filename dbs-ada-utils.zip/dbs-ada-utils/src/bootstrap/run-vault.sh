#!/usr/bin/env bash
set -e

BOOTSTRAP_DIR=$(cd `dirname $BASH_SOURCE` && pwd)
OVERLAY_NAME="$(cat ${BOOTSTRAP_DIR}/config.json | jq -r '.environment')"
mkdir -p ${BOOTSTRAP_DIR}/secrets
OUTPUT_DIR=${BOOTSTRAP_DIR}/output/${OVERLAY_NAME}
mkdir -p ${OUTPUT_DIR}

### Gather Files ###
aws secretsmanager get-secret-value --secret-id dbs-ada/controller/sealedsecret-key --output text --query 'SecretString' > ${BOOTSTRAP_DIR}/secrets/sealedsecret-key.json
aws secretsmanager get-secret-value --secret-id dbs-ada/controller/controller-secret --output text --query 'SecretString' > ${BOOTSTRAP_DIR}/secrets/controller-secret.json

### Setup Vault (Transit) ###
while ! kubectl exec -it vault-transit-0 -n vault -- hostname; do echo 'trying again in 20s..'; sleep 20; done
# unseal
kubectl exec -it vault-transit-0 -n vault -- vault operator init  -key-shares 1 -key-threshold 1 -format json >> ${OUTPUT_DIR}/transit-unsealkeys.json

## Transit - Unseal, config Transit AutoUnseal, config ServiceAccount login
TRANSIT_UNSEAL_KEY_1=$(cat ${OUTPUT_DIR}/transit-unsealkeys.json | jq '.unseal_keys_b64[0]')
TRANSIT_TOKEN=$(cat ${OUTPUT_DIR}/transit-unsealkeys.json | jq '.root_token')
TOKEN_REVIEW_JWT=$(kubectl get secret -n vault \
   $(kubectl get serviceaccount vault-transit -n vault -o jsonpath='{.secrets[0].name}') \
   -o jsonpath='{ .data.token }' | base64 --decode)
KUBE_CA_CERT=$(kubectl get secret -n vault \
   $(kubectl get serviceaccount vault-transit -n vault -o jsonpath='{.secrets[0].name}') \
   -o jsonpath='{ .data.ca\.crt }' | base64 --decode)
KUBE_HOST=$(kubectl config view --raw --minify --flatten \
   -o jsonpath='{.clusters[].cluster.server}')
# upload: execution steps
kubectl cp ${BOOTSTRAP_DIR}/vault/bootstrap-transit-vault.sh vault/vault-transit-0:/home/vault/bootstrap-transit-vault.sh
# upload: policies
kubectl cp ${BOOTSTRAP_DIR}/vault/policies/autounseal.hcl vault/vault-transit-0:/home/vault/autounseal.hcl
# run
kubectl exec vault-transit-0 -n vault -- sh -c "\
  export VAULT_UNSEAL_KEY_1=\"${TRANSIT_UNSEAL_KEY_1}\"; \
  export VAULT_TOKEN=\"${TRANSIT_TOKEN}\"; \
  export TOKEN_REVIEW_JWT=\"${TOKEN_REVIEW_JWT}\"; \
  export KUBE_CA_CERT=\"${KUBE_CA_CERT}\"; \
  export KUBE_HOST=\"${KUBE_HOST}\"; \
  sh /home/vault/bootstrap-transit-vault.sh"

### Setup Vault (Main) ###
# re-authentication to transit-vault
kubectl delete pod vault-main-0 -n vault
while ! kubectl exec -it vault-main-0 -n vault -- hostname; do echo 'trying again in 20s..'; sleep 20; done
# unseal
kubectl exec -it vault-main-0 -n vault -- vault operator init -format json > ${OUTPUT_DIR}/main-unsealkeys.json
MAIN_TOKEN=$(cat ${OUTPUT_DIR}/main-unsealkeys.json | jq '.root_token')
# upload: execution steps
kubectl cp ${BOOTSTRAP_DIR}/vault/bootstrap-main-vault.sh vault/vault-main-0:/home/vault/bootstrap-main-vault.sh
# upload: policies
kubectl cp ${BOOTSTRAP_DIR}/vault/policies/admin.hcl vault/vault-main-0:/home/vault/admin.hcl
kubectl cp ${BOOTSTRAP_DIR}/vault/policies/user.hcl vault/vault-main-0:/home/vault/user.hcl
# upload: sealedsecret key
kubectl cp ${BOOTSTRAP_DIR}/secrets/sealedsecret-key.json vault/vault-main-0:/home/vault/sealedsecret-key.json
kubectl cp ${BOOTSTRAP_DIR}/secrets/controller-secret.json vault/vault-main-0:/home/vault/controller-secret.json
# run
kubectl exec vault-main-0 -n vault -- sh -c "\
  export VAULT_TOKEN=\"${MAIN_TOKEN}\"; \
  sh /home/vault/bootstrap-main-vault.sh"
