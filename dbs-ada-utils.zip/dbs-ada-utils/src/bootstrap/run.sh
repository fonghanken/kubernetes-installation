#!/usr/bin/env bash
set -e

BOOTSTRAP_DIR=$(cd `dirname $BASH_SOURCE` && pwd)
K8S_DIR=$(cd $BOOTSTRAP_DIR/../../k8s && pwd)
OVERLAY_NAME="$(cat ${BOOTSTRAP_DIR}/config.json | jq -r '.environment')"

echo '---------- input arguments ----------'
echo "BOOTSTRAP_DIR : ${BOOTSTRAP_DIR}"
echo "K8S_DIR       : ${K8S_DIR}"
echo "OVERLAY_NAME  : ${OVERLAY_NAME}"
echo "K8_CONTEXT    : $(kubectl config current-context)"
echo "-------------------------------------"
read -r -p "Proceed with bootstraping [y|n] ? " CONTINUE;
if [ ${CONTINUE} != "y" ]; then \
    echo "exiting.."
    exit
fi

mkdir -p ${BOOTSTRAP_DIR}/secrets

### Gather Files ###
aws secretsmanager get-secret-value --secret-id dbs-ada/controller/sealedsecret-key --output text --query 'SecretString' > ${BOOTSTRAP_DIR}/secrets/sealedsecret-key.json
# aws secretsmanager get-secret-value --secret-id dbs-ada/jenkins/jenkins --output text --query 'SecretString' > ${BOOTSTRAP_DIR}/secrets/jenkins.json

### Base ###
# # namespaces
# kubectl apply -f ${K8S_DIR}/cluster-config/vault/base/namespace.yaml
# kubectl apply -f ${K8S_DIR}/cluster-config/jenkins/base/namespace.yaml
# # pvs
# if [[ "$(kubectl get nodes --no-headers | grep 'minikube' | wc -l)" -gt 0 ]]; then
#   kubectl label nodes minikube role=infra --overwrite
# fi
# kubectl apply -f ${BOOTSTRAP_DIR}/bootstrap-job.yaml
# kubectl wait --for=condition=complete --timeout=180s job/bootstrap-job
# if [[ "$(kubectl get job bootstrap-job -o jsonpath='{.status.succeeded}')" != 1 ]]; then
#   echo 'init failed. unable to create required infra node directories.'
#   exit 2
# fi
# kubectl delete -f ${BOOTSTRAP_DIR}/bootstrap-job.yaml
kubectl apply -k ${K8S_DIR}/cluster-config/utility-app/base/pv
# # secrets
# kubectl apply -f ${BOOTSTRAP_DIR}/secrets/jenkins.json

### Deploy sealedsecrets controller ###
kubectl apply -f ${BOOTSTRAP_DIR}/secrets/sealedsecret-key.json
kubectl apply -f ${K8S_DIR}/cluster-config/sealedsecrets/base/sealedsecret-controller.yaml
kubectl wait -n=kube-system --for=condition=ready pod -l name=sealed-secrets-controller

#### Deploy ArgoCD ###
kubectl apply -f ${K8S_DIR}/cluster-config/argocd/base/namespace.yaml
kubectl apply -f ${K8S_DIR}/cluster-config/sealedsecrets/overlays/demo/gitcred-ssh-dbs-ada-sealed.yaml
kubectl apply -k ${K8S_DIR}/cluster-config/argocd/overlays/${OVERLAY_NAME}
### Wait for 2 minutes ###
kubectl wait -nargocd \
  --for=condition=Ready pod \
  --selector=ada-argo=argo-deployment \
  --timeout=180s

### Deploy ArgoCD Default App ###
kubectl apply -k ${K8S_DIR}/argocd-config/overlays/${OVERLAY_NAME}

echo "done.."