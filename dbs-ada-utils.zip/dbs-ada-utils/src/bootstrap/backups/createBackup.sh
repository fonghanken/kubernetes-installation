URL=https://longhorn.stg.ada.dbs-sandbox.versent-innovation.au1.staxapp.cloud
PVC_FILTER='utility-app","rabbitmq","pd-tidb","tikv-tidb'
### List PVCs
PV_LIST=( $(curl -sk $URL'/v1/volumes' | jq -r '.data[].kubernetesStatus | select(.pvcName|test("'$PVC_FILTER'")) | .pvName') )

for PV_NAME in "${PV_LIST[@]}"
do
    ### Get backup name
    BACKUP_NAME=$(curl -sk $URL'/v1/volumes' | jq -r '.data[] | select(.kubernetesStatus.pvName|test("'$PV_NAME'")) | .name')

    ### Get namespace
    NS=$(curl -sk $URL'/v1/volumes' | jq -r '.data[].kubernetesStatus | select(.pvName|test("'$PV_NAME'")) | .namespace')

    ### Get PVC name
    PVC_NAME=$(curl -sk $URL'/v1/volumes' | jq -r '.data[].kubernetesStatus | select(.pvName|test("'$PV_NAME'")) | .pvcName')
    DATE_NOW=$(date +%F)
    TIME_NOW=$(date +%T)

    ### Create Snapshot
    SNAPSHOT_ID=$(curl -sX POST -H 'Accept: application/json' -H 'Content-Type: application/json' \
                    -d '{"labels":{"date":"'$DATE_NOW'", "time":"'$TIME_NOW'"}}' $URL'/v1/volumes/'$BACKUP_NAME'?action=snapshotCreate' \
                    | jq -r '.name')
    
    ### Get Latest Snapshot (volume-head)
    # curl -sX POST -H 'Accept: application/json' -H 'Content-Type: application/json' -d '{"name":"volume-head"}' \
    #     $URL'/v1/volumes/'$BACKUP_NAME'?action=snapshotGet' | jq -r '.parent'

    ### Create Backup of Snapshot
    BACKUP_ID=$(curl -sX POST -H 'Accept: application/json' -H 'Content-Type: application/json' \
                -d '{"labels":{"date":"'$DATE_NOW'", "time":"'$TIME_NOW'"}, "name":"'$SNAPSHOT_ID'"}' $URL'/v1/volumes/'$BACKUP_NAME'?action=snapshotBackup' \
                | jq -r '.backupStatus[0].id')

    echo "NS: $NS, PVC: $PVC_NAME, PV: $PV_NAME, BACKUP: $BACKUP_NAME, SNAPSHOT: $SNAPSHOT_ID BACKUP_ID: $BACKUP_ID"
    echo "=========================================================================================================="
done