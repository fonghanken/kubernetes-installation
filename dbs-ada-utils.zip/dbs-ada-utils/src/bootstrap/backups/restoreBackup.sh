URL=https://longhorn.stg.ada.dbs-sandbox.versent-innovation.au1.staxapp.cloud
PVC_FILTER='pd-tidb","tikv-tidb' #utility-app","rabbitmq","

PV_LIST=( $(curl -sk $URL'/v1/backupvolumes' | jq -r '.data[].labels.KubernetesStatus' | jq -r 'select(.pvcName|test("'$PVC_FILTER'")) | .pvName') )

for PV_NAME in "${PV_LIST[@]}"
do
    ### Get backup name
    BACKUP_NAME=$(curl -sk $URL'/v1/backupvolumes' | jq -r '.data[] | select(.labels.KubernetesStatus|test("{\"pvName\":\"'$PV_NAME'\",")) | .name')

    ### Get NS
    NS=$(curl -sk $URL'/v1/backupvolumes' | jq -r '.data[].labels.KubernetesStatus' | jq -r 'select(.pvName|test("'$PV_NAME'")) | .namespace')

    ### Get PVC name
    PVC_NAME=$(curl -sk $URL'/v1/backupvolumes' | jq -r '.data[].labels.KubernetesStatus' | jq -r 'select(.pvName|test("'$PV_NAME'")) | .pvcName')

    echo "NS: $NS, PVC: $PVC_NAME, PV: $PV_NAME, BACKUP: $BACKUP_NAME"
    echo "==========================================================="

    ### Get Latest Date
    LATEST_BACKUP_DATE=$(curl -sX POST -H 'Accept: application/json' -H 'Content-Type: application/json' $URL'/v1/backupvolumes/'$BACKUP_NAME'?action=backupList' \
                    | jq -r '[.data[].created] | max')

    ### Get Backup ID
    BACKUP_ID=$(curl -sX POST -H 'Accept: application/json' -H 'Content-Type: application/json' $URL'/v1/backupvolumes/'$BACKUP_NAME'?action=backupList' \
                    | jq -r '.data[] | select(.created|test("'$LATEST_BACKUP_DATE'")) | .id')

    ### Get Backup URL
    BACKUP_URL=$(curl -sX POST -H 'Accept: application/json' -H 'Content-Type: application/json' $URL'/v1/backupvolumes/'$BACKUP_NAME'?action=backupList' \
                    | jq -r '.data[] | select(.created|test("'$LATEST_BACKUP_DATE'")) | .url')

    ### Create volume from Backup
    curl -sX POST -H 'Accept: application/json' -H 'Content-Type: application/json' \
        -d '{
                "name": "'$PV_NAME'",
                "numberOfReplicas": 3,
                "accessMode": "rwx",
                "backingImage": "", 
                "encrypted": false,
                "nodeSelector": [],
                "diskSelector": [],
                "fromBackup": "'$BACKUP_URL'",
                "staleReplicaTimeout": 20
            }' \
        $URL'/v1/volumes' | jq -r '.name'

    ### Create PV
    curl -sX POST -H 'Accept: application/json' -H 'Content-Type: application/json' -d '{"fsType":"ext4", "pvName":"'$PV_NAME'", "secretName":"", "secretNamespace":""}' \
        $URL'/v1/volumes/'$PV_NAME'?action=pvCreate' | jq -r '.name'

    ### Create PVC
    curl -sX POST -H 'Accept: application/json' -H 'Content-Type: application/json' -d '{"namespace":"'$NS'", "pvcName":"'$PVC_NAME'"}' \
        $URL'/v1/volumes/'$PV_NAME'?action=pvcCreate' | jq -r '.name'
done
