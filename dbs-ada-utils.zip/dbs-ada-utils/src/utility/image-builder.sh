aws ecr-public get-login-password --region us-east-1 | docker login --username AWS --password-stdin public.ecr.aws;
if [ -z "${IMG_REPO_URL}" ]; then
    IMG_REPO_URL=public.ecr.aws/e7y4y7w2
fi
if [ -z "${S3_UPLOAD}" ]; then
    S3_UPLOAD=false;
fi
DOCKER_DIR=src/docker
if [ -z "${IMG_LIST}" ]; then
    IMG_LIST=( $(find $DOCKER_DIR -print | grep Dockerfile | sed 's/src\/docker\///g;s/\/Dockerfile//g;') )
else
    IMG_LIST=( ${IMG_LIST//,/} )
fi

for IMG_NAME in "${IMG_LIST[@]}"
do
    echo "======= Building $IMG_NAME =======" 
    aws ecr-public describe-repositories --region us-east-1 --repository-names ${IMG_NAME} || aws ecr-public create-repository --region us-east-1 --repository-name ${IMG_NAME}
    IMG_VERSION=$(cat $DOCKER_DIR/$IMG_NAME/config.json | jq -r '.version')
    echo "---> Docker build" &&
    docker build $DOCKER_DIR/$IMG_NAME --tag ${IMG_REPO_URL}/$IMG_NAME:$IMG_VERSION &&
    echo "---> Docker push" &&
    docker push ${IMG_REPO_URL}/$IMG_NAME:$IMG_VERSION &&
    echo "---> S3 upload" &&
    if $S3_UPLOAD; then
        S3_NAME=$(echo custom-$IMG_NAME:$IMG_VERSION.tar | sed "s/\//-/g")
        docker save ${IMG_REPO_URL}/$IMG_NAME:$IMG_VERSION -o $S3_NAME
        aws s3 mv $S3_NAME s3://dbsada-artifacts/images/$S3_NAME
    else
        echo "No action - S3_UPLOAD is $S3_UPLOAD"
    fi
    echo "---> Docker remove" &&
    docker image rm ${IMG_REPO_URL}/$IMG_NAME:$IMG_VERSION
    echo "======= Complete $IMG_NAME ======="
done