#!/usr/bin/env bash

imageArray=( $1 )
dockerRegistry=docker-registry:5000
imageName=""

echo "Uploading #${#imageArray[@]} images"

for i in "${imageArray[@]}"
do
  imageName=$1
  docker tag $imageName $dockerRegistry/$imageName
  docker push $dockerRegistry/$imageName
done
