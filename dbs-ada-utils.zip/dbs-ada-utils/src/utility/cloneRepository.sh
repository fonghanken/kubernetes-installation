#!/usr/bin/env bash
set -e

#############################################################
### Functions                                             ###
#############################################################
function help() {
    echo "Usage: ./cloneRepository.sh [path-to-repository-bundle]"
    echo "       ./cloneRepository.sh main.bundle"
}

#############################################################
### Entry Point                                           ###
#############################################################
UTILS_DIR=$(cd `dirname $BASH_SOURCE` && pwd)
REPO_PARENT_DIR=$(cd $UTILS_DIR/../../../ && pwd)
# BB_REPO_DIR="${REPO_PARENT_DIR}/ada_adak8s"
GH_REPO_DIR="${REPO_PARENT_DIR}/gh_repo"
BUNDLE_FILEPATH=$1

case $BUNDLE_FILEPATH in
  /*) ;;
  *) BUNDLE_FILEPATH=${PWD}/${BUNDLE_FILEPATH} ;;
esac

if [ ! -f "${BUNDLE_FILEPATH}" ]; then
  help
  echo "error: repository bundle not found.."
  exit
fi

echo "--------------------------------------"
echo "BUNDLE_FILEPATH   : ${BUNDLE_FILEPATH}"
echo "UTILS_DIR         : ${UTILS_DIR}"
echo "REPO_PARENT_DIR   : ${REPO_PARENT_DIR}"
# echo "BB_REPO_DIR       : ${BB_REPO_DIR}"
echo "GH_REPO_DIR       : ${GH_REPO_DIR}"
echo "--------------------------------------"
read -r -p "Proceed with repository update [y|n] ? " CONTINUE;
if [ ${CONTINUE} != "y" ]; then \
    echo "exiting.."
    exit
fi

# ## (A) Push to existing ada_adak8s repository, on gh-repo branch
# rm -rf "${BB_REPO_DIR}" && echo "deleted ${BB_REPO_DIR}"
# git clone ssh://git@bitbucket.sgp.dbs.com:7999/ada_adak8s/ada_adak8s.git ${BB_REPO_DIR}
# shopt -s extglob

# cd ${BB_REPO_DIR}
# rm -rf !(".git"|"."|"..")

# rm -rf ${GH_REPO_DIR}/.git
# cp -r ${GH_REPO_DIR}/* .

# git checkout -b feature/gh-repo
# git commit -m 'clone from github'
# git push --set-upstream origin feature/gh-repo

## (B) Push to new adak8s repository, on main branch
rm -rf "${GH_REPO_DIR}" && echo "deleted ${GH_REPO_DIR}"
git clone -b main ${BUNDLE_FILEPATH} ${GH_REPO_DIR}
cd ${GH_REPO_DIR}
git remote set-url origin ssh://git@bitbucket.sgp.dbs.com:7999/ada_adak8s/adak8s.git
git checkout -b stage
git push --set-upstream origin stage
# git push -u origin --all
# git push origin --tags

rm -rf "${GH_REPO_DIR}" && echo "cleaned up ${GH_REPO_DIR}"
