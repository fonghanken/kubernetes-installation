#/bin/bash

dir_path=*
if [ $# -gt 0 ]; then
  dir_path=$1
fi

grep "image:" $dir_path -r | grep -vE "docker-registry:5000|{{|}}" | cut -d : -f3,4,5 | sed 's/"//g; s/ //g' | sort | uniq > image_list.txt

while read image; do
  echo "$image"
  #sed -i "s/$image/docker-registry:5000\/$image/g" *
  #find . -name *.* -exec sed -i "s/$image/docker-registry:5000\/$image/g" {} \;
  grep -rl "$image" $dir_path | grep -vE "image_list.txt|update_docker_registry.sh" | xargs sed -i "s!$image!docker-registry:5000/$image!g"
done < image_list.txt

rm -rf image_list.txt
