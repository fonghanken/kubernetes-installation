#!/usr/bin/env bash
source functions.sh
source ~/.bashrc

ARGO_DIR=/home/adak8s1/ada_adak8s/poc/k8s-config/argocd/overlays/demo/
APPS_DIR=/home/adak8s1/ada_adak8s/poc/argocd-config/overlays/demo/apps/
ARGO_SECRET=/home/adak8s1/docker_images/argo-secret.yaml

### Step 1 - Deploy ArgoCD
kubectl create -k $ARGO_DIR &&
f_wait 20 &&

### Step 2 - Deploy Bitbucket Secrets
kubectl apply -f $ARGO_SECRET &&
f_wait 5 &&

### Step 3 - Grep ArgoCD Password
kubectl -nargocd get secret argocd-initial-admin-secret -o jsonpath='{.data.password}' | base64 -d &&
echo "Wait for deployment of ArgoCD"
f_wait 120 &&

### Step 4 - Deploy ArgoCD App
kubectl create -k $APPS_DIR 
