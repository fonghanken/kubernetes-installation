#!/usr/bin/env bash

gitHubDir=
bitBucketURL=