## Purpose
Jupyterlab user image with required jars

## Building the Image
```
docker build -t public.ecr.aws/e7y4y7w2/jupyter/all-spark-notebook:2022-04-24-ada1 .

aws ecr-public get-login-password --region us-east-1 | docker login --username AWS --password-stdin public.ecr.aws
docker push public.ecr.aws/e7y4y7w2/jupyter/all-spark-notebook:2022-04-24-ada1
```
