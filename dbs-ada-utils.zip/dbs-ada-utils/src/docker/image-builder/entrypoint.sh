#!/bin/bash
systemctl start docker