## Purpose
TiDB Enterprise tools for backup and restore

## Building the Image
```
docker build -t public.ecr.aws/e7y4y7w2/adak8s/tidb-tools:debian-v5.4.0 .

aws ecr-public get-login-password --region us-east-1 | docker login --username AWS --password-stdin public.ecr.aws
docker push public.ecr.aws/e7y4y7w2/adak8s/tidb-tools:debian-v5.4.0
```

## Backup
```bash
# Local
br backup full \
    --pd "tidb-cluster-pd:2379" \
    --storage "local:///tmp/backup" \
    --log-file backupfull.log

# S3
export AWS_ACCESS_KEY_ID='sa-access-key'
export AWS_SECRET_ACCESS_KEY='sa-secret-key'
br backup full \
    --pd "tidb-cluster-pd.tidb:2379" \
    --storage "s3://tidb/backup" \
    --s3.endpoint "https://s3-api.stg.ada.dbs-sandbox.versent-innovation.au1.staxapp.cloud" \
    --send-credentials-to-tikv=true \
    --ratelimit 128 \
    --log-file backupfull.log
```

## Restore
```bash
# S3
export AWS_ACCESS_KEY_ID='sa-access-key'
export AWS_SECRET_ACCESS_KEY='sa-secret-key'
br restore full \
    --pd "tidb-cluster-pd.tidb:2379" \
    --storage "s3://tidb/backup/1652879708" \
    --s3.endpoint "https://s3-api.stg.ada.dbs-sandbox.versent-innovation.au1.staxapp.cloud" \
    --send-credentials-to-tikv=true \
    --ratelimit 128 \
    --log-file restorefull.log
```