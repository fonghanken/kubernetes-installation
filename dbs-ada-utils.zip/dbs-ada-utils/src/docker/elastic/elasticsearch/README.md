## Purpose
Airflow pre-baked with required packages and python modules

## Building the Image
```
docker build -t public.ecr.aws/e7y4y7w2/elastic/elasticsearch:7.16.3-adak8s .

aws ecr-public get-login-password --region us-east-1 | docker login --username AWS --password-stdin public.ecr.aws
docker push public.ecr.aws/e7y4y7w2/elastic/elasticsearch:7.16.3-adak8s
```
