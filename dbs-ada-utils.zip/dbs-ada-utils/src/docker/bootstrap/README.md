# Purpose
Contains the necessary tools and scripts to:
1. Bootstrap and nuke the ArgoCD cluster
2. Generate the config yaml for each cluster environment
3. Creates the necessary tool overlays

# Usage
```
docker run -it --rm \
    --volume=/Users/seanlim/.ssh:/root/.ssh \
    --volume=$(pwd)/adak8s-overlays:/tmp/repo \
    --volume=$(pwd)/dbs-ada-utils:/tmp/utils-repo \
    public.ecr.aws/e7y4y7w2/bootstrap:v1.0 sh
```

## Edit Manifest
```
python /tmp/utils-repo/src/docker/bootstrap/scripts/gitops/editManifest.py
```
## Generate 
```
python /tmp/utils-repo/src/docker/bootstrap/scripts/gitops/generateValues.py
```

## Create cluster overlays
```
./createPlatformOverlays.sh /repo alpha
```
