## Purpose
Airflow pre-baked with required packages and python modules

## Building the Image
```
docker build -t public.ecr.aws/e7y4y7w2/apache/airflow:v2.2.3-ada3 .

aws ecr-public get-login-password --region us-east-1 | docker login --username AWS --password-stdin public.ecr.aws
docker push public.ecr.aws/e7y4y7w2/apache/airflow:v2.2.3-ada3
```

## Tags
- `v2.2.3-java` / `v2.2.3-ada1`
  - installs java
  - install airflow provider for spark 
- `v2.2.3-ada2`
  - pip install w/o cache
  - install airflow provider for trino
- `v2.2.3-ada3`
  - adds hadoop and aws jars
