## Purpose
Kubeseal cli and Git client

## Building the Image
```
docker build -t public.ecr.aws/e7y4y7w2/adak8s/kubeseal:alpine-v3.15.4 .

aws ecr-public get-login-password --region us-east-1 | docker login --username AWS --password-stdin public.ecr.aws
docker push public.ecr.aws/e7y4y7w2/adak8s/kubeseal:alpine-v3.15.4
```
