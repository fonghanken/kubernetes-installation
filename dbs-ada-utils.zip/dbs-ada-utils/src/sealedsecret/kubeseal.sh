#!/usr/bin/env bash
# set -euo pipefail

homeDir=$(pwd)
secretsDir="$homeDir/secrets"
mkdir -p "$secretsDir"
echo "home directory: $homeDir"
echo "secrets directory: $secretsDir"

function getSecret() {
    # params
    # 1 - path get secret
    URL="https://vault.stg.ada.dbs-sandbox.versent-innovation.au1.staxapp.cloud" &&
    # URL="https://vault-main.vault:8200" &&
    SECPATH=$1 &&
    USER="$vaultuser" &&
    PASS="$vaultpassword" &&
    VAULT_TOKEN=$(curl -sk --request POST --data '{"password": "'$PASS'"}' $URL/v1/auth/userpass/login/$USER | jq -r '.auth.client_token') &&
    curl -sk --header "X-Vault-Token: $VAULT_TOKEN" "$URL/$SECPATH" | jq -r '.data.data'
}

# assumptions:
# secrets are in the format of k8s json manifests
# secrets are stored in the engine ada-infra under the k8s folder with the format <namespace>/<secret name>
# a secret for the argocd namespace called gitcred-some-secret will be stored as k8s/argocd/gitcred-some-secret in ada-infra engine
function listSecrets() { # lists secrets in current directory
    # params
    # 1 - path to list secrets
    URL="https://vault.stg.ada.dbs-sandbox.versent-innovation.au1.staxapp.cloud" &&
    # URL="https://vault-main.vault:8200" &&
    SECPATH=$1 &&
    USER="$vaultuser" &&
    PASS="$vaultpassword" &&
    VAULT_TOKEN=$(curl -sk --request POST --data '{"password": "'$PASS'"}' $URL/v1/auth/userpass/login/$USER | jq -r '.auth.client_token') &&
    curl -sk --header "X-Vault-Token: $VAULT_TOKEN" -X LIST "$URL/$SECPATH"
}

function outputSecrets() {
    # Outputs secrets from vault as json file to a specified directory
    # params
    # 1 - path to list and get all secrets
    # 2 - directory to output json files to (best is to give an absolute path to prevent issues)
    # 3 - namespace. is passed in if statement to recursively call outputSecrets on subdirectories
    echo "listing secrets in $1"
    listSecrets "$1" | jq -r '.data.keys' | jq -rc '.[]' | while read -r secret; do
        if [[ $secret == */ ]]; then
            # echo "$secret ends with slash, is a directory/namespace"
            echo "checking subdirectory $secret"
            secretSansSlash=${secret%/}
            outputSecrets "$1/$secretSansSlash" "$2" "$secretSansSlash"
        else
            echo "Processing secrets $secret"
            if [ "${3:-""}" = "" ]; then
                echo "No namespace supplied for secret $secret"
                # comment out below if you do not want to generate secrets that do not conform to naming convention
                # secretName="default-$secret"
                # getSecretPath="${1/metadata/data}" 
                # # GET path is different from LIST path. e.g.
                # # get: v1/ada-infra/metadata/k8s/argocd/secret
                # # list: v1/ada-infra/data/k8s/argocd/
                # getSecret "$getSecretPath/$secret" > "$2/$secretName.json"
            else
                # echo "secret name is: $secret, namespace is: $3"
                secretName="$3-$secret"
                getSecretPath="${1/metadata/data}" 
                # GET path is different from LIST path. e.g.
                # get: v1/ada-infra/metadata/k8s/argocd/secret
                # list: v1/ada-infra/data/k8s/argocd/
                getSecret "$getSecretPath/$secret" > "$2/$secretName.json"
            fi
        fi
    done
}

function outputSealedSecrets (){
    # Given a directory of secrets, use kubeseal to generate and save sealed secrets to a directory
    # params
    # 1 - directory where secrets are stored
    # 2 - directory to output sealed secrets to
    for file in "$1"/*.json; do
        echo "file is $file"
        filename=$(basename "$file")
        kubeseal --format=yaml --cert="$homeDir/sealedsecret-tls.crt" < "$file" > "$2/${filename%.json}-sealed.yaml"
    done
}

echo "---Retrieve secrets from Vault---"
outputSecrets "v1/ada-infra/metadata/k8s" "$secretsDir"

echo "---get sealed secrets key---"
getSecret "v1/ada-infra/data/sealedsecret-key" | jq -r '.data."tls.crt"' | base64 -d > sealedsecret-tls.crt

echo "---get git creds key---"
getSecret "v1/ada-infra/data/dbs-ada/git-ssh-keys" | jq -r '."ssh-key"' > id_rsa
mkdir ~/.ssh
chmod 400 ./id_rsa && mv ./id_rsa ~/.ssh/id_rsa
eval "$(ssh-agent -s)"
ssh-add -k ~/.ssh/id_rsa

echo "---git clone---"
ssh -o StrictHostKeyChecking=no git@github.com
# ssh -vT git@github.com
git clone git@github.com:Versent/dbs-ada.git
cd "$homeDir/dbs-ada" || exit
# git checkout feature/kubeseal-commit # temporary until tested working

echo "---Kubeseal secrets into sealed secrets---"
sealedSecretsDir="$homeDir/dbs-ada/ k8s/cluster-config/sealedsecrets"
outputSealedSecrets "$secretsDir" "$sealedSecretsDir"

echo "---list sealedsecrets---"
ls "$homeDir/dbs-ada/ k8s/cluster-config/sealedsecrets/"

echo "---check git status---"
git status

echo "---push to git---"
git config --global user.email "jenkinsbot"
git config --global user.name "jenkinsbot"
git add "$sealedSecretsDir/*-sealed.yaml"
git commit -m "Sealedsecret Updates"
git status
git push origin

echo "---clean up sensitive data---"
rm "$secretsDir"/* "$homeDir/sealedsecret-tls.crt" "$HOME/.ssh/id_rsa"