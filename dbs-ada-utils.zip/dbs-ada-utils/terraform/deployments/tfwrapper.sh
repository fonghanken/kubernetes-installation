#!/usr/bin/env bash
process=$1
environment=$2
tf_additional_args=$3
tf_options="-var=ENV=${environment}"

#############################################################
### Functions                                             ###
#############################################################
function help() {
    echo "Usage: ./tfwrapper.sh [init|plan|apply|destroy] [env]"
    echo "  ./tfwrapper.sh init"
    echo "  ./tfwrapper.sh apply stg"
}

function log_error() {
    RED='\033[0;31m'
    NC='\033[0m'
    echo -e "${RED}${1}${NC}"
}

#############################################################
### Entry point                                           ###
#############################################################
## Process: init
if [[ "${process}" == 'init' ]]; then
    tf_additional_arg=${2}
    set -x
    # terraform init -backend-config="${env_dir}/backend.tfvars" ${tf_additional_arg}
    terraform init ${tf_additional_arg}
    exit
fi

#############################################################
### Entry point                                           ###
#############################################################
## Process: plan | apply | destroy
echo '------ input arguments ------'
echo "process           : ${process}"
echo "environment       : ${environment}"
echo "additional args   : ${tf_additional_args}"
echo '-----------------------------'

## Validation: Accepted process(es)
if [[ "${process}" != 'plan' && "${process}" != 'apply' && "${process}" != 'destroy' ]]; then
    help
    echo "exiting.."
    exit
fi

## Validation: Environment variable
if [[ -z "${environment}" ]]; then
    log_error "Missing environment"
    echo "exiting.."
    exit
fi

## User Confirmation
read -r -p "Proceed with ${process}-ing \"${environment}\" environment [y|n] ? " CONTINUE;
if [ ${CONTINUE} != "y" ]; then \
    echo "exiting.."
    exit
fi

## Execute
set -x
terraform workspace select ${environment} \
&& terraform ${process} ${tf_options} ${tf_additional_args}
